package com.subzeal.champ_de_prosperite.activities.farm_activities.harvests;

import static com.subzeal.champ_de_prosperite.activities.farm_activities.harvests.adapters.HarvestsAdapter.INTENT_KEY_PASS_HARVEST_ITEM;
import static com.subzeal.champ_de_prosperite.utils.Logger.printd;
import static com.subzeal.champ_de_prosperite.utils.UtilFunctions.getMonthFromInt;

import androidx.appcompat.app.ActionBar;
import androidx.appcompat.app.AppCompatActivity;

import android.app.DatePickerDialog;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.DatePicker;
import android.widget.Toast;

import com.google.android.material.textfield.TextInputEditText;
import com.subzeal.champ_de_prosperite.R;
import com.subzeal.champ_de_prosperite.activities.farm_activities.harvests.local_db.HarvestsDatabaseHandler;
import com.subzeal.champ_de_prosperite.activities.farm_activities.harvests.models.HarvestItem;
import com.subzeal.champ_de_prosperite.local_auth.SharedPreferencesAuth;
import com.subzeal.champ_de_prosperite.utils.KeyboardController;

import java.util.Calendar;

public class EditHarvestActivity extends AppCompatActivity {
    private static String TAG="EditHarvestActivity";
    private TextInputEditText plantingDateEdt;
    String iyear=null;
    int imonth=0;
    String iday=null;
    private boolean dateIsSet=false;

    private TextInputEditText harvestDateEdt,
            harvestNameEdt,harvestQuantityEdt
            ,harvestIncomeEdt,harvestUnitCostEdt,harvestNameOfFieldEdt,harvestNotesEdt;

    private KeyboardController keyboardController;
    private HarvestsDatabaseHandler harvestsDatabasehandler;
    private HarvestItem harvestItem=null;
    private SharedPreferencesAuth sharedPreferencesAuth;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        sharedPreferencesAuth=new SharedPreferencesAuth(this);

        setContentView(R.layout.activity_edit_harvest);
        harvestsDatabasehandler=new HarvestsDatabaseHandler(this);
        keyboardController=new KeyboardController(this);

        // ActionBar and its title
        ActionBar actionBar=getSupportActionBar();
        actionBar.setTitle("Harvest");

        // enable back button
        actionBar.setDisplayHomeAsUpEnabled(true);
        actionBar.setHomeButtonEnabled(true);


        harvestDateEdt=findViewById(R.id.harvests_date_id);
        harvestNameEdt=findViewById(R.id.harvest_name_id);
        harvestQuantityEdt=findViewById(R.id.haverst_quantity_id);
        harvestIncomeEdt=findViewById(R.id.haverst_income_id);
        harvestUnitCostEdt=findViewById(R.id.haverst_unit_cost_id);
        harvestNameOfFieldEdt=findViewById(R.id.harvest_name_of_field_id);
        harvestNotesEdt=findViewById(R.id.harvest_short_notes_id);


        Bundle extras = getIntent().getExtras();
        if (extras != null) {
            //currentFile = (Paper)getIntent().getSerializableExtra(PAPER_TO_FILEVIEW_DATA_KEY); //Obtaining data
            harvestItem = (HarvestItem) getIntent().getParcelableExtra(INTENT_KEY_PASS_HARVEST_ITEM);
            // show related fiels
            displayPlantData(harvestItem);
        }



        // listed to date clicks
        harvestDateEdt.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                //Toast.makeText(getApplicationContext(),"planting date clicked",Toast.LENGTH_SHORT).show();
                final Calendar newCalender=Calendar.getInstance();

                DatePickerDialog dialog=new DatePickerDialog(EditHarvestActivity.this, new DatePickerDialog.OnDateSetListener() {
                    @Override
                    public void onDateSet(DatePicker view, int year, int month, int dayOfMonth) {
                        iyear=year+"";
                        imonth=month;
                        iday=dayOfMonth+"";
                        printd(TAG,"day : "+dayOfMonth);
                        printd(TAG,"month : "+month);
                        printd(TAG,"year : "+year);
                        dateIsSet=true;
                        harvestDateEdt.setText(dayOfMonth+"/"+month+"/"+year);
                    }
                },newCalender.get(Calendar.YEAR),newCalender.get(Calendar.MONTH),newCalender.get(Calendar.DAY_OF_MONTH));

                dialog.show();
            }
        });


    }//end of onCreate


    private void displayPlantData(HarvestItem harvestItem) {
        harvestDateEdt.setText(harvestItem.getHarvestDate());
        harvestNameEdt.setText(harvestItem.getHarvestName());
        harvestQuantityEdt.setText(harvestItem.getQuantityHarvested()+"");
        harvestIncomeEdt.setText(harvestItem.getIncome()+"");
        harvestUnitCostEdt.setText(harvestItem.getUnitCosts()+"");
        harvestNameOfFieldEdt.setText(harvestItem.getNameOfField());
        harvestNotesEdt.setText(harvestItem.getNotes());
    }

    private void updateHarvestItem(){
        String harvestName=harvestNameEdt.getText().toString().trim();
        Double harvestQuantity= Double.valueOf(harvestQuantityEdt.getText().toString());
        String nameOfField=harvestNameOfFieldEdt.getText().toString().trim();
        Double harvestIncome= Double.valueOf(harvestIncomeEdt.getText().toString().trim());
        Double harvestUnitCost= Double.valueOf(harvestUnitCostEdt.getText().toString());
        String harvestNotes=harvestNotesEdt.getText().toString().trim();
        String harvestDate=iday+" "+getMonthFromInt(imonth)+", "+iyear;

        if(iday==null){
            harvestDate=harvestItem.getHarvestDate();
        }

        // check for empty fields
        if(harvestName.length()==0){
            Toast.makeText(EditHarvestActivity.this, getResources().getString(R.string.plantings_provide_name_of_plant), Toast.LENGTH_SHORT).show();
            return;
        }

        // remoekeyboard
        keyboardController.closeKeyboard();

        // harvest Item
        HarvestItem newItem=new HarvestItem();
        newItem.setHarvestName(harvestName);
        newItem.setHarvestDate(harvestDate);
        newItem.setNameOfField(nameOfField);
        newItem.setNotes(harvestNotes);
        newItem.setIncome(harvestIncome);
        newItem.setUnitCosts(harvestUnitCost);
        newItem.setQuantityHarvested(harvestQuantity);
        newItem.setId(harvestItem.getId());

        harvestsDatabasehandler.updateHaverstInfor(newItem);

        // finish activity
        finish();
    }


    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.farm_activities_edit_menu, menu);
        return super.onCreateOptionsMenu(menu);
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        switch (item.getItemId()) {
            case R.id.farm_activity_update_id:
                // User chose the "Settings" item, show the app settings UI...
                updateHarvestItem();
                return true;
            case R.id.farm_activity_delete_id:
                // User chose the "Settings" item, show the app settings UI...
                harvestsDatabasehandler.deleteHarvestItem(harvestItem);
                finish();
                return true;
            default:
                // If we got here, the user's action was not recognized.
                // Invoke the superclass to handle it.
                return super.onOptionsItemSelected(item);

        }
    }


}//end of EditHarvestActivity