package com.subzeal.champ_de_prosperite.activities.auth_and_language.local_db;

import android.content.Context;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

public class FarmerInforDBHelper extends SQLiteOpenHelper {

    private static final String DATABASE_NAME="farmerinfor.db";
    private static final int DATABASE_VERSION=1;

    final String SQL_CREATE_COUNTRY_TABLE
            ="CREATE TABLE "+ FarmerInforContract.TABLE_NAME+" ("+FarmerInforContract._ID
            +" TEXT PRIMARY KEY, "
            + FarmerInforContract.COLUMN_FARMER_FIRSTNAME_SURNAME+" TEXT , " +
            FarmerInforContract.COLUMN_FARMER_MONTH_OF_BIRTH+" TEXT , " +
            FarmerInforContract.COLUMN_FARMER_YEAR_OF_BIRTH+" TEXT , " +
            FarmerInforContract.COLUMN_FARMER_ID_NUMBER+" TEXT , " +
            FarmerInforContract.COLUMN_FARMER_PHONE_NUMBER+" TEXT , " +
            FarmerInforContract.COLUMN_FARMER_GENDER+" TEXT , " +
            FarmerInforContract.COLUMN_FARMER_VILLAGE+" TEXT , " +
            FarmerInforContract.COLUMN_FARMER_DISTRICT+" TEXT , " +
            FarmerInforContract.COLUMN_FARMER_LANGUAGE+" TEXT , " +
            FarmerInforContract.COLUMN_FARMER_DAY_OF_BIRTH+" TEXT);";

    public FarmerInforDBHelper(Context context) {
        super(context,DATABASE_NAME,null, DATABASE_VERSION);
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        db.execSQL(SQL_CREATE_COUNTRY_TABLE);
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        // ideally we wouldn't want to drop our tables/data
        db.execSQL("DROP TABLE IF EXISTS "+FarmerInforContract.TABLE_NAME);
        onCreate(db);
    }
}
