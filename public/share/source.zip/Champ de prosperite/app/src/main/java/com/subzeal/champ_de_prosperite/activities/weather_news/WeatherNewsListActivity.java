package com.subzeal.champ_de_prosperite.activities.weather_news;

import static com.subzeal.champ_de_prosperite.constants.app_constants.SHIMMER_ANGLE;
import static com.subzeal.champ_de_prosperite.constants.app_constants.SHIMMER_DURATION;
import static com.subzeal.champ_de_prosperite.constants.firebase_constants.REALTIME_DB_WEATHER_NEWS;
import static com.subzeal.champ_de_prosperite.utils.Logger.printd;

import androidx.appcompat.app.ActionBar;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.os.Bundle;
import android.util.Log;
import android.widget.ProgressBar;

import com.androidnetworking.AndroidNetworking;
import com.androidnetworking.common.Priority;
import com.androidnetworking.error.ANError;
import com.androidnetworking.interfaces.JSONObjectRequestListener;
import com.faltenreich.skeletonlayout.Skeleton;
import com.faltenreich.skeletonlayout.SkeletonLayoutUtils;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;
import com.jacksonandroidnetworking.JacksonParserFactory;
import com.subzeal.champ_de_prosperite.R;
import com.subzeal.champ_de_prosperite.adapters.GenericDataObjectAdapter;
import com.subzeal.champ_de_prosperite.local_auth.SharedPreferencesAuth;
import com.subzeal.champ_de_prosperite.models.updateDataObject;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.Collections;


public class WeatherNewsListActivity extends AppCompatActivity {
    private static String TAG="WeatherNewsListActivity";
    // declaring the views
    private ProgressBar mProgressBar;
    private RecyclerView mRecyclerView;
    private RecyclerView recylerViewExternalApi;

    // declaring an ArrayList of articles
    private ArrayList<updateDataObject> mDataList=new ArrayList<>();
    private ArrayList<updateDataObject> mApiNewsList=new ArrayList<>();

    private GenericDataObjectAdapter genericDataObjectAdapter;
    // views (skeletons)
    private Skeleton itemsListSkeleton;
    private SharedPreferencesAuth sharedPreferencesAuth;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        sharedPreferencesAuth=new SharedPreferencesAuth(this);
        setContentView(R.layout.activity_weather_news_list);
        // ActionBar and its title
        ActionBar actionBar=getSupportActionBar();
        actionBar.setTitle(getResources().getString(R.string.weather_news_label));

        // enable back button
        actionBar.setDisplayHomeAsUpEnabled(true);
        actionBar.setHomeButtonEnabled(true);

        //  initializing the Fast Android Networking Library
        AndroidNetworking.initialize(getApplicationContext());
        // setting the JacksonParserFactory
        AndroidNetworking.setParserFactory(new JacksonParserFactory());
        mRecyclerView=(RecyclerView)findViewById(R.id.recyclerview_id);

        // setting the recyclerview layout manager
        mRecyclerView.setLayoutManager(new LinearLayoutManager(this));
        //mRecyclerView.setHasFixedSize(false);
        itemsListSkeleton = findViewById(R.id.file_items_skeleton_Layout_id);
        // show loading skeleton
        showLoadingSkeleton();
        loadDataFromRealTimeDB();

        //get_news_from_api();

    }//end of onCreate

    public void get_news_from_api(){
        String API_KEY="b971358de21d4af48ae24b5faf06bbfd";
        // clearing the articles list before adding news ones
       mApiNewsList= new ArrayList<>();
        /* Making a GET Request using Fast Android Networking Library
         the request returns a JSONObject containing news articles from the news api
        or it will return an error
        */
        AndroidNetworking.get("https://newsapi.org/v2/top-headlines")
                //.addQueryParameter("country", "za")
                .addQueryParameter("category", "general")
                .addQueryParameter("apiKey",API_KEY)
                .addHeaders("token", "1234")
                .setTag("test")
                .setPriority(Priority.LOW)
                .build()
                .getAsJSONObject(new JSONObjectRequestListener(){
                    @Override
                    public void onResponse(JSONObject response) {
                        // disabling the progress bar
                        // handling the response
                        try {

                            // storing the response in a JSONArray
                            JSONArray articles=response.getJSONArray("articles");

                            // looping through all the articles to access them individually
                            for (int j=0;j<articles.length();j++)
                            {
                                // accessing each article object in the JSONArray
                                JSONObject article=articles.getJSONObject(j);

                                // initializing an empty ArticleModel
                                updateDataObject currentItem=new updateDataObject();

                                // storing values of the article object properties
                                String author=article.getString("author");
                                String title=article.getString("title");
                                String description=article.getString("description");
                                String url=article.getString("url");
                                String urlToImage=article.getString("urlToImage");
                                String publishedAt=article.getString("publishedAt");
                                String content=article.getString("content");

                                currentItem.setTitle(title);
                                currentItem.setTextShortContent(description);
                                //currentItem.setDateCreated("");
                                currentItem.setCoverImageUrl(urlToImage);
                                currentItem.setHtmlContent(url);
                                currentItem.setWebApiExternalContent(true);

                                printd(TAG,"news : "+urlToImage);
                                if(urlToImage.equals("null") || urlToImage==null){
                                    currentItem.setType(0);
                                }else{
                                    currentItem.setType(1);
                                }

                                if(description.equals("null")){
                                    currentItem.setTextShortContent("");
                                }
                                // adding an article to the articles List
                                mApiNewsList.add(currentItem);
                            }

                            // setting the adapter
                            //genericDataObjectAdapter=new GenericDataObjectAdapter(getApplicationContext(),mApiNewsList,false);
                            //mRecyclerView.setAdapter(genericDataObjectAdapter);
                            if(mDataList.size()!=0){
                                // add nes from api if available
                                for(updateDataObject apiObject:mApiNewsList){
                                    if(!mDataList.contains(apiObject)){
                                        mDataList.add(apiObject);
                                    }
                                }

                                // displaying the data
                                genericDataObjectAdapter.notifyDataSetChanged();
                            }

                        } catch (JSONException e) {
                            e.printStackTrace();
                            // logging the JSONException LogCat
                            Log.d(TAG,"Error : "+e.getMessage());
                        }

                    }
                    @Override
                    public void onError(ANError error) {
                        // logging the error detail and response to LogCat
                        Log.d(TAG,"Error detail : "+error.getErrorDetail());
                        Log.d(TAG,"Error response : "+error.getResponse());
                    }
                });
    }




    /* Laods data from the fb realtime database */
    private void loadDataFromRealTimeDB(){
        // Write a message to the database
        FirebaseDatabase database = FirebaseDatabase.getInstance();
        DatabaseReference myRef = database.getReference(REALTIME_DB_WEATHER_NEWS);
        mDataList=new ArrayList<>();

        // Read from the database
        myRef.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(DataSnapshot dataSnapshot) {
                // This method is called once with the initial value and again
                // whenever data at this location is updated.
                //String value = dataSnapshot.getValue(String.class);
                printd(TAG, "data retrieved here bibido: ");
                for(DataSnapshot snapshot1:dataSnapshot.getChildren()){
                    //fileModel currentFile=snapshot1.getValue(fileModel.class);
                    updateDataObject currentObject=snapshot1.getValue(updateDataObject.class);

                    //printd(TAG,"tit : "+currentObject.getTitle());
                   // printd(TAG,"time : "+convertTimestampToDate(currentObject.getDateCreated()));
                    mDataList.add(currentObject);
                }
                Collections.reverse(mDataList);

                // add nes from api if available
                for(updateDataObject apiObject:mApiNewsList){
                    if(!mDataList.contains(apiObject)){
                        mDataList.add(apiObject);
                    }
                }

                // displaying the data
                genericDataObjectAdapter=new GenericDataObjectAdapter(getApplicationContext(),mDataList,false);
                mRecyclerView.setAdapter(genericDataObjectAdapter);

            }

            @Override
            public void onCancelled(DatabaseError error) {
                // Failed to read value
                printd(TAG, "Failed to read value."+error.toException());
            }
        });
    }

    private void showLoadingSkeleton(){
        itemsListSkeleton = SkeletonLayoutUtils.applySkeleton(mRecyclerView, R.layout.data_object_skeleton_item,8);
        itemsListSkeleton.setShimmerDurationInMillis(SHIMMER_DURATION);
        itemsListSkeleton.setShimmerAngle(SHIMMER_ANGLE);
        itemsListSkeleton.showSkeleton();
    }


}//end of WeatherNewsActivity