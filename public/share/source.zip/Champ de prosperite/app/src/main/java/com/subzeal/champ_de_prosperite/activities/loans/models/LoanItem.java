package com.subzeal.champ_de_prosperite.activities.loans.models;

import android.os.Parcel;
import android.os.Parcelable;

public class LoanItem implements  Parcelable{
    private String amount;
    private  String interest_rate;
    private String duration;
    private String description;

    // Applicant details ici
    private String surname;
    private String first_name;
    private String willaya;
    private String phone_number;
    private String id;

    public LoanItem() {
        this.amount = "";
        this.interest_rate = "";
        this.duration = "";
        this.description = "";
        this.surname = "";
        this.first_name = "";
        this.willaya = "";
        this.phone_number = "";
        this.id="";
    }

    protected LoanItem(Parcel in) {
        amount = in.readString();
        interest_rate = in.readString();
        duration = in.readString();
        description = in.readString();
        surname = in.readString();
        first_name = in.readString();
        willaya = in.readString();
        phone_number = in.readString();
        id = in.readString();
    }

    public static final Creator<LoanItem> CREATOR = new Creator<LoanItem>() {
        @Override
        public LoanItem createFromParcel(Parcel in) {
            return new LoanItem(in);
        }

        @Override
        public LoanItem[] newArray(int size) {
            return new LoanItem[size];
        }
    };

    public String getAmount() {
        return amount;
    }

    public void setAmount(String amount) {
        this.amount = amount;
    }

    public String getInterest_rate() {
        return interest_rate;
    }

    public void setInterest_rate(String interest_rate) {
        this.interest_rate = interest_rate;
    }

    public String getDuration() {
        return duration;
    }

    public void setDuration(String duration) {
        this.duration = duration;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public String getSurname() {
        return surname;
    }

    public void setSurname(String surname) {
        this.surname = surname;
    }

    public String getFirst_name() {
        return first_name;
    }

    public void setFirst_name(String first_name) {
        this.first_name = first_name;
    }

    public String getWillaya() {
        return willaya;
    }

    public void setWillaya(String willaya) {
        this.willaya = willaya;
    }

    public String getPhone_number() {
        return phone_number;
    }

    public void setPhone_number(String phone_number) {
        this.phone_number = phone_number;
    }

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    @Override
    public int describeContents() {
        return 0;
    }

    @Override
    public void writeToParcel(Parcel dest, int flags) {
        dest.writeString(amount);
        dest.writeString(interest_rate);
        dest.writeString(duration);
        dest.writeString(description);
        dest.writeString(surname);
        dest.writeString(first_name);
        dest.writeString(willaya);
        dest.writeString(phone_number);
        dest.writeString(id);
    }
}// end of Loan Item
