package com.subzeal.champ_de_prosperite.activities.farm_activities.treatments.models;

import android.os.Parcel;
import android.os.Parcelable;

public class TreatmentItem implements Parcelable {
    int id;
    String treatmentDate;
    String treatmentName;
    String treatmentField;

    protected TreatmentItem(Parcel in) {
        id = in.readInt();
        treatmentDate = in.readString();
        treatmentName = in.readString();
        treatmentField = in.readString();
        treatmentNotes = in.readString();
    }

    @Override
    public void writeToParcel(Parcel dest, int flags) {
        dest.writeInt(id);
        dest.writeString(treatmentDate);
        dest.writeString(treatmentName);
        dest.writeString(treatmentField);
        dest.writeString(treatmentNotes);
    }

    @Override
    public int describeContents() {
        return 0;
    }

    public static final Creator<TreatmentItem> CREATOR = new Creator<TreatmentItem>() {
        @Override
        public TreatmentItem createFromParcel(Parcel in) {
            return new TreatmentItem(in);
        }

        @Override
        public TreatmentItem[] newArray(int size) {
            return new TreatmentItem[size];
        }
    };

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    String treatmentNotes;

    public TreatmentItem(){};

    public String getTreatmentDate() {
        return treatmentDate;
    }

    public void setTreatmentDate(String treatmentDate) {
        this.treatmentDate = treatmentDate;
    }

    public String getTreatmentName() {
        return treatmentName;
    }

    public void setTreatmentName(String treatmentName) {
        this.treatmentName = treatmentName;
    }

    public String getTreatmentField() {
        return treatmentField;
    }

    public void setTreatmentField(String treatmentField) {
        this.treatmentField = treatmentField;
    }

    public String getTreatmentNotes() {
        return treatmentNotes;
    }

    public void setTreatmentNotes(String treatmentNotes) {
        this.treatmentNotes = treatmentNotes;
    }
}
