package com.subzeal.champ_de_prosperite.activities.crop_schedule.adapters;

import static com.subzeal.champ_de_prosperite.activities.auth_and_language.LanguageSelectionActivity.ENGLISH_CODE;
import static com.subzeal.champ_de_prosperite.activities.auth_and_language.LanguageSelectionActivity.FRENCH_CODE;
import static com.subzeal.champ_de_prosperite.activities.auth_and_language.LanguageSelectionActivity.NDEBELE_CODE;
import static com.subzeal.champ_de_prosperite.activities.auth_and_language.LanguageSelectionActivity.SHONA_CODE;
import static com.subzeal.champ_de_prosperite.activities.inventory.util.function_util.getInventoryItemSvg;

import android.content.Context;
import android.content.Intent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.subzeal.champ_de_prosperite.R;
import com.subzeal.champ_de_prosperite.activities.crop_schedule.CropActivity;
import com.subzeal.champ_de_prosperite.activities.crop_schedule.model.CropItem;
import com.subzeal.champ_de_prosperite.local_auth.SharedPreferencesAuth;
import com.subzeal.champ_de_prosperite.models.InventoryItemType;

import java.util.ArrayList;

public class CropAdapter extends RecyclerView.Adapter<CropAdapter.ViewHolder>{
    public static String INTENT_KEY_PASS_CROP_ITEM_TO_CROP_VIEW="pass_crop_item_to_crop_view_jdh72dy7y7dy7d";
    private Context mContext;
    private ArrayList<CropItem> mList;
    private SharedPreferencesAuth sharedPreferencesAuth;

    public CropAdapter(Context c,ArrayList<CropItem> listo,SharedPreferencesAuth sharedPreferencesAuth){
        this.mContext=c;
        this.mList=listo;
        this.sharedPreferencesAuth=sharedPreferencesAuth;
    };//

    @NonNull
    @Override
    public ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view= LayoutInflater.from(mContext).inflate(R.layout.crop_item,parent,false);
        return new ViewHolder(view);
    }// end of onCreateViewHolder

    @Override
    public void onBindViewHolder(@NonNull ViewHolder holder, int position) {
        CropItem cropItem=mList.get(position);

        String currentlang=sharedPreferencesAuth.getAppLanguage();

        // setting the data
        if(currentlang.equals(ENGLISH_CODE)){
            holder.cropNametxt.setText(cropItem.getCropName());
        }
        // shona title
        if(currentlang.equals(SHONA_CODE)){
            holder.cropNametxt.setText(cropItem.getCropName_sn());
        }

        // ndebele title
        if(currentlang.equals(NDEBELE_CODE)){
            holder.cropNametxt.setText(cropItem.getCropName_nd());
        }

        // french title
        if(currentlang.equals(FRENCH_CODE)){
            holder.cropNametxt.setText(cropItem.getCropName_fr());
        }

        String itemName=cropItem.getCropName().toLowerCase();
        InventoryItemType invItemType=getInventoryItemSvg(itemName);

        if(invItemType.getIconSvg()!=-1){
            holder.cropImg.setImageResource(invItemType.getIconSvg());
        }else{
            holder.cropImg.setVisibility(View.INVISIBLE);
        }

        // handling click event of the article
        holder.itemView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(mContext, CropActivity.class);
                intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                intent.putExtra(INTENT_KEY_PASS_CROP_ITEM_TO_CROP_VIEW,cropItem);
                // starting an Activity to display the page of the article
                mContext.startActivity(intent);
            }
        });

    }//end of onBindViewHolder

    @Override
    public int getItemCount() {
        return mList.size();
    }

    public class ViewHolder extends RecyclerView.ViewHolder{
        private TextView cropNametxt;
        private ImageView cropImg;
        public ViewHolder(@NonNull View itemView) {
            super(itemView);
            cropNametxt=itemView.findViewById(R.id.crop_name_id);
            cropImg=itemView.findViewById(R.id.crop_svg_id);
        }
    }//end of ViewHolder
}
