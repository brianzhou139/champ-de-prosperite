package com.subzeal.champ_de_prosperite.activities.farm_activities.harvests.adapters;

import android.content.Context;
import android.content.Intent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.subzeal.champ_de_prosperite.R;
import com.subzeal.champ_de_prosperite.activities.farm_activities.harvests.EditHarvestActivity;
import com.subzeal.champ_de_prosperite.activities.farm_activities.harvests.models.HarvestItem;

import java.util.ArrayList;

public class HarvestsAdapter extends RecyclerView.Adapter<HarvestsAdapter.ViewHolder>{
    public static String INTENT_KEY_PASS_HARVEST_ITEM="pass_harvest_item_to_editor_jxnt26td8ygxtgd";
    private ArrayList<HarvestItem> harvestItemArrayList;
    private Context context;

    public HarvestsAdapter(Context context,ArrayList<HarvestItem> harvestItems){
        this.context=context;
        this.harvestItemArrayList=harvestItems;
    };

    @NonNull
    @Override
    public ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view= LayoutInflater.from(context).inflate(R.layout.harvesting_item,parent,false);
        return new ViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull ViewHolder holder, int position) {
        HarvestItem harvestItem=harvestItemArrayList.get(position);
        holder.harvestItemNameTxt.setText(harvestItem.getHarvestName());
        holder.harvestQuantityTxt.setText(harvestItem.getQuantityHarvested()+"");
        holder.harvestDateTxt.setText(harvestItem.getHarvestDate());
        holder.harvestNotesTxt.setText(harvestItem.getNotes());
        holder.harvestFieldNameTxt.setText(harvestItem.getNameOfField());
        holder.harvestIncomeTxt.setText(harvestItem.getIncome()+"");

        holder.itemView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(context, EditHarvestActivity.class);
                intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                intent.putExtra(INTENT_KEY_PASS_HARVEST_ITEM,harvestItem);
                // starting an Activity to display the page of the article
                context.startActivity(intent);
            }
        });


    }

    @Override
    public int getItemCount() {
        return harvestItemArrayList.size();
    }

    public class ViewHolder extends RecyclerView.ViewHolder{
        private TextView harvestDateTxt,
                harvestItemNameTxt,
                harvestQuantityTxt,
                harvestFieldNameTxt,harvestNotesTxt;
        private TextView harvestIncomeTxt;
        public ViewHolder(@NonNull View itemView) {
            super(itemView);
            harvestDateTxt=itemView.findViewById(R.id.harvest_date_id);
            harvestItemNameTxt=itemView.findViewById(R.id.harvest_iten_name_id);
            harvestQuantityTxt=itemView.findViewById(R.id.harvest_quantity_id);
            harvestFieldNameTxt=itemView.findViewById(R.id.harvest_field_name_id);
            harvestNotesTxt=itemView.findViewById(R.id.harvests_notes_id);
            harvestIncomeTxt=itemView.findViewById(R.id.harvest_income_id);
        }
    }//end of ViewHolder
}
