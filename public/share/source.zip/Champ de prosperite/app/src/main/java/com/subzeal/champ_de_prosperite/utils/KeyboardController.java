package com.subzeal.champ_de_prosperite.utils;

import android.app.Activity;
import android.content.Context;
import android.util.Log;
import android.view.inputmethod.InputMethodManager;

public class KeyboardController {
    private static  String TAG="Keyboard";
    private Activity mActivity;
    public KeyboardController(Activity activity){
        this.mActivity=activity;
    }

    public void closeKeyboard() {
        InputMethodManager inputManager = (InputMethodManager)mActivity.getSystemService(Context.INPUT_METHOD_SERVICE);
        try{
            inputManager.hideSoftInputFromWindow(mActivity.getCurrentFocus().getWindowToken(), InputMethodManager.HIDE_NOT_ALWAYS);
        }catch (Exception e){
            Log.d(TAG,"Error +"+e.getMessage());
        }

    }

    public void openKeyboard() {
        InputMethodManager imm = (InputMethodManager)mActivity.getSystemService(Context.INPUT_METHOD_SERVICE);
        if(imm != null){
            imm.toggleSoftInput(InputMethodManager.SHOW_IMPLICIT, 0);
        }
    }
}
