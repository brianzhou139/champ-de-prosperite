package com.subzeal.champ_de_prosperite.activities.crop_schedule.data;


import com.subzeal.champ_de_prosperite.activities.crop_schedule.model.CropItem;

import java.util.ArrayList;

public class CropsData {
    public static ArrayList<CropItem> getCropsListData(){
        ArrayList<CropItem> cropItems=new ArrayList<>();

        CropItem c9 = new CropItem();
        c9.setCropName("Wheat");
        c9.setCropName_sn("Wheat");
        c9.setCropName_nd("Wheat");
        c9.setCropName_fr("Blé");

        CropItem c1 = new CropItem();
        c1.setCropName("Maize");
        c1.setCropName_sn("Chibage");
        c1.setCropName_nd("Umumbu");
        c1.setCropName_fr("Maïs");

        CropItem c2 = new CropItem();
        c2.setCropName("Cotton");
        c2.setCropName_sn("Donje");
        c2.setCropName_nd("Ukotini");
        c2.setCropName_fr("Coton");

        CropItem c3 = new CropItem();
        c3.setCropName("SunFlower");
        c3.setCropName_sn("SunFlower");
        c3.setCropName_nd("Ubhekilanga");
        c3.setCropName_fr("Tournesol");

        CropItem c4 = new CropItem();
        c4.setCropName("Ground Nuts");
        c4.setCropName_sn("Nzungu");
        c4.setCropName_nd("Amazambane");
        c4.setCropName_fr("Arachides");

        cropItems.add(c9);
        cropItems.add(c1);
        cropItems.add(c2);
        cropItems.add(c3);
        cropItems.add(c4);
        return cropItems;
    }// end of getCropsListData


}
