package com.subzeal.champ_de_prosperite.activities.farm_activities.treatments.local_db;

import android.provider.BaseColumns;

public class TreatmentContract {
    public static final class TreatmentEntry implements BaseColumns {
        // Table Name
        public static final String TABLE_NAME = "treatments";
        // Columns
        public static final String _ID = BaseColumns._ID;
        public static final String COLUMN_TREATMENT_DATE= "Date";
        public static final String COLUMN_TREATMENT_NAME = "TreatmentName";
        public static final String COLUMN_TREATMENT_FIELD= "Field";
        public static final String COLUMN_TREATMENT_NOTES = "Notes";

    }// end of NationEntry

}//end of TreatmentContract
