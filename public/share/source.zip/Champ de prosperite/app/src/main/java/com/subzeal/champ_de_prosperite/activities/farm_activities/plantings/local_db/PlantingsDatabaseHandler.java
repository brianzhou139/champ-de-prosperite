package com.subzeal.champ_de_prosperite.activities.farm_activities.plantings.local_db;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.util.Log;

import com.subzeal.champ_de_prosperite.activities.farm_activities.plantings.models.PlantItem;

import java.util.ArrayList;
import java.util.Collections;

public class PlantingsDatabaseHandler {
    private static String TAG="PlantingsDatabaseHandler";
    private Context context;
    private SQLiteDatabase database;
    private PlantingsDBHelper plantingsDBHelper;

    public PlantingsDatabaseHandler(Context context){
        this.context=context;
        plantingsDBHelper=new PlantingsDBHelper(context);
        database=plantingsDBHelper.getWritableDatabase();
    };//end of InventoryDatabaseHandler

    public void insertPlantingItem(PlantItem item){
        ContentValues contentValues=new ContentValues();

        contentValues.put(PlantingsContract.PlantingsEntry.COLUMN_PLANT_NAME,item.getPlantName());
        contentValues.put(PlantingsContract.PlantingsEntry.COLUMN_PLANTING_DATE,item.getPlantDate());
        contentValues.put(PlantingsContract.PlantingsEntry.COLUMN_NAME_OF_FIELD,item.getNameOfField());
        contentValues.put(PlantingsContract.PlantingsEntry.COLUMN_NOTES,item.getNotes());
        contentValues.put(PlantingsContract.PlantingsEntry.COLUMN_QUANTITY_PLANTED,item.getQuantityPlanted());

        long rowID = database.insert(PlantingsContract.PlantingsEntry.TABLE_NAME,null,contentValues);
        Log.i(TAG, "Number of rows updated: " + rowID);
    }//end of insertData

    public void updatePlantInfor(PlantItem item) {
        String selection = PlantingsContract.PlantingsEntry._ID + " = ?";
        String[] selectionArgs = {String.valueOf(item.getId())};

        ContentValues contentValues = new ContentValues();
        contentValues.put(PlantingsContract.PlantingsEntry.COLUMN_PLANT_NAME,item.getPlantName());
        contentValues.put(PlantingsContract.PlantingsEntry.COLUMN_PLANTING_DATE,item.getPlantDate());
        contentValues.put(PlantingsContract.PlantingsEntry.COLUMN_NAME_OF_FIELD,item.getNameOfField());
        contentValues.put(PlantingsContract.PlantingsEntry.COLUMN_NOTES,item.getNotes());
        contentValues.put(PlantingsContract.PlantingsEntry.COLUMN_QUANTITY_PLANTED,item.getQuantityPlanted());

        int rowsUpdated = database.update(PlantingsContract.PlantingsEntry.TABLE_NAME, contentValues, selection, selectionArgs);
        Log.i(TAG, "Number of rows updated: " + rowsUpdated);
    }// updateFarmerInfor


    public void deletePlanting(PlantItem item) {
        String selection = PlantingsContract.PlantingsEntry._ID + " = ? ";
        String[] selectionArgs = {String.valueOf(item.getId())};		// WHERE country = "Japan"

        int rowsDeleted = database.delete(PlantingsContract.PlantingsEntry.TABLE_NAME, selection, selectionArgs);
        Log.i(TAG, "Number of rows deleted: " + rowsDeleted);
    }


    public ArrayList<PlantItem> queryPlantingsDataAndReturnIt(){
        ArrayList<PlantItem> mList=new ArrayList<>();

        String [] projection={
                PlantingsContract.PlantingsEntry._ID,
                PlantingsContract.PlantingsEntry.COLUMN_PLANT_NAME,
                PlantingsContract.PlantingsEntry.COLUMN_PLANTING_DATE,
                PlantingsContract.PlantingsEntry.COLUMN_NAME_OF_FIELD,
                PlantingsContract.PlantingsEntry.COLUMN_NOTES,
                PlantingsContract.PlantingsEntry.COLUMN_QUANTITY_PLANTED

        };

        // Filter
        String selection = null;
        String []selectionArgs = null;

        String sortOrder = null;

        Cursor cursor = database.query(PlantingsContract.PlantingsEntry.TABLE_NAME,// table sname ,
                projection,  // Columns to return
                selection,   // Selection: Where clause or the condition
                selectionArgs, //
                null, //
                null,
                sortOrder
        );

        if(cursor!=null){
            String str="";
            while(cursor.moveToNext()){  // cursor iterates through all the rows
                // Cursor iterates through all rows
                String[] columns = cursor.getColumnNames();
                PlantItem item=new PlantItem();

                // { id , country , continent }
                int id=cursor.getInt(cursor.getColumnIndex(PlantingsContract.PlantingsEntry._ID));
                String plantName=cursor.getString(cursor.getColumnIndex(PlantingsContract.PlantingsEntry.COLUMN_PLANT_NAME));
                String plantDate=cursor.getString(cursor.getColumnIndex(PlantingsContract.PlantingsEntry.COLUMN_PLANTING_DATE));
                String quantityPlanted=cursor.getString(cursor.getColumnIndex(PlantingsContract.PlantingsEntry.COLUMN_QUANTITY_PLANTED));
                String nameOfField=cursor.getString(cursor.getColumnIndex(PlantingsContract.PlantingsEntry.COLUMN_NAME_OF_FIELD));
                String notes=cursor.getString(cursor.getColumnIndex(PlantingsContract.PlantingsEntry.COLUMN_NOTES));

                item.setId(id);
                item.setPlantName(plantName);
                item.setPlantDate(plantDate);
                item.setQuantityPlanted(quantityPlanted);
                item.setNameOfField(nameOfField);
                item.setNotes(notes);
                mList.add(item);
            }
        }
        Collections.reverse(mList);
        return mList;
    }//end of insertData



}
