package com.subzeal.champ_de_prosperite.activities.farm_activities.tasks.local_db;

import static com.subzeal.champ_de_prosperite.utils.Logger.printd;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;

import com.subzeal.champ_de_prosperite.activities.farm_activities.tasks.models.TaskItem;
import com.subzeal.champ_de_prosperite.activities.farm_activities.treatments.local_db.TreatmentContract;

import java.util.ArrayList;
import java.util.Collections;

public class TaskDatabaseHandler {
    private static String TAG="TaskDatabaseHandler";
    private Context context;
    private SQLiteDatabase database;
    private TaskDBHelper taskDBHelper;

    public TaskDatabaseHandler(Context context){
        this.context=context;
        taskDBHelper=new TaskDBHelper(context);
        database=taskDBHelper.getWritableDatabase();
    };//end of InventoryDatabaseHandler

    public void insertTaskItem(TaskItem item){
        ContentValues contentValues=new ContentValues();

        contentValues.put(TaskContract.TaskEntry.COLUMN_TASK_NAME,item.getTaskName());
        contentValues.put(TaskContract.TaskEntry.COLUMN_TASK_DATE,item.getTaskDate());
        contentValues.put(TaskContract.TaskEntry.COLUMN_TASK_NOTES,item.getTaskNotes());
        contentValues.put(TaskContract.TaskEntry.COLUMN_TASK_STATUS,item.getTaskStatus());

        long rowID = database.insert(TaskContract.TaskEntry.TABLE_NAME,null,contentValues);
        printd(TAG, "Number of rows updated: " + rowID);
    }//end of insertData

    public void updateTaskInfor(TaskItem item) {
        String selection = TaskContract.TaskEntry._ID + " = ?";
        String[] selectionArgs = {String.valueOf(item.getId())};

        ContentValues contentValues = new ContentValues();
        contentValues.put(TaskContract.TaskEntry.COLUMN_TASK_NAME,item.getTaskName());
        contentValues.put(TaskContract.TaskEntry.COLUMN_TASK_DATE,item.getTaskDate());
        contentValues.put(TaskContract.TaskEntry.COLUMN_TASK_NOTES,item.getTaskNotes());
        contentValues.put(TaskContract.TaskEntry.COLUMN_TASK_STATUS,item.getTaskStatus());

        int rowsUpdated = database.update(TaskContract.TaskEntry.TABLE_NAME, contentValues, selection, selectionArgs);
        printd(TAG, "Number of rows updated: " + rowsUpdated);
    }// updateFarmerInfor

    public void deleteTaskItem(TaskItem item) {
        String selection = TaskContract.TaskEntry._ID + " = ? ";
        String[] selectionArgs = {String.valueOf(item.getId())};//

        int rowsDeleted = database.delete(TaskContract.TaskEntry.TABLE_NAME, selection, selectionArgs);
        printd(TAG, "Number of rows deleted: " + rowsDeleted);
    }

    public ArrayList<TaskItem> queryTaskDataAndReturnIt(){
        ArrayList<TaskItem> mList=new ArrayList<>();

        String [] projection={
                TaskContract.TaskEntry._ID,
                TaskContract.TaskEntry.COLUMN_TASK_NOTES,
                TaskContract.TaskEntry.COLUMN_TASK_DATE,
                TaskContract.TaskEntry.COLUMN_TASK_NAME,
                TaskContract.TaskEntry.COLUMN_TASK_STATUS,
        };

        // Filter
        String selection = null;
        String []selectionArgs = null;

        String sortOrder = null;

        Cursor cursor = database.query(TaskContract.TaskEntry.TABLE_NAME,// table sname ,
                projection,  // Columns to return
                selection,   // Selection: Where clause or the condition
                selectionArgs, //
                null, //
                null,
                sortOrder
        );

        if(cursor!=null){
            String str="";
            while(cursor.moveToNext()){  // cursor iterates through all the rows
                // Cursor iterates through all rows
                String[] columns = cursor.getColumnNames();
                TaskItem item=new TaskItem();

                // { id , country , continent }
                int id=cursor.getInt(cursor.getColumnIndex(TreatmentContract.TreatmentEntry._ID));
                String taskDate=cursor.getString(cursor.getColumnIndex(TaskContract.TaskEntry.COLUMN_TASK_DATE));
                String taskName=cursor.getString(cursor.getColumnIndex(TaskContract.TaskEntry.COLUMN_TASK_NAME));
                String taskStatus=cursor.getString(cursor.getColumnIndex(TaskContract.TaskEntry.COLUMN_TASK_STATUS));
                String taskNotes=cursor.getString(cursor.getColumnIndex(TaskContract.TaskEntry.COLUMN_TASK_NOTES));

                item.setTaskName(taskName);
                item.setTaskNotes(taskNotes);
                item.setTaskDate(taskDate);
                item.setId(id);
                item.setTaskStatus(taskStatus);

                mList.add(item);
            }
        }
        Collections.reverse(mList);
        return mList;
    }//end of insertData

} // end of TaskDatabaseHandler
