package com.subzeal.champ_de_prosperite.activities.farm_activities.tasks.adapters;

import android.content.Context;
import android.content.Intent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.subzeal.champ_de_prosperite.R;
import com.subzeal.champ_de_prosperite.activities.farm_activities.tasks.EditTaskActivity;
import com.subzeal.champ_de_prosperite.activities.farm_activities.tasks.models.TaskItem;

import java.util.ArrayList;

public class TaskAdapter extends RecyclerView.Adapter<TaskAdapter.ViewHolder>{
    public static String INTENT_KEY_PASS_TASK_TO_EDITOR="pass_task_to_editor_ds33223bhd6d872dd77dh72dh7hd";
    private ArrayList<TaskItem> mList;
    private Context context;

    public TaskAdapter(Context context,ArrayList<TaskItem> mList){
        this.context=context;
        this.mList=mList;
    };

    @NonNull
    @Override
    public ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view= LayoutInflater.from(context).inflate(R.layout.task_item,parent,false);
        return new ViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull ViewHolder holder, int position) {
        TaskItem taskItem=mList.get(position);

        holder.taskNameTxt.setText(taskItem.getTaskName());
        holder.taskNotesTxt.setText(taskItem.getTaskNotes());
        holder.taskDateTxt.setText(taskItem.getTaskDate());
        holder.taskStatusTxt.setText(taskItem.getTaskStatus());

        holder.itemView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(context, EditTaskActivity.class);
                intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                intent.putExtra(INTENT_KEY_PASS_TASK_TO_EDITOR,taskItem);
                // starting an Activity to display the page of the article
                context.startActivity(intent);
            }
        });

    }

    @Override
    public int getItemCount() {
        return mList.size();
    }

    public class ViewHolder extends RecyclerView.ViewHolder{
        TextView taskNameTxt,taskDateTxt,taskStatusTxt,taskNotesTxt;
        public ViewHolder(@NonNull View itemView) {
            super(itemView);
            taskDateTxt=itemView.findViewById(R.id.task_date_id);
            taskNameTxt=itemView.findViewById(R.id.task_item_name_id);
            taskStatusTxt=itemView.findViewById(R.id.task_status_name_id);
            taskNotesTxt=itemView.findViewById(R.id.task_notes_id);

        }
    }
}
