package com.subzeal.champ_de_prosperite.activities.announcements;

import static com.subzeal.champ_de_prosperite.constants.activity_constants.INTENT_KEY_PASS_ANNOUNCEMENTS_TO_DISPLAYER;
import static com.subzeal.champ_de_prosperite.constants.app_constants.SHIMMER_ANGLE;
import static com.subzeal.champ_de_prosperite.constants.app_constants.SHIMMER_DURATION;
import static com.subzeal.champ_de_prosperite.constants.firebase_constants.REALTIME_DB_ANNOUNCEMENTS;
import static com.subzeal.champ_de_prosperite.utils.Logger.printd;

import androidx.appcompat.app.ActionBar;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.os.Bundle;

import com.faltenreich.skeletonlayout.Skeleton;
import com.faltenreich.skeletonlayout.SkeletonLayoutUtils;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;
import com.subzeal.champ_de_prosperite.R;
import com.subzeal.champ_de_prosperite.adapters.AnnouncementsAdapter;
import com.subzeal.champ_de_prosperite.local_auth.SharedPreferencesAuth;
import com.subzeal.champ_de_prosperite.models.announcementModel;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

public class AnnouncementsListActivity extends AppCompatActivity {
    private static String TAG="AnnouncementsListActivity";
    private RecyclerView mRecyclerView;

    // declaring an ArrayList of articles
    private List<announcementModel> mDataList;
    private AnnouncementsAdapter announcementsAdapter;
    // views (skeletons)
    private Skeleton itemsListSkeleton;

    private SharedPreferencesAuth sharedPreferencesAuth;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        sharedPreferencesAuth=new SharedPreferencesAuth(this);

        setContentView(R.layout.activity_announcements_list);
        // ActionBar and its title
        ActionBar actionBar=getSupportActionBar();
        actionBar.setTitle(getResources().getString(R.string.announcements_label));

        // enable back button
        actionBar.setDisplayHomeAsUpEnabled(true);
        actionBar.setHomeButtonEnabled(true);

        mRecyclerView=(RecyclerView)findViewById(R.id.recyclerview_id);
        // setting the recyclerview layout manager
        mRecyclerView.setLayoutManager(new LinearLayoutManager(this));
        itemsListSkeleton = findViewById(R.id.file_items_skeleton_Layout_id);

        //INTENT_KEY_PASS_ANNOUNCEMENTS_TO_DISPLAYER
        mDataList=new ArrayList<>();

        Bundle extras = getIntent().getExtras();
        if (extras != null) {
            //currentFile = (Paper)getIntent().getSerializableExtra(PAPER_TO_FILEVIEW_DATA_KEY); //Obtaining data
            mDataList=getIntent().getParcelableArrayListExtra(INTENT_KEY_PASS_ANNOUNCEMENTS_TO_DISPLAYER);
            fillData();
        }

        if(extras==null){
            //Toast.makeText(this, "extras is null", Toast.LENGTH_SHORT).show();
            showLoadingSkeleton();
            loadNotificationsFromRealTimeDB();
        }

    }//end of onCreate

    private void fillData(){
        // setting the adapter
        announcementsAdapter=new AnnouncementsAdapter(this,mDataList);
        mRecyclerView.setAdapter(announcementsAdapter);
    }

    private void showLoadingSkeleton(){
        itemsListSkeleton = SkeletonLayoutUtils.applySkeleton(mRecyclerView, R.layout.data_object_skeleton_item,8);
        itemsListSkeleton.setShimmerDurationInMillis(SHIMMER_DURATION);
        itemsListSkeleton.setShimmerAngle(SHIMMER_ANGLE);
        itemsListSkeleton.showSkeleton();
    }

    /* Laods data from the fb realtime database */
    private void loadNotificationsFromRealTimeDB(){
        // Write a message to the database
        FirebaseDatabase database = FirebaseDatabase.getInstance();
        DatabaseReference myRef = database.getReference(REALTIME_DB_ANNOUNCEMENTS);
        mDataList=new ArrayList<>();

        // Read from the database
        myRef.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(DataSnapshot dataSnapshot) {
                // This method is called once with the initial value and again
                // whenever data at this location is updated.
                //String value = dataSnapshot.getValue(String.class);
                printd(TAG, "data retrieved here bibido: ");
                for(DataSnapshot snapshot1:dataSnapshot.getChildren()){
                    //fileModel currentFile=snapshot1.getValue(fileModel.class);
                    announcementModel announcement=snapshot1.getValue(announcementModel.class);

                    printd(TAG,"tit : "+announcement.getTitle());
                    mDataList.add(announcement);
                }
                Collections.reverse(mDataList);
                fillData();
            }

            @Override
            public void onCancelled(DatabaseError error) {
                // Failed to read value
                printd(TAG, "Failed to read value."+error.toException());
            }
        });
    }


}//end of AnnouncementsActivity