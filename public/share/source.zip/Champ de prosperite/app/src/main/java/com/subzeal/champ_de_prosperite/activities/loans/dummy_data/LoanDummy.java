package com.subzeal.champ_de_prosperite.activities.loans.dummy_data;

import com.subzeal.champ_de_prosperite.activities.loans.models.LoanItem;

import java.util.ArrayList;

public class LoanDummy {

    public static ArrayList<LoanItem> getDummyLoansList(){
        ArrayList<LoanItem> loanItems = new ArrayList<>();

        LoanItem item1 = new LoanItem();
        item1.setAmount("300 000");
        item1.setDuration("6 mois");
        item1.setInterest_rate("4.5%");

        LoanItem item2 = new LoanItem();
        item2.setAmount("700 000");
        item2.setDuration("1 an");
        item2.setInterest_rate("5%");

        LoanItem item3 = new LoanItem();
        item3.setAmount("1 000 000");
        item3.setDuration("1 an");
        item3.setInterest_rate("6.5%");

        LoanItem item4 = new LoanItem();
        item4.setAmount("3 000 000");
        item4.setDuration("2 années");
        item4.setInterest_rate("7.5%");

        loanItems.add(item1);
        loanItems.add(item2);
        loanItems.add(item3);
        loanItems.add(item4);
        return loanItems;
    }// end of getLoansList

}// end of LoanDummy
