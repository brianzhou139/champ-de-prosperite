package com.subzeal.champ_de_prosperite.activities.farm_activities.treatments;

import static com.subzeal.champ_de_prosperite.utils.Logger.printd;
import static com.subzeal.champ_de_prosperite.utils.UtilFunctions.getMonthFromInt;

import androidx.appcompat.app.ActionBar;
import androidx.appcompat.app.AppCompatActivity;

import android.app.DatePickerDialog;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.DatePicker;
import android.widget.Toast;

import com.google.android.material.textfield.TextInputEditText;
import com.google.gson.Gson;
import com.subzeal.champ_de_prosperite.R;
import com.subzeal.champ_de_prosperite.activities.farm_activities.treatments.local_db.TreatmentDatabaseHandler;
import com.subzeal.champ_de_prosperite.activities.farm_activities.treatments.models.TreatmentItem;
import com.subzeal.champ_de_prosperite.local_auth.SharedPreferencesAuth;
import com.subzeal.champ_de_prosperite.utils.KeyboardController;

import java.util.Calendar;

public class AddTreatmentActivity extends AppCompatActivity {
    private static String TAG="AddTreatmentActivity";
    private TextInputEditText plantingDateEdt;
    String iyear=null;
    int imonth=0;
    String iday=null;
    private boolean dateIsSet=false;

    private TextInputEditText treatmentDateEdt,
            treatmentNameEdt,treatmentFieldEdt,
            treatmentNotesEdt;

    private KeyboardController keyboardController;
    private TreatmentDatabaseHandler treatmentDatabaseHandler;

    private SharedPreferencesAuth sharedPreferencesAuth;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        sharedPreferencesAuth=new SharedPreferencesAuth(this);

        setContentView(R.layout.activity_add_treatment);
        treatmentDatabaseHandler=new TreatmentDatabaseHandler(this);
        keyboardController=new KeyboardController(this);

        // ActionBar and its title
        ActionBar actionBar=getSupportActionBar();
        actionBar.setTitle(getResources().getString(R.string.new_treatment_label));

        // enable back button
        actionBar.setDisplayHomeAsUpEnabled(true);
        actionBar.setHomeButtonEnabled(true);

        treatmentDateEdt=findViewById(R.id.treatment_date_id);
        treatmentNameEdt=findViewById(R.id.treatment_name_id);
        treatmentFieldEdt=findViewById(R.id.treatment_name_of_field_id);
        treatmentNotesEdt=findViewById(R.id.treatment_short_notes_id);

        // listed to date clicks
        treatmentDateEdt.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                //Toast.makeText(getApplicationContext(),"planting date clicked",Toast.LENGTH_SHORT).show();
                final Calendar newCalender=Calendar.getInstance();

                DatePickerDialog dialog=new DatePickerDialog(AddTreatmentActivity.this, new DatePickerDialog.OnDateSetListener() {
                    @Override
                    public void onDateSet(DatePicker view, int year, int month, int dayOfMonth) {
                        iyear=year+"";
                        imonth=month;
                        iday=dayOfMonth+"";
                        printd(TAG,"day : "+dayOfMonth);
                        printd(TAG,"month : "+month);
                        printd(TAG,"year : "+year);
                        dateIsSet=true;
                        treatmentDateEdt.setText(dayOfMonth+"/"+month+"/"+year);
                    }
                },newCalender.get(Calendar.YEAR),newCalender.get(Calendar.MONTH),newCalender.get(Calendar.DAY_OF_MONTH));

                dialog.show();
            }
        });


    }//end of onCreate

    private void saveDataAndClose(){
        if(!dateIsSet){
            Toast.makeText(AddTreatmentActivity.this, getResources().getString(R.string.plantings_select_the_date), Toast.LENGTH_SHORT).show();
            return;
        }
        String treatmentDate=iday+" "+getMonthFromInt(imonth)+", "+iyear;
        String treatmentName=treatmentNameEdt.getText().toString().trim();
        String treatmentField=treatmentFieldEdt.getText().toString().trim();
        String treatmentNotes=treatmentNotesEdt.getText().toString().trim();

        // check for empty fields
        if(treatmentName.length()==0){
            Toast.makeText(AddTreatmentActivity.this, getResources().getString(R.string.treatments_provide_the_name_of_treatment), Toast.LENGTH_SHORT).show();
            return;
        }

        // remote
        keyboardController.closeKeyboard();

        // Treatment item
        TreatmentItem newTreatmentItem=new TreatmentItem();
        newTreatmentItem.setTreatmentDate(treatmentDate);
        newTreatmentItem.setTreatmentName(treatmentName);
        newTreatmentItem.setTreatmentNotes(treatmentNotes);
        newTreatmentItem.setTreatmentField(treatmentField);

        Gson gson = new Gson();
        printd(TAG,""+ gson.toJson(newTreatmentItem));

        //harvestsDatabasehandler.insertHarvestedItem(harvestItem);
        treatmentDatabaseHandler.insertTreatmentItem(newTreatmentItem);
        // finish activity
        finish();
    }


    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.farm_activities_add_menu, menu);
        return super.onCreateOptionsMenu(menu);
    }// end onCreateOptionsMenu

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        switch (item.getItemId()) {
            case R.id.action_save:
                // User chose the "Settings" item, show the app settings UI...
                saveDataAndClose();
                return true;
            default:
                // If we got here, the user's action was not recognized.
                // Invoke the superclass to handle it.
                return super.onOptionsItemSelected(item);

        }
    }



}//end of AddTreatmentActivity