package com.subzeal.champ_de_prosperite.activities.farm_activities.treatments.adapters;

import android.content.Context;
import android.content.Intent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.subzeal.champ_de_prosperite.R;
import com.subzeal.champ_de_prosperite.activities.farm_activities.treatments.EditTreatmentActivity;
import com.subzeal.champ_de_prosperite.activities.farm_activities.treatments.models.TreatmentItem;

import java.util.ArrayList;

public class TreatmentAdapter extends RecyclerView.Adapter<TreatmentAdapter.ViewHolder> {
    public static String INTENT_KEY_PASS_TREATMENT_ITEM="pass_treatment_njdhjd72887dy8d728d8d2d2";
    private ArrayList<TreatmentItem> mList;
    private Context context;

    public TreatmentAdapter(Context context,ArrayList<TreatmentItem> mList){
        this.context=context;
        this.mList=mList;
    }//end of TreatmentAdapter

    @NonNull
    @Override
    public ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view= LayoutInflater.from(context).inflate(R.layout.treatment_item,parent,false);
        return new ViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull ViewHolder holder, int position) {
        TreatmentItem item=mList.get(position);
        holder.treatmentNameTxt.setText(item.getTreatmentName());
        holder.treatmentFieldTxt.setText(item.getTreatmentField());
        holder.treatmentDateTxt.setText(item.getTreatmentDate());
        holder.treatmentNotesTxt.setText(item.getTreatmentNotes());

        holder.itemView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(context, EditTreatmentActivity.class);
                intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                intent.putExtra(INTENT_KEY_PASS_TREATMENT_ITEM,item);
                // starting an Activity to display the page of the article
                context.startActivity(intent);
            }
        });
    }// onBindViewHolder

    @Override
    public int getItemCount() {
        return mList.size();
    }// end of getItemCount()

    public class ViewHolder extends RecyclerView.ViewHolder{
        private TextView treatmentDateTxt,treatmentNameTxt,treatmentFieldTxt,treatmentNotesTxt;
        public ViewHolder(@NonNull View itemView) {
            super(itemView);
            treatmentDateTxt=itemView.findViewById(R.id.treatment_date_id);
            treatmentNameTxt=itemView.findViewById(R.id.treatment_item_name_id);
            treatmentFieldTxt=itemView.findViewById(R.id.treatment_field_name_id);
            treatmentNotesTxt=itemView.findViewById(R.id.treatment_notes_id);
        }
    }
}
