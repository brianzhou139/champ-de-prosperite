package com.subzeal.champ_de_prosperite.activities.farm_activities.harvests.models;

import android.os.Parcel;
import android.os.Parcelable;

public class HarvestItem implements Parcelable {
    private int id;
    private String harvestDate;
    private String harvestName;
    private String nameOfField;
    private Double quantityHarvested;
    private String notes;
    private Double income;
    private Double unitCosts;

    public HarvestItem(){};

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getHarvestDate() {
        return harvestDate;
    }

    public void setHarvestDate(String harvestDate) {
        this.harvestDate = harvestDate;
    }

    public String getHarvestName() {
        return harvestName;
    }

    public void setHarvestName(String harvestName) {
        this.harvestName = harvestName;
    }

    public String getNameOfField() {
        return nameOfField;
    }

    public void setNameOfField(String nameOfField) {
        this.nameOfField = nameOfField;
    }

    public Double getQuantityHarvested() {
        return quantityHarvested;
    }

    public void setQuantityHarvested(Double quantityHarvested) {
        this.quantityHarvested = quantityHarvested;
    }

    public String getNotes() {
        return notes;
    }

    public void setNotes(String notes) {
        this.notes = notes;
    }

    public Double getIncome() {
        return income;
    }

    public void setIncome(Double income) {
        this.income = income;
    }

    public Double getUnitCosts() {
        return unitCosts;
    }

    public void setUnitCosts(Double unitCosts) {
        this.unitCosts = unitCosts;
    }

    protected HarvestItem(Parcel in) {
        id = in.readInt();
        harvestDate = in.readString();
        harvestName = in.readString();
        nameOfField = in.readString();
        if (in.readByte() == 0) {
            quantityHarvested = null;
        } else {
            quantityHarvested = in.readDouble();
        }
        notes = in.readString();
        if (in.readByte() == 0) {
            income = null;
        } else {
            income = in.readDouble();
        }
        if (in.readByte() == 0) {
            unitCosts = null;
        } else {
            unitCosts = in.readDouble();
        }
    }

    @Override
    public void writeToParcel(Parcel dest, int flags) {
        dest.writeInt(id);
        dest.writeString(harvestDate);
        dest.writeString(harvestName);
        dest.writeString(nameOfField);
        if (quantityHarvested == null) {
            dest.writeByte((byte) 0);
        } else {
            dest.writeByte((byte) 1);
            dest.writeDouble(quantityHarvested);
        }
        dest.writeString(notes);
        if (income == null) {
            dest.writeByte((byte) 0);
        } else {
            dest.writeByte((byte) 1);
            dest.writeDouble(income);
        }
        if (unitCosts == null) {
            dest.writeByte((byte) 0);
        } else {
            dest.writeByte((byte) 1);
            dest.writeDouble(unitCosts);
        }
    }

    @Override
    public int describeContents() {
        return 0;
    }

    public static final Creator<HarvestItem> CREATOR = new Creator<HarvestItem>() {
        @Override
        public HarvestItem createFromParcel(Parcel in) {
            return new HarvestItem(in);
        }

        @Override
        public HarvestItem[] newArray(int size) {
            return new HarvestItem[size];
        }
    };
}
