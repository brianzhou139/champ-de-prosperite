package com.subzeal.champ_de_prosperite.activities.farm_activities.harvests.local_db;
import static com.subzeal.champ_de_prosperite.utils.Logger.printd;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;

import com.subzeal.champ_de_prosperite.activities.farm_activities.harvests.models.HarvestItem;

import java.util.ArrayList;
import java.util.Collections;

public class HarvestsDatabaseHandler {
    private static String TAG="HarvestsDatabasehandler";
    private Context context;
    private SQLiteDatabase database;
    private HarvestsDBHelper harvestsDBHelper;

    public HarvestsDatabaseHandler(Context context){
        this.context=context;
        harvestsDBHelper=new HarvestsDBHelper(context);
        database=harvestsDBHelper.getWritableDatabase();
    };//end of InventoryDatabaseHandler

    public void insertHarvestedItem(HarvestItem item){
        ContentValues contentValues=new ContentValues();

        contentValues.put(HarvestsContract.HarvestsEntry.COLUMN_HARVEST_NAME,item.getHarvestName());
        contentValues.put(HarvestsContract.HarvestsEntry.COLUMN_HARVEST_DATE,item.getHarvestDate());
        contentValues.put(HarvestsContract.HarvestsEntry.COLUMN_HARVEST_NAME_OF_FIELD,item.getNameOfField());
        contentValues.put(HarvestsContract.HarvestsEntry.COLUMN_HARVEST_QUANTITY,item.getQuantityHarvested());
        contentValues.put(HarvestsContract.HarvestsEntry.COLUMN_HARVEST_INCOME,item.getIncome());
        contentValues.put(HarvestsContract.HarvestsEntry.COLUMN_HARVEST_UNIT_COSTS,item.getUnitCosts());
        contentValues.put(HarvestsContract.HarvestsEntry.COLUMN_HARVEST_NOTES,item.getNotes());

        long rowID = database.insert(HarvestsContract.HarvestsEntry.TABLE_NAME,null,contentValues);
        printd(TAG, "Number of rows updated: " + rowID);

    }//end of insertData

    public void updateHaverstInfor(HarvestItem item) {
        String selection = HarvestsContract.HarvestsEntry._ID + " = ?";
        String[] selectionArgs = {String.valueOf(item.getId())};

        ContentValues contentValues = new ContentValues();
        contentValues.put(HarvestsContract.HarvestsEntry.COLUMN_HARVEST_NAME,item.getHarvestName());
        contentValues.put(HarvestsContract.HarvestsEntry.COLUMN_HARVEST_DATE,item.getHarvestDate());
        contentValues.put(HarvestsContract.HarvestsEntry.COLUMN_HARVEST_NAME_OF_FIELD,item.getNameOfField());
        contentValues.put(HarvestsContract.HarvestsEntry.COLUMN_HARVEST_QUANTITY,item.getQuantityHarvested());
        contentValues.put(HarvestsContract.HarvestsEntry.COLUMN_HARVEST_INCOME,item.getIncome());
        contentValues.put(HarvestsContract.HarvestsEntry.COLUMN_HARVEST_UNIT_COSTS,item.getUnitCosts());
        contentValues.put(HarvestsContract.HarvestsEntry.COLUMN_HARVEST_NOTES,item.getNotes());

        int rowsUpdated = database.update(HarvestsContract.HarvestsEntry.TABLE_NAME, contentValues, selection, selectionArgs);
        printd(TAG, "Number of rows updated: " + rowsUpdated);
    }// updateFarmerInfor


    public void deleteHarvestItem(HarvestItem item) {
        String selection = HarvestsContract.HarvestsEntry._ID + " = ? ";
        String[] selectionArgs = {String.valueOf(item.getId())};		// WHERE country = "Japan"

        int rowsDeleted = database.delete(HarvestsContract.HarvestsEntry.TABLE_NAME, selection, selectionArgs);
        printd(TAG, "Number of rows deleted: " + rowsDeleted);
    }

    public ArrayList<HarvestItem> queryHarvestsDataAndReturnIt(){
        ArrayList<HarvestItem> mList=new ArrayList<>();

        String [] projection={
                HarvestsContract.HarvestsEntry._ID,
                HarvestsContract.HarvestsEntry.COLUMN_HARVEST_NAME,
                HarvestsContract.HarvestsEntry.COLUMN_HARVEST_DATE,
                HarvestsContract.HarvestsEntry.COLUMN_HARVEST_NAME_OF_FIELD,
                HarvestsContract.HarvestsEntry.COLUMN_HARVEST_QUANTITY,
                HarvestsContract.HarvestsEntry.COLUMN_HARVEST_INCOME,
                HarvestsContract.HarvestsEntry.COLUMN_HARVEST_UNIT_COSTS,
                HarvestsContract.HarvestsEntry.COLUMN_HARVEST_NOTES
        };

        // Filter
        String selection = null;
        String []selectionArgs = null;

        String sortOrder = null;

        Cursor cursor = database.query(HarvestsContract.HarvestsEntry.TABLE_NAME,// table sname ,
                projection,  // Columns to return
                selection,   // Selection: Where clause or the condition
                selectionArgs, //
                null, //
                null,
                sortOrder
        );

        if(cursor!=null){
            String str="";
            while(cursor.moveToNext()){  // cursor iterates through all the rows
                // Cursor iterates through all rows
                String[] columns = cursor.getColumnNames();
                HarvestItem item=new HarvestItem();

                // { id , country , continent }
                int id=cursor.getInt(cursor.getColumnIndex(HarvestsContract.HarvestsEntry._ID));
                String harvestName=cursor.getString(cursor.getColumnIndex(HarvestsContract.HarvestsEntry.COLUMN_HARVEST_NAME));
                String harvestDate=cursor.getString(cursor.getColumnIndex(HarvestsContract.HarvestsEntry.COLUMN_HARVEST_DATE));
                String harvestNameOfField=cursor.getString(cursor.getColumnIndex(HarvestsContract.HarvestsEntry.COLUMN_HARVEST_NAME_OF_FIELD));
                Double harvestQuantity=cursor.getDouble(cursor.getColumnIndex(HarvestsContract.HarvestsEntry.COLUMN_HARVEST_QUANTITY));
                Double harvestIncome=cursor.getDouble(cursor.getColumnIndex(HarvestsContract.HarvestsEntry.COLUMN_HARVEST_INCOME));
                Double harvestUnitCost=cursor.getDouble(cursor.getColumnIndex(HarvestsContract.HarvestsEntry.COLUMN_HARVEST_UNIT_COSTS));
                String harvestNotes=cursor.getString(cursor.getColumnIndex(HarvestsContract.HarvestsEntry.COLUMN_HARVEST_NOTES));

                item.setHarvestName(harvestName);
                item.setHarvestDate(harvestDate);
                item.setNameOfField(harvestNameOfField);
                item.setQuantityHarvested(harvestQuantity);
                item.setIncome(harvestIncome);
                item.setUnitCosts(harvestUnitCost);
                item.setNotes(harvestNotes);
                item.setId(id);

                mList.add(item);
            }
        }
        Collections.reverse(mList);
        return mList;
    }//end of insertData
}
