package com.subzeal.champ_de_prosperite.constants;

public class activity_constants {
    public static String INTENT_KEY_PASS_DATA_OBJECT="key_pass_data_object_to_display_activity_yuh3hd7d73hd37";

    public static String INTENT_KEY_PASS_ANNOUNCEMENTS_TO_DISPLAYER="key_pass_announcements_to_acitivity_for_display_jndhd7dy3y7d7";

    public static String INTENT_KEY_GO_TO_LANGUAGE_SELECTION="key_pass_go_to_language_selection_28728282677637367377";


    public static String INTENT_LOAN_TO_LOAN_APPLICATION="INTENT_LOAN_TO_LOAN_APPLICATION=uhe727ey7ye78e8e8";

}
