package com.subzeal.champ_de_prosperite.activities.crop_schedule;

import static com.subzeal.champ_de_prosperite.activities.auth_and_language.LanguageSelectionActivity.ENGLISH_CODE;
import static com.subzeal.champ_de_prosperite.activities.auth_and_language.LanguageSelectionActivity.FRENCH_CODE;
import static com.subzeal.champ_de_prosperite.activities.crop_schedule.adapters.CropAdapter.INTENT_KEY_PASS_CROP_ITEM_TO_CROP_VIEW;

import androidx.appcompat.app.ActionBar;
import androidx.appcompat.app.AppCompatActivity;

import android.os.Build;
import android.os.Bundle;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.widget.ImageView;

import com.subzeal.champ_de_prosperite.R;
import com.subzeal.champ_de_prosperite.activities.crop_schedule.model.CropItem;
import com.subzeal.champ_de_prosperite.local_auth.SharedPreferencesAuth;

public class CropActivity extends AppCompatActivity {
    private WebView webView = null;
    private CropItem cropItem=null;
    private ImageView coverImg;

    private SharedPreferencesAuth sharedPreferencesAuth;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        sharedPreferencesAuth=new SharedPreferencesAuth(this);

        setContentView(R.layout.activity_crop);
        webView = (WebView) findViewById(R.id.webview);
        // ActionBar and its title
        ActionBar actionBar=getSupportActionBar();
        actionBar.setTitle(getResources().getString(R.string.crop_schedule_label));

        // enable back button
        actionBar.setDisplayHomeAsUpEnabled(true);
        actionBar.setHomeButtonEnabled(true);


        Bundle extras = getIntent().getExtras();
        if (extras != null) {
            //currentFile = (Paper)getIntent().getSerializableExtra(PAPER_TO_FILEVIEW_DATA_KEY); //Obtaining data
            cropItem = (CropItem) getIntent().getParcelableExtra(INTENT_KEY_PASS_CROP_ITEM_TO_CROP_VIEW);
            // show related fiels
            displayWebViewData(cropItem);
        }
    }//end of onCreate
    private void displayWebViewData(CropItem cropItem) {
        String currentlang=sharedPreferencesAuth.getAppLanguage();

        webView.getSettings().setJavaScriptEnabled(true);
        webView.getSettings().setLayoutAlgorithm(WebSettings.LayoutAlgorithm.SINGLE_COLUMN);
        webView.getSettings().setDomStorageEnabled(true);
        webView.getSettings().setAllowFileAccessFromFileURLs(true);
        webView.getSettings().setAllowUniversalAccessFromFileURLs(true);

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.KITKAT)
        {
            webView.getSettings().setLayoutAlgorithm(WebSettings.LayoutAlgorithm.TEXT_AUTOSIZING);
        }
        else
        {
            webView.getSettings().setLayoutAlgorithm(WebSettings.LayoutAlgorithm.NORMAL);
        }

        // French Language
        if(currentlang.equals(FRENCH_CODE)){
            if(cropItem.getCropName().toLowerCase().trim().equals("wheat")){
                webView.loadUrl("file:///android_asset/wheat_fr.html");
            }
            if(cropItem.getCropName().toLowerCase().trim().equals("maize")){
                webView.loadUrl("file:///android_asset/maize_fr.html");
            }
            if(cropItem.getCropName().toLowerCase().trim().equals("cotton")){
                webView.loadUrl("file:///android_asset/cotton_fr.html");
            }
            if(cropItem.getCropName().toLowerCase().trim().equals("sunflower")){
                webView.loadUrl("file:///android_asset/sunflower_fr.html");
            }
            if(cropItem.getCropName().toLowerCase().trim().equals("ground nuts")){
                webView.loadUrl("file:///android_asset/groundnuts_fr.html");
            }
        }else{
            if(cropItem.getCropName().toLowerCase().trim().equals("wheat")){
                webView.loadUrl("file:///android_asset/wheat_en.html");
            }
            if(cropItem.getCropName().toLowerCase().trim().equals("maize")){
                webView.loadUrl("file:///android_asset/maize_en.html");
            }
            if(cropItem.getCropName().toLowerCase().trim().equals("cotton")){
                webView.loadUrl("file:///android_asset/cotton_en.html");
            }
            if(cropItem.getCropName().toLowerCase().trim().equals("sunflower")){
                webView.loadUrl("file:///android_asset/sunflower_en.html");
            }
            if(cropItem.getCropName().toLowerCase().trim().equals("ground nuts")){
                webView.loadUrl("file:///android_asset/groundnuts_en.html");
            }
        }


        //webView.loadUrl("file:///android_asset/zimsec.html");
        //webView.loadDataWithBaseURL(null, getHtmlData("shito_"+cropItem.getCropName()), "text/html", "utf-8", null);
    }// end of displayWebViewData
}//end of CropActivity