package com.subzeal.champ_de_prosperite.activities.market_guide;

import static com.subzeal.champ_de_prosperite.constants.app_constants.SHIMMER_ANGLE;
import static com.subzeal.champ_de_prosperite.constants.app_constants.SHIMMER_DURATION;
import static com.subzeal.champ_de_prosperite.constants.firebase_constants.REALTIME_DB_MARKET_GUIDE;
import static com.subzeal.champ_de_prosperite.utils.Logger.printd;
import static com.subzeal.champ_de_prosperite.utils.UtilFunctions.convertTimestampToDate;

import androidx.appcompat.app.ActionBar;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.os.Bundle;
import android.widget.ProgressBar;

import com.androidnetworking.AndroidNetworking;
import com.faltenreich.skeletonlayout.Skeleton;
import com.faltenreich.skeletonlayout.SkeletonLayoutUtils;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;
import com.jacksonandroidnetworking.JacksonParserFactory;
import com.subzeal.champ_de_prosperite.R;
import com.subzeal.champ_de_prosperite.adapters.GenericDataObjectAdapter;
import com.subzeal.champ_de_prosperite.local_auth.SharedPreferencesAuth;
import com.subzeal.champ_de_prosperite.models.updateDataObject;

import java.util.ArrayList;
import java.util.Collections;

public class MarketGuideListActivity extends AppCompatActivity {
    private static String TAG="MarketGuideListActivity";
    // declaring the views
    private ProgressBar mProgressBar;
    private RecyclerView mRecyclerView;

    // declaring an ArrayList of articles
    private ArrayList<updateDataObject> mDataList;

    private GenericDataObjectAdapter genericDataObjectAdapter;

    // views (skeletons)
    private Skeleton itemsListSkeleton;
    private SharedPreferencesAuth sharedPreferencesAuth;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        sharedPreferencesAuth=new SharedPreferencesAuth(this);
        setContentView(R.layout.activity_market_guide_list);
        // ActionBar and its title
        ActionBar actionBar=getSupportActionBar();
        actionBar.setTitle(getResources().getString(R.string.market_guide_label));

        // enable back button
        actionBar.setDisplayHomeAsUpEnabled(true);
        actionBar.setHomeButtonEnabled(true);

        //  initializing the Fast Android Networking Library
        AndroidNetworking.initialize(getApplicationContext());
        // setting the JacksonParserFactory
        AndroidNetworking.setParserFactory(new JacksonParserFactory());
        mRecyclerView=(RecyclerView)findViewById(R.id.recyclerview_id);
        // setting the recyclerview layout manager
        mRecyclerView.setLayoutManager(new LinearLayoutManager(this));
        //mRecyclerView.setHasFixedSize(false);
        itemsListSkeleton = findViewById(R.id.file_items_skeleton_Layout_id);

        // show loading skeleton
        showLoadingSkeleton();

        loadDataFromRealTimeDB();
    }//end onCreate


    /* Laods data from the fb realtime database */
    private void loadDataFromRealTimeDB(){
        // Write a message to the database
        FirebaseDatabase database = FirebaseDatabase.getInstance();
        DatabaseReference myRef = database.getReference(REALTIME_DB_MARKET_GUIDE);
        mDataList=new ArrayList<>();

        // Read from the database
        myRef.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(DataSnapshot dataSnapshot) {
                // This method is called once with the initial value and again
                // whenever data at this location is updated.
                //String value = dataSnapshot.getValue(String.class);
                printd(TAG, "data retrieved here bibido: ");
                for(DataSnapshot snapshot1:dataSnapshot.getChildren()){
                    //fileModel currentFile=snapshot1.getValue(fileModel.class);
                    updateDataObject currentObject=snapshot1.getValue(updateDataObject.class);

                    printd(TAG,"tit : "+currentObject.getTitle());
                    printd(TAG,"time : "+convertTimestampToDate(currentObject.getDateCreated()));
                    mDataList.add(currentObject);
                }
                Collections.reverse(mDataList);

                // displaying the data
                genericDataObjectAdapter=new GenericDataObjectAdapter(getApplicationContext(),mDataList,false);
                mRecyclerView.setAdapter(genericDataObjectAdapter);

            }

            @Override
            public void onCancelled(DatabaseError error) {
                // Failed to read value
                printd(TAG, "Failed to read value."+error.toException());
            }
        });
    }

    private void showLoadingSkeleton(){
        itemsListSkeleton = SkeletonLayoutUtils.applySkeleton(mRecyclerView, R.layout.data_object_skeleton_item,8);
        itemsListSkeleton.setShimmerDurationInMillis(SHIMMER_DURATION);
        itemsListSkeleton.setShimmerAngle(SHIMMER_ANGLE);
        itemsListSkeleton.showSkeleton();
    }

}//end of MarketGuideActivity