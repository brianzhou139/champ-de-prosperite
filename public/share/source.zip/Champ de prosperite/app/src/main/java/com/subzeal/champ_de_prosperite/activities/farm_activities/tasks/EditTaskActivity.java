package com.subzeal.champ_de_prosperite.activities.farm_activities.tasks;

import static com.subzeal.champ_de_prosperite.activities.farm_activities.tasks.adapters.TaskAdapter.INTENT_KEY_PASS_TASK_TO_EDITOR;
import static com.subzeal.champ_de_prosperite.utils.Logger.printd;
import static com.subzeal.champ_de_prosperite.utils.UtilFunctions.getMonthFromInt;

import androidx.appcompat.app.ActionBar;
import androidx.appcompat.app.AppCompatActivity;

import android.app.DatePickerDialog;
import android.os.Bundle;
import android.util.Log;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.DatePicker;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.Toast;

import com.google.android.material.textfield.TextInputEditText;
import com.google.gson.Gson;
import com.subzeal.champ_de_prosperite.R;
import com.subzeal.champ_de_prosperite.activities.farm_activities.tasks.local_db.TaskDatabaseHandler;
import com.subzeal.champ_de_prosperite.activities.farm_activities.tasks.models.TaskItem;
import com.subzeal.champ_de_prosperite.local_auth.SharedPreferencesAuth;
import com.subzeal.champ_de_prosperite.utils.KeyboardController;

import java.util.Calendar;

public class EditTaskActivity extends AppCompatActivity {
    private static String TAG="AddTaskActivity";
    String iyear=null;
    int imonth=0;
    String iday=null;
    private boolean dateIsSet=false;
    private RadioGroup radioGroup;
    private RadioButton doneRadionButt,tobeDoneradionButt;
    private String tempTaskStatus="";

    private TextInputEditText taskDateEdt,taskNameEdt,taskNoteEdt;
    private KeyboardController keyboardController;

    private TaskDatabaseHandler taskDatabaseHandler;
    private TaskItem taskItem=null;

    private SharedPreferencesAuth sharedPreferencesAuth;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        sharedPreferencesAuth=new SharedPreferencesAuth(this);

        setContentView(R.layout.activity_edit_task);
        taskDatabaseHandler=new TaskDatabaseHandler(this);
        keyboardController=new KeyboardController(this);

        // ActionBar and its title
        ActionBar actionBar=getSupportActionBar();
        actionBar.setTitle(getResources().getString(R.string.tasks_task_label));

        // enable back button
        actionBar.setDisplayHomeAsUpEnabled(true);
        actionBar.setHomeButtonEnabled(true);

        radioGroup=findViewById(R.id.radioGroup);
        doneRadionButt=findViewById(R.id.radio_button_done_id);
        tobeDoneradionButt=findViewById(R.id.radio_button_tobedone_id);

        taskDateEdt=findViewById(R.id.task_date_id);
        taskNameEdt=findViewById(R.id.task_name_id);
        taskNoteEdt=findViewById(R.id.task_short_notes_id);

        Bundle extras = getIntent().getExtras();
        if (extras != null) {
            //currentFile = (Paper)getIntent().getSerializableExtra(PAPER_TO_FILEVIEW_DATA_KEY); //Obtaining data
            taskItem = (TaskItem) getIntent().getParcelableExtra(INTENT_KEY_PASS_TASK_TO_EDITOR);
            // show related fiels
            displayTreatmentData(taskItem);
        }

        // listen tp radio button changes
        radioGroup.setOnCheckedChangeListener(new RadioGroup.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(RadioGroup group, int checkedId) {
                switch (checkedId){
                    case R.id.radio_button_done_id:
                        tempTaskStatus="done";
                        break;
                    case R.id.radio_button_tobedone_id:
                        tempTaskStatus="to be done";
                        break;
                    default:
                        Log.d("Main Activity","Hello World");
                }
                //Toast.makeText(getApplicationContext(),"Radio butt",Toast.LENGTH_SHORT).show();
            }
        });

        // listed to date clicks
        taskDateEdt.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                //Toast.makeText(getApplicationContext(),"planting date clicked",Toast.LENGTH_SHORT).show();
                final Calendar newCalender=Calendar.getInstance();

                DatePickerDialog dialog=new DatePickerDialog(EditTaskActivity.this, new DatePickerDialog.OnDateSetListener() {
                    @Override
                    public void onDateSet(DatePicker view, int year, int month, int dayOfMonth) {
                        iyear=year+"";
                        imonth=month;
                        iday=dayOfMonth+"";
                        printd(TAG,"day : "+dayOfMonth);
                        printd(TAG,"month : "+month);
                        printd(TAG,"year : "+year);
                        dateIsSet=true;
                        taskDateEdt.setText(dayOfMonth+"/"+month+"/"+year);
                    }
                },newCalender.get(Calendar.YEAR),newCalender.get(Calendar.MONTH),newCalender.get(Calendar.DAY_OF_MONTH));

                dialog.show();
            }
        });

    }// end of onCreate


    private void displayTreatmentData(TaskItem taskItem) {
        taskDateEdt.setText(taskItem.getTaskDate());
        taskNameEdt.setText(taskItem.getTaskName());
        taskNoteEdt.setText(taskItem.getTaskNotes());
        if(!taskItem.getTaskStatus().trim().isEmpty()){
            if(taskItem.getTaskStatus().trim().toLowerCase().equals("done")){
                doneRadionButt.setChecked(true);
            }else{
                tobeDoneradionButt.setChecked(true);
            }
        }
    }//end of displayTreatmentData

    private void updateTaskInfor(){
        String taskDate=iday+" "+getMonthFromInt(imonth)+", "+iyear;
        String taskName=taskNameEdt.getText().toString().trim();
        String taskNotes=taskNoteEdt.getText().toString().trim();
        String taskStatus=tempTaskStatus;

        if(iday==null){
            taskDate=taskItem.getTaskDate();
        }

        if(taskStatus.trim().length()==0){
            taskStatus=taskItem.getTaskStatus();
        }

        // check for empty fields
        if(taskName.length()==0){
            Toast.makeText(EditTaskActivity.this, getResources().getString(R.string.tasks_provide_name_of_task), Toast.LENGTH_SHORT).show();
            return;
        }

        // remote
        keyboardController.closeKeyboard();

        // Treatment item
        TaskItem newTaskItem=new TaskItem();
        newTaskItem.setTaskName(taskName);
        newTaskItem.setTaskNotes(taskNotes);
        newTaskItem.setTaskStatus(taskStatus);
        newTaskItem.setTaskDate(taskDate);
        newTaskItem.setId(taskItem.getId());

        Gson gson = new Gson();
        printd(TAG,""+ gson.toJson(taskItem));
        //harvestsDatabasehandler.insertHarvestedItem(harvestItem);
        taskDatabaseHandler.updateTaskInfor(newTaskItem);
        // close the activity
        finish();
    }


    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.farm_activities_edit_menu, menu);
        return super.onCreateOptionsMenu(menu);
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        switch (item.getItemId()) {
            case R.id.farm_activity_update_id:
                // User chose the "Settings" item, show the app settings UI...
                updateTaskInfor();
                return true;
            case R.id.farm_activity_delete_id:
                // User chose the "Settings" item, show the app settings UI...
                taskDatabaseHandler.deleteTaskItem(taskItem);
                finish();
                return true;
            default:
                // If we got here, the user's action was not recognized.
                // Invoke the superclass to handle it.
                return super.onOptionsItemSelected(item);

        }
    }

}// end of EditTaskActivity