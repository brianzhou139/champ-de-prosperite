package com.subzeal.champ_de_prosperite.activities.farm_activities.harvests;

import androidx.appcompat.app.ActionBar;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.LinearLayout;

import com.google.android.material.floatingactionbutton.ExtendedFloatingActionButton;
import com.subzeal.champ_de_prosperite.R;
import com.subzeal.champ_de_prosperite.activities.farm_activities.harvests.adapters.HarvestsAdapter;
import com.subzeal.champ_de_prosperite.activities.farm_activities.harvests.local_db.HarvestsDatabaseHandler;
import com.subzeal.champ_de_prosperite.activities.farm_activities.harvests.models.HarvestItem;
import com.subzeal.champ_de_prosperite.local_auth.SharedPreferencesAuth;

import java.util.ArrayList;

public class HarvestsListActivity extends AppCompatActivity {
    private static String TAG="HarvestsListActivity";
    private RecyclerView mRecyclerView;
    private HarvestsAdapter harvestsAdapter;
    private ArrayList<HarvestItem> mList;
    private ExtendedFloatingActionButton fab;
    private LinearLayout noInforContainer;
    private HarvestsDatabaseHandler harvestsDatabasehandler;
    private SharedPreferencesAuth sharedPreferencesAuth;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        sharedPreferencesAuth=new SharedPreferencesAuth(this);

        setContentView(R.layout.activity_harvests_list);
        harvestsDatabasehandler=new HarvestsDatabaseHandler(this);


        // ActionBar and its title
        ActionBar actionBar=getSupportActionBar();
        actionBar.setTitle("Harvests");

        // enable back button
        actionBar.setDisplayHomeAsUpEnabled(true);
        actionBar.setHomeButtonEnabled(true);

        fab=findViewById(R.id.fab);
        mList=new ArrayList<>();
        mRecyclerView=findViewById(R.id.recyclerview_id);
        mRecyclerView.setLayoutManager(new LinearLayoutManager(this));
        noInforContainer=findViewById(R.id.linear_no_infor_id);

        //setting the data
        displayLocalCropData();

        fab.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(getApplicationContext(), AddHarvestActivity.class);
                // starting an Activity to display the page of the article
                startActivity(intent);
            }
        });

    }//end of onCreate

    private void displayLocalCropData(){
        mList=harvestsDatabasehandler.queryHarvestsDataAndReturnIt();

        Log.d(TAG,"szi :: "+mList.size());
        if(mList.size()==0){
            noInforContainer.setVisibility(View.VISIBLE);
        }else{
            noInforContainer.setVisibility(View.GONE);
        }

        // show data in the reyclerList
        harvestsAdapter=new HarvestsAdapter(this,mList);
        mRecyclerView.setAdapter(harvestsAdapter);

    }

    @Override
    protected void onResume() {
        super.onResume();
        displayLocalCropData();
    }


}//end of  HarvestsListActivity