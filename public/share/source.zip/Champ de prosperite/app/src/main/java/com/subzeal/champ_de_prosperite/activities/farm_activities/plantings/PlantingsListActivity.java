package com.subzeal.champ_de_prosperite.activities.farm_activities.plantings;

import androidx.appcompat.app.ActionBar;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.LinearLayout;

import com.google.android.material.floatingactionbutton.ExtendedFloatingActionButton;
import com.subzeal.champ_de_prosperite.R;
import com.subzeal.champ_de_prosperite.activities.farm_activities.plantings.adapters.PlantingsAdapter;
import com.subzeal.champ_de_prosperite.activities.farm_activities.plantings.local_db.PlantingsDatabaseHandler;
import com.subzeal.champ_de_prosperite.activities.farm_activities.plantings.models.PlantItem;
import com.subzeal.champ_de_prosperite.local_auth.SharedPreferencesAuth;

import java.util.ArrayList;

public class PlantingsListActivity extends AppCompatActivity {
    private static String TAG="PlantingsListActivity";
    private RecyclerView mRecyclerView;
    private PlantingsAdapter plantingsAdapter;
    private ArrayList<PlantItem> mList;
    private ExtendedFloatingActionButton fab;
    private LinearLayout noInforContainer;
    private PlantingsDatabaseHandler plantingsDatabaseHandler;
    private SharedPreferencesAuth sharedPreferencesAuth;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        sharedPreferencesAuth=new SharedPreferencesAuth(this);
        setContentView(R.layout.activity_plantings_list);

        plantingsDatabaseHandler=new PlantingsDatabaseHandler(this);

        // ActionBar and its title
        ActionBar actionBar=getSupportActionBar();
        actionBar.setTitle(getResources().getString(R.string.plantings_label));

        // enable back button
        actionBar.setDisplayHomeAsUpEnabled(true);
        actionBar.setHomeButtonEnabled(true);


        fab=findViewById(R.id.fab);
        mList=new ArrayList<>();
        mRecyclerView=findViewById(R.id.recyclerview_id);
        mRecyclerView.setLayoutManager(new LinearLayoutManager(this));
        noInforContainer=findViewById(R.id.linear_no_infor_id);

        //setting the data
        displayLocalCropData();

        fab.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(getApplicationContext(), AddPlantingActivity.class);
                // starting an Activity to display the page of the article
                startActivity(intent);
            }
        });


    }//end of onCreate


    private void displayLocalCropData(){
        mList=plantingsDatabaseHandler.queryPlantingsDataAndReturnIt();


        Log.d(TAG,"szi :: "+mList.size());
        if(mList.size()==0){
            noInforContainer.setVisibility(View.VISIBLE);
        }else{
            noInforContainer.setVisibility(View.GONE);
        }

        // show data in the reyclerList
        plantingsAdapter=new PlantingsAdapter(this,mList);
        mRecyclerView.setAdapter(plantingsAdapter);

    }


    @Override
    protected void onResume() {
        super.onResume();
        displayLocalCropData();
    }

}//end PlantingsListActivity