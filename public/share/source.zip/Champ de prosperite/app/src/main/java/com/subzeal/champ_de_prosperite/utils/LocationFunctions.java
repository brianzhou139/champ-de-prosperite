package com.subzeal.champ_de_prosperite.utils;

import static com.subzeal.champ_de_prosperite.constants.firebase_constants.REALTIME_DB_FARMERS;
import static com.subzeal.champ_de_prosperite.utils.Logger.printd;

import android.content.Context;
import android.content.pm.PackageManager;
import android.location.Address;
import android.location.Geocoder;
import android.location.Location;

import androidx.core.content.ContextCompat;

import com.google.android.gms.location.FusedLocationProviderClient;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.gson.Gson;
import com.subzeal.champ_de_prosperite.local_auth.SharedPreferencesAuth;

import java.io.IOException;
import java.util.HashMap;
import java.util.List;
import java.util.Locale;

public class LocationFunctions {
    private static String TAG="LocationFunctions";
    Context context;
    FusedLocationProviderClient fusedLocationProviderClient;
    SharedPreferencesAuth sharedPreferencesAuth;
    private DatabaseReference mDatabase;

    public LocationFunctions(Context c, FusedLocationProviderClient fusedLocationProviderClient,SharedPreferencesAuth sharedPreferencesAuth){
        this.context=c;
        this.fusedLocationProviderClient=fusedLocationProviderClient;
        this.sharedPreferencesAuth=sharedPreferencesAuth;
        mDatabase = FirebaseDatabase.getInstance().getReference();
    };

    // Find Location And Save
    public void FindLocationAndSave(){
        if (ContextCompat.checkSelfPermission(context, android.Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED ) {
            //ActivityCompat.requestPermissions(this, new String[]{android.Manifest.permission.ACCESS_FINE_LOCATION}, 101);
        }else{
            fusedLocationProviderClient.getLastLocation().addOnSuccessListener(new OnSuccessListener<Location>() {
                @Override
                public void onSuccess(Location location) {
                    if(location!=null){
                        Geocoder geocoder=new Geocoder(context, Locale.getDefault());
                        try {
                            List<Address> addressesList=geocoder.getFromLocation(location.getLatitude(),location.getLongitude(),1);
                            Address adr=addressesList.get(0);
                            // Register User And go to the MainActivity
                            Gson gson = new Gson();
                            printd(TAG,"Address Ici");
                            printd(TAG,""+ gson.toJson(adr));
                            printd(TAG,"Latitude : "+ adr.getLatitude());
                            printd(TAG,"Longitude : "+ adr.getLongitude());
                            // Log.d(TAG,"City : "+ adr.getCountryName());
                            // Log.d(TAG,"PostalCode : "+ adr.getPostalCode());
                            double latitude=adr.getLatitude();
                            double longitude=adr.getLongitude();

                            HashMap<String,Object> locationUpdate = new HashMap<>();
                            locationUpdate.put("latitude", latitude);
                            locationUpdate.put("longitude", longitude);

                            String fId=sharedPreferencesAuth.getFarmerUid();
                            if(fId!=null){
                                mDatabase.child(REALTIME_DB_FARMERS).child(fId).updateChildren(locationUpdate);
                            }

                        } catch (IOException e) {
                            e.printStackTrace();
                        }

                    }
                }
            });

        }
    };

}
