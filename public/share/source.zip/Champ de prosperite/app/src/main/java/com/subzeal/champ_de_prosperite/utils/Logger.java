package com.subzeal.champ_de_prosperite.utils;

import static com.subzeal.champ_de_prosperite.constants.app_constants.isDEVELOPMENT;

import android.util.Log;

public class Logger {

    public static void printd(String TAG, String message){
        if(isDEVELOPMENT){
            Log.d(TAG,message);
        }
    }

}//end of Logger
