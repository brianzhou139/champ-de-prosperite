package com.subzeal.champ_de_prosperite.activities.farm_activities.harvests.local_db;

import android.content.Context;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

public class HarvestsDBHelper extends SQLiteOpenHelper {
    private static final String DATABASE_NAME = "farmharvests.db";
    private static final int DATABASE_VERSION = 1;

    private final String SQL_CREATE_HARVESTS_TABLE
            = "CREATE TABLE " + HarvestsContract.HarvestsEntry.TABLE_NAME
            + " (" + HarvestsContract.HarvestsEntry._ID + " INTEGER PRIMARY KEY AUTOINCREMENT, "
            + HarvestsContract.HarvestsEntry.COLUMN_HARVEST_NAME + " TEXT NOT NULL, "
            + HarvestsContract.HarvestsEntry.COLUMN_HARVEST_DATE + " TEXT, "
            + HarvestsContract.HarvestsEntry.COLUMN_HARVEST_NAME_OF_FIELD + " TEXT, "
            + HarvestsContract.HarvestsEntry.COLUMN_HARVEST_QUANTITY + " REAL, "
            + HarvestsContract.HarvestsEntry.COLUMN_HARVEST_INCOME + " REAL, "
            + HarvestsContract.HarvestsEntry.COLUMN_HARVEST_UNIT_COSTS + " REAL, "
            + HarvestsContract.HarvestsEntry.COLUMN_HARVEST_NOTES + " TEXT"
            + ");";

    public HarvestsDBHelper(Context context) {
        super(context, DATABASE_NAME, null, DATABASE_VERSION);
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        db.execSQL(SQL_CREATE_HARVESTS_TABLE);
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        // Ideally we wouldn't want to delete all of our entries!
        db.execSQL("DROP TABLE IF EXISTS " + HarvestsContract.HarvestsEntry.TABLE_NAME);
        onCreate(db);	// Call to create a new db with upgraded schema and version
    }

}// end of HarvestsDBHelper
