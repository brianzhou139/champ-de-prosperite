package com.subzeal.champ_de_prosperite.constants;

public class fcm_constants {
    public static String TOPIC_WEATHER_UPDATE="weather_update";
    public static String TOPIC_MARKET_GUIDE="market_guide";
    public static String TOPIC_ANNOUNCEMENT="announcement";

    public static String []LIST_OF_TOPICS={TOPIC_WEATHER_UPDATE,TOPIC_MARKET_GUIDE,TOPIC_ANNOUNCEMENT};

    public static String FCM_WEATHER_UPDATE="/topics/"+TOPIC_WEATHER_UPDATE;
    public static String FCM_MARKET_GUIDE="/topics/"+TOPIC_MARKET_GUIDE;
    public static String FCM_ANNOUNCEMENT="/topics/"+TOPIC_ANNOUNCEMENT;

}
