package com.subzeal.champ_de_prosperite.activities.farm_activities.plantings.models;

import android.os.Parcel;
import android.os.Parcelable;

public class PlantItem implements Parcelable {
    private int id;
    private String plantDate;

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getPlantDate() {
        return plantDate;
    }

    public void setPlantDate(String plantDate) {
        this.plantDate = plantDate;
    }

    public String getPlantName() {
        return plantName;
    }

    public void setPlantName(String plantName) {
        this.plantName = plantName;
    }

    public String getQuantityPlanted() {
        return quantityPlanted;
    }

    public void setQuantityPlanted(String quantityPlanted) {
        this.quantityPlanted = quantityPlanted;
    }

    public String getNameOfField() {
        return nameOfField;
    }

    public void setNameOfField(String nameOfField) {
        this.nameOfField = nameOfField;
    }

    public String getNotes() {
        return notes;
    }

    public void setNotes(String notes) {
        this.notes = notes;
    }

    private String plantName;
    private String quantityPlanted;
    private String nameOfField;
    private String notes;

    public PlantItem(){};

    protected PlantItem(Parcel in) {
        id = in.readInt();
        plantDate = in.readString();
        plantName = in.readString();
        quantityPlanted = in.readString();
        nameOfField = in.readString();
        notes = in.readString();
    }

    @Override
    public void writeToParcel(Parcel dest, int flags) {
        dest.writeInt(id);
        dest.writeString(plantDate);
        dest.writeString(plantName);
        dest.writeString(quantityPlanted);
        dest.writeString(nameOfField);
        dest.writeString(notes);
    }

    @Override
    public int describeContents() {
        return 0;
    }

    public static final Creator<PlantItem> CREATOR = new Creator<PlantItem>() {
        @Override
        public PlantItem createFromParcel(Parcel in) {
            return new PlantItem(in);
        }

        @Override
        public PlantItem[] newArray(int size) {
            return new PlantItem[size];
        }
    };
}
