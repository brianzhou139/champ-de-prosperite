package com.subzeal.champ_de_prosperite.activities.auth_and_language;

import androidx.appcompat.app.ActionBar;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;

import com.subzeal.champ_de_prosperite.HomePageActivity;
import com.subzeal.champ_de_prosperite.R;
import com.subzeal.champ_de_prosperite.local_auth.SharedPreferencesAuth;

public class LanguageSelectionActivity extends AppCompatActivity {
    private static String TAG="LanguageSelectionActivity";
    public static String ENGLISH_CODE="en";
    public static String FRENCH_CODE="fr";
    public static String SHONA_CODE="sn";
    public static String NDEBELE_CODE="nd";

    private ImageView englishImg,shonaImg,ndebeleImg,frenchImg;
    private LinearLayout englishContainer,shonaContainer,ndebeleContainer,frenchContainer;
    private TextView englishLabelText,shonaLabelText,ndebeleLabelText,frenchLabelText;

    private Button continueButt;
    private SharedPreferencesAuth sharedPreferencesAuth;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        sharedPreferencesAuth=new SharedPreferencesAuth(this);
        setContentView(R.layout.activity_language_selection);

        // ActionBar and its title
        ActionBar actionBar=getSupportActionBar();
        actionBar.setTitle(getResources().getString(R.string.language_options));

        // enable back button
        actionBar.setDisplayHomeAsUpEnabled(true);
        actionBar.setHomeButtonEnabled(true);

        // img indicators
        englishImg=findViewById(R.id.english_src_id);
        shonaImg=findViewById(R.id.shona_src_id);
        ndebeleImg=findViewById(R.id.ndebele_src_id);
        frenchImg=findViewById(R.id.french_src_id);

        // container
        englishContainer=findViewById(R.id.english_container_id);
        shonaContainer=findViewById(R.id.shona_container_id);
        ndebeleContainer=findViewById(R.id.ndebele_container_id);
        frenchContainer =  findViewById(R.id.french_container_id);

        // text labels
        englishLabelText=findViewById(R.id.english_label_id);
        shonaLabelText=findViewById(R.id.shona_label_id);
        ndebeleLabelText=findViewById(R.id.ndebele_label_id);
        frenchLabelText =  findViewById(R.id.french_label_id);

        // button
        continueButt=findViewById(R.id.continue_butt_id);

        // setTheCurrentLangauge
        setTheCurrentLanguage();

        englishContainer.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                // setting the language to english
                sharedPreferencesAuth.setAppLanguage(ENGLISH_CODE);

                englishContainer.setBackgroundResource(R.drawable.b1_selected_lang);
                englishImg.setVisibility(View.VISIBLE);
                englishLabelText.setTextColor(getResources().getColor(R.color.slate_800));

                // remove
                ndebeleContainer.setBackgroundResource(R.drawable.b1_lang);
                shonaContainer.setBackgroundResource(R.drawable.b1_lang);
                ndebeleImg.setVisibility(View.INVISIBLE);
                shonaImg.setVisibility(View.INVISIBLE);
                ndebeleLabelText.setTextColor(getResources().getColor(R.color.slate_500));
                shonaLabelText.setTextColor(getResources().getColor(R.color.slate_500));

                //
                frenchContainer.setBackgroundResource(R.drawable.b1_lang);
                frenchLabelText.setTextColor(getResources().getColor(R.color.slate_500));
                frenchImg.setVisibility(View.INVISIBLE);
            }
        });//end of english

        shonaContainer.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                // setting the language to shona
                sharedPreferencesAuth.setAppLanguage(SHONA_CODE);

                shonaContainer.setBackgroundResource(R.drawable.b1_selected_lang);
                shonaImg.setVisibility(View.VISIBLE);
                shonaLabelText.setTextColor(getResources().getColor(R.color.slate_800));

                // remove for others
                englishContainer.setBackgroundResource(R.drawable.b1_lang);
                ndebeleContainer.setBackgroundResource(R.drawable.b1_lang);
                englishImg.setVisibility(View.INVISIBLE);
                ndebeleImg.setVisibility(View.INVISIBLE);
                englishLabelText.setTextColor(getResources().getColor(R.color.slate_500));
                ndebeleLabelText.setTextColor(getResources().getColor(R.color.slate_500));

                //
                frenchContainer.setBackgroundResource(R.drawable.b1_lang);
                frenchLabelText.setTextColor(getResources().getColor(R.color.slate_500));
                frenchImg.setVisibility(View.INVISIBLE);
            }
        });//shona


        ndebeleContainer.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                // setting the language to ndebele
                sharedPreferencesAuth.setAppLanguage(NDEBELE_CODE);

                ndebeleContainer.setBackgroundResource(R.drawable.b1_selected_lang);
                ndebeleImg.setVisibility(View.VISIBLE);
                ndebeleLabelText.setTextColor(getResources().getColor(R.color.slate_800));
                // remove
                englishContainer.setBackgroundResource(R.drawable.b1_lang);
                shonaContainer.setBackgroundResource(R.drawable.b1_lang);
                frenchContainer.setBackgroundResource(R.drawable.b1_lang);
                englishImg.setVisibility(View.INVISIBLE);
                shonaImg.setVisibility(View.INVISIBLE);
                frenchImg.setVisibility(View.INVISIBLE);
                shonaLabelText.setTextColor(getResources().getColor(R.color.slate_500));
                englishLabelText.setTextColor(getResources().getColor(R.color.slate_500));
                frenchLabelText.setTextColor(getResources().getColor(R.color.slate_500));

            }
        });//ndebele

        frenchContainer.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // setting the language to ndebele
                sharedPreferencesAuth.setAppLanguage(FRENCH_CODE);

                frenchContainer.setBackgroundResource(R.drawable.b1_selected_lang);
                frenchImg.setVisibility(View.VISIBLE);
                frenchLabelText.setTextColor(getResources().getColor(R.color.slate_800));
                // remove
                englishContainer.setBackgroundResource(R.drawable.b1_lang);
                shonaContainer.setBackgroundResource(R.drawable.b1_lang);
                englishImg.setVisibility(View.INVISIBLE);
                shonaImg.setVisibility(View.INVISIBLE);
                shonaLabelText.setTextColor(getResources().getColor(R.color.slate_500));
                englishLabelText.setTextColor(getResources().getColor(R.color.slate_500));

                //
                ndebeleContainer.setBackgroundResource(R.drawable.b1_lang);
                ndebeleImg.setVisibility(View.INVISIBLE);
                ndebeleLabelText.setTextColor(getResources().getColor(R.color.slate_500));
            }
        });//french

        continueButt.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String fId=sharedPreferencesAuth.getFarmerUid();
                // Go to HomePage
                Intent intent = new Intent(getApplicationContext(), HomePageActivity.class);
                startActivity(intent);
                finish();
            }
        });//end of continueButt

    }//end of onCreate


    private void setTheCurrentLanguage(){
        String currentlang=sharedPreferencesAuth.getAppLanguage();

        // english Language
        if(currentlang.equals(ENGLISH_CODE)){
            englishContainer.setBackgroundResource(R.drawable.b1_selected_lang);
            englishImg.setVisibility(View.VISIBLE);
            englishLabelText.setTextColor(getResources().getColor(R.color.slate_800));

            // remove
            ndebeleContainer.setBackgroundResource(R.drawable.b1_lang);
            shonaContainer.setBackgroundResource(R.drawable.b1_lang);
            ndebeleImg.setVisibility(View.INVISIBLE);
            shonaImg.setVisibility(View.INVISIBLE);
            ndebeleLabelText.setTextColor(getResources().getColor(R.color.slate_500));
            shonaLabelText.setTextColor(getResources().getColor(R.color.slate_500));

            //
            frenchContainer.setBackgroundResource(R.drawable.b1_lang);
            frenchLabelText.setTextColor(getResources().getColor(R.color.slate_500));
            frenchImg.setVisibility(View.INVISIBLE);
        }

        // Shona Language
        if(currentlang.equals(SHONA_CODE)){
            shonaContainer.setBackgroundResource(R.drawable.b1_selected_lang);
            shonaImg.setVisibility(View.VISIBLE);
            shonaLabelText.setTextColor(getResources().getColor(R.color.slate_800));

            // remove for others
            englishContainer.setBackgroundResource(R.drawable.b1_lang);
            ndebeleContainer.setBackgroundResource(R.drawable.b1_lang);
            englishImg.setVisibility(View.INVISIBLE);
            ndebeleImg.setVisibility(View.INVISIBLE);
            englishLabelText.setTextColor(getResources().getColor(R.color.slate_500));
            ndebeleLabelText.setTextColor(getResources().getColor(R.color.slate_500));

            //
            frenchContainer.setBackgroundResource(R.drawable.b1_lang);
            frenchLabelText.setTextColor(getResources().getColor(R.color.slate_500));
            frenchImg.setVisibility(View.INVISIBLE);
        }

        // Ndebele Language
        if(currentlang.equals(NDEBELE_CODE)){
            ndebeleContainer.setBackgroundResource(R.drawable.b1_selected_lang);
            ndebeleImg.setVisibility(View.VISIBLE);
            ndebeleLabelText.setTextColor(getResources().getColor(R.color.slate_800));
            // remove
            englishContainer.setBackgroundResource(R.drawable.b1_lang);
            shonaContainer.setBackgroundResource(R.drawable.b1_lang);
            frenchContainer.setBackgroundResource(R.drawable.b1_lang);
            englishImg.setVisibility(View.INVISIBLE);
            shonaImg.setVisibility(View.INVISIBLE);
            frenchImg.setVisibility(View.INVISIBLE);
            shonaLabelText.setTextColor(getResources().getColor(R.color.slate_500));
            englishLabelText.setTextColor(getResources().getColor(R.color.slate_500));
            frenchLabelText.setTextColor(getResources().getColor(R.color.slate_500));

        }

        // Ndebele Language
        if(currentlang.equals(FRENCH_CODE)){
            // setting the language to ndebele
            frenchContainer.setBackgroundResource(R.drawable.b1_selected_lang);
            frenchImg.setVisibility(View.VISIBLE);
            frenchLabelText.setTextColor(getResources().getColor(R.color.slate_800));
            // remove
            englishContainer.setBackgroundResource(R.drawable.b1_lang);
            shonaContainer.setBackgroundResource(R.drawable.b1_lang);
            englishImg.setVisibility(View.INVISIBLE);
            shonaImg.setVisibility(View.INVISIBLE);
            shonaLabelText.setTextColor(getResources().getColor(R.color.slate_500));
            englishLabelText.setTextColor(getResources().getColor(R.color.slate_500));

            //
            ndebeleContainer.setBackgroundResource(R.drawable.b1_lang);
            ndebeleImg.setVisibility(View.INVISIBLE);
            ndebeleLabelText.setTextColor(getResources().getColor(R.color.slate_500));
        }
    }//end of setTheCurrentLanguage



    @Override
    public void onBackPressed() {
        super.onBackPressed();
        Intent goToHomePage = new Intent(getApplicationContext(), HomePageActivity.class);
        startActivity(goToHomePage);
    }

}//end of LanguageSelectionActivity