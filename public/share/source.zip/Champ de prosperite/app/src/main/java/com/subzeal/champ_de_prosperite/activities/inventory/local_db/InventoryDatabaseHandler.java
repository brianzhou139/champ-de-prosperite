package com.subzeal.champ_de_prosperite.activities.inventory.local_db;

import static com.subzeal.champ_de_prosperite.activities.inventory.local_db.InventoryContract.COLUMN_INVENTORY_ITEM_NAME;
import static com.subzeal.champ_de_prosperite.activities.inventory.local_db.InventoryContract.COLUMN_INVENTORY_ITEM_QUANTITY;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.util.Log;

import com.subzeal.champ_de_prosperite.models.InventoryItem;

import java.util.ArrayList;
import java.util.Collections;

public class InventoryDatabaseHandler {
    private static String TAG="InventoryDatabaseHandler";
    private Context context;
    private SQLiteDatabase database;
    private InventoryDBHelper inventoryDBHelper;

    public InventoryDatabaseHandler(Context context){
        this.context=context;
        inventoryDBHelper=new InventoryDBHelper(context);
        database=inventoryDBHelper.getWritableDatabase();
    };//end of InventoryDatabaseHandler

    public void insertInventoryData(InventoryItem item){
        ContentValues contentValues=new ContentValues();
        contentValues.put(InventoryContract._ID,item.getId());
        contentValues.put(COLUMN_INVENTORY_ITEM_NAME,item.getInventoryItemName());
        contentValues.put(COLUMN_INVENTORY_ITEM_QUANTITY,item.getInventoryItemQuantity());
        long rowID = database.insert(InventoryContract.TABLE_NAME,null,contentValues);
    }//end of insertData

    public ArrayList<InventoryItem> queryInventoryDataAndReturnIt(){
        ArrayList<InventoryItem> mList=new ArrayList<>();

        String [] projection={
                InventoryContract._ID,
                COLUMN_INVENTORY_ITEM_NAME,
                COLUMN_INVENTORY_ITEM_QUANTITY
        };

        // Filter
        String selection = null;
        String []selectionArgs = null;

        String sortOrder = null;

        Cursor cursor = database.query(InventoryContract.TABLE_NAME,// table sname ,
                projection,  // Columns to return
                selection,   // Selection: Where clause or the condition
                selectionArgs, //
                null, //
                null,
                sortOrder
        );

        if(cursor!=null){
            String str="";
            while(cursor.moveToNext()){  // cursor iterates through all the rows
                // Cursor iterates through all rows
                String[] columns = cursor.getColumnNames();
                InventoryItem item=new InventoryItem();

                // { id , country , continent }
                String id=cursor.getString(cursor.getColumnIndex(InventoryContract._ID));
                String item_name=cursor.getString(cursor.getColumnIndex(COLUMN_INVENTORY_ITEM_NAME));
                String quand=cursor.getString(cursor.getColumnIndex(COLUMN_INVENTORY_ITEM_QUANTITY));
                Log.d(TAG,id+" >>>>> "+item_name);

                item.setInventoryItemName(item_name);
                item.setInventoryItemQuantity(quand);
                item.setId(id);
                mList.add(item);
            }
        }


        Log.d(TAG," >>>>> "+mList.size());
        Collections.reverse(mList);
        return mList;
    }//end of insertData


    public void deleteInventoryItem(String selectedId) {
        String selection = InventoryContract._ID + " = ? ";
        String[] selectionArgs = { selectedId };		// WHERE country = "Japan"
        int rowsDeleted = database.delete(InventoryContract.TABLE_NAME, selection, selectionArgs);
        Log.i(TAG, "Number of rows deleted: " + rowsDeleted);
    }// end of delete

    public void updateInventoryData(InventoryItem item) {
        String selection = InventoryContract._ID + " = ?";
        String[] selectionArgs = { item.getId() };			// WHERE country = ? = Japan

        ContentValues contentValues = new ContentValues();
        contentValues.put(InventoryContract._ID, item.getId());
        contentValues.put(COLUMN_INVENTORY_ITEM_NAME, item.getInventoryItemName());
        contentValues.put(COLUMN_INVENTORY_ITEM_QUANTITY, item.getInventoryItemQuantity());

        int rowsUpdated = database.update(InventoryContract.TABLE_NAME, contentValues, selection, selectionArgs);
        Log.i(TAG, "Number of rows updated: " + rowsUpdated);
    }

    // kill the database to release resources
    public void destroyInventoryDatabase(){
        database.close(); // close database here
    }

}
