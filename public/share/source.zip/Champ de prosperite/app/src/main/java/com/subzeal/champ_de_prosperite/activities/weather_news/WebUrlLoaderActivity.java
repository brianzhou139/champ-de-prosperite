package com.subzeal.champ_de_prosperite.activities.weather_news;

import static com.subzeal.champ_de_prosperite.utils.Logger.printd;

import androidx.appcompat.app.ActionBar;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.graphics.Bitmap;
import android.os.Bundle;
import android.view.View;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.ProgressBar;

import com.subzeal.champ_de_prosperite.R;

public class WebUrlLoaderActivity extends AppCompatActivity {
    // setting the TAG for debugging purposes
    private static String TAG="WebActivity";

    // declaring the webview
    private WebView myWebView;

    // declaring the url string variable
    private String url;

    private ProgressBar progressBar;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_web_url_loader);

        // ActionBar and its title
        ActionBar actionBar=getSupportActionBar();
        actionBar.setTitle(getResources().getString(R.string.weather_news_label));

        // enable back button
        actionBar.setDisplayHomeAsUpEnabled(true);
        actionBar.setHomeButtonEnabled(true);

        progressBar=findViewById(R.id.progressBar);

        // assigning the views to id's
        myWebView = (WebView) findViewById(R.id.webview);

        Intent intent = getIntent();

        //checking if there is an intent
        if(intent!=null){
            //retrieving the url in the intent
            url = intent.getStringExtra("url_key");

            //loading and displaying a web page in the activity
            myWebView.loadUrl(url);
        }

        myWebView.setWebViewClient(new WebViewClient() {
            @Override
            public void onPageStarted(WebView view, String url, Bitmap favicon)
            {
                // TODO show you progress image
                printd(TAG,"onPageStarted");
                progressBar.setVisibility(View.GONE);
                super.onPageStarted(view, url, favicon);
            }

            @Override
            public void onPageFinished(WebView view, String url)
            {
                // TODO hide your progress image
                printd(TAG,"Done Loading Here");
                progressBar.setVisibility(View.GONE);
                super.onPageFinished(view, url);
            }
        });



    }//end of onCreate

    @Override
    protected void onRestart() {
        super.onRestart();
        finish();
    }

}//end of WebUrlLoaderActivity