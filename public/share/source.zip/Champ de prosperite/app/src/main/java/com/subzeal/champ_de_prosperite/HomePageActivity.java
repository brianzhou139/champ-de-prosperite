package com.subzeal.champ_de_prosperite;
import static com.subzeal.champ_de_prosperite.constants.fcm_constants.FCM_ANNOUNCEMENT;
import static com.subzeal.champ_de_prosperite.constants.fcm_constants.FCM_MARKET_GUIDE;
import static com.subzeal.champ_de_prosperite.constants.fcm_constants.FCM_WEATHER_UPDATE;
import static com.subzeal.champ_de_prosperite.constants.fcm_constants.LIST_OF_TOPICS;
import static com.subzeal.champ_de_prosperite.constants.firebase_constants.REALTIME_DB_ANNOUNCEMENTS;
import static com.subzeal.champ_de_prosperite.constants.firebase_constants.REALTIME_DB_WEATHER_NEWS;
import static com.subzeal.champ_de_prosperite.utils.Logger.printd;

import androidx.annotation.NonNull;
import androidx.appcompat.app.ActionBar;
import androidx.appcompat.app.AppCompatActivity;
import androidx.cardview.widget.CardView;

import android.content.ContentResolver;
import android.content.Intent;
import android.graphics.Color;
import android.net.Uri;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.LinearLayout;

import com.google.android.gms.location.FusedLocationProviderClient;
import com.google.android.gms.location.LocationServices;
import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;
import com.google.firebase.messaging.FirebaseMessaging;
import com.smarteist.autoimageslider.IndicatorView.animation.type.IndicatorAnimationType;
import com.smarteist.autoimageslider.IndicatorView.draw.controller.DrawController;
import com.smarteist.autoimageslider.SliderAnimations;
import com.smarteist.autoimageslider.SliderView;
import com.subzeal.champ_de_prosperite.activities.announcements.AnnouncementsListActivity;
import com.subzeal.champ_de_prosperite.activities.auth_and_language.LanguageSelectionActivity;
import com.subzeal.champ_de_prosperite.activities.crop_schedule.CropScheduleListActivity;
import com.subzeal.champ_de_prosperite.activities.farm_activities.DisplayfarmActivitiesActivity;
import com.subzeal.champ_de_prosperite.activities.inventory.InventoryActivity;
import com.subzeal.champ_de_prosperite.activities.loans.LoansActivity;
import com.subzeal.champ_de_prosperite.activities.market_guide.MarketGuideListActivity;
import com.subzeal.champ_de_prosperite.activities.weather_news.WeatherNewsListActivity;
import com.subzeal.champ_de_prosperite.adapters.SliderAdapterExample;
import com.subzeal.champ_de_prosperite.local_auth.SharedPreferencesAuth;
import com.subzeal.champ_de_prosperite.models.SliderItem;
import com.subzeal.champ_de_prosperite.models.announcementModel;
import com.subzeal.champ_de_prosperite.models.updateDataObject;
import com.subzeal.champ_de_prosperite.utils.LocationFunctions;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Set;

public class HomePageActivity extends AppCompatActivity {
    private static String TAG="HomePageActivity";
    private static List<announcementModel> announcementList=new ArrayList<>();
    private SliderView sliderView;
    private SliderAdapterExample adapter;

    private CardView weatherNewsCard, marketGuideCard,
            cropScheduleCard,inventoryCard,
            farmActivityCard,reportsCard, LoansCard;
    private CardView slideViewCard;
    private LinearLayout containerForSlider;

    // Location Functions
    private String farmerId=null;
    private LocationFunctions locationFunctions;

    private FusedLocationProviderClient fusedLocationProviderClient;
    private DatabaseReference mDatabase;
    private SharedPreferencesAuth sharedPreferencesAuth;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        sharedPreferencesAuth=new SharedPreferencesAuth(this);

        setContentView(R.layout.activity_home_page);
        checkIntentAndSubribeForNotifications();
        fusedLocationProviderClient= LocationServices.getFusedLocationProviderClient(this);
        locationFunctions=new LocationFunctions(this,fusedLocationProviderClient,sharedPreferencesAuth);


        // ActionBar and its title
        ActionBar actionBar=getSupportActionBar();
        actionBar.setTitle(getResources().getString(R.string.app_name));

        // geting the farmerId
        farmerId=sharedPreferencesAuth.getFarmerUid();
        if(farmerId==null){
            // Go to Registration Page
            // Intent intent = new Intent(getApplicationContext(), LanguageSelectionActivity.class);
            // startActivity(intent);
            // finish();
        }

        sliderView = findViewById(R.id.imageSlider);
        containerForSlider=findViewById(R.id.containerForSlider_id);
        weatherNewsCard=findViewById(R.id.weather_news_card_id);
        marketGuideCard=findViewById(R.id.market_guide_card_id);
        cropScheduleCard=findViewById(R.id.crop_schedule_card_id);
        farmActivityCard=findViewById(R.id.farm_acitivities_card_id);
        reportsCard=findViewById(R.id.reports_card_id);
        inventoryCard=findViewById(R.id.inventory_card_id);
        LoansCard =findViewById(R.id.announcements_selection_card_id);
        slideViewCard=findViewById(R.id.slide_show_card_id);
        slideViewCard.setVisibility(View.INVISIBLE);

        // load notifications
        loadNotificationsFromRealTimeDB();


        weatherNewsCard.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // Go to WeatherNewsActivity
                Intent intent = new Intent(getApplicationContext(),WeatherNewsListActivity.class);
                startActivity(intent);
            }
        });//end of weatherNewsCard

        marketGuideCard.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // Go to MarketGuideAcitivity
                Intent intent = new Intent(getApplicationContext(), MarketGuideListActivity.class);
                startActivity(intent);
            }
        });//end of marketGuideCard

        cropScheduleCard.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // Go to CropSchedule List
                Intent intent = new Intent(getApplicationContext(), CropScheduleListActivity.class);
                startActivity(intent);
            }
        });// cropScheduleCard

        inventoryCard.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // Go to Inventory Acitivity
                Intent intent = new Intent(getApplicationContext(), InventoryActivity.class);
                startActivity(intent);
            }
        });// inventoryCard

        farmActivityCard.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // Go to Inventory Acitivity
                Intent intent = new Intent(getApplicationContext(), DisplayfarmActivitiesActivity.class);
                startActivity(intent);
            }
        });//end of farmActivityCard

        reportsCard.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                //Toast.makeText(getApplicationContext(),"reports clicked",Toast.LENGTH_SHORT).show();
            }
        });//end of reports

        LoansCard.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // Go to Inventory Acitivity
                Intent goToFileViewIntent=new Intent(getApplicationContext(), LoansActivity.class);
                startActivity(goToFileViewIntent);

                if(announcementList.size()>=1){
                    //Intent goToFileViewIntent=new Intent(getApplicationContext(), AnnouncementsListActivity.class);
                    //goToFileViewIntent.putParcelableArrayListExtra(INTENT_KEY_PASS_ANNOUNCEMENTS_TO_DISPLAYER,(ArrayList<? extends Parcelable>)announcementList);
                    //startActivity(goToFileViewIntent);
                }
            }
        });

        // find location
        locationFunctions.FindLocationAndSave();
    }// end of onCreate


    /*   Checks for Intents and Subscribes to recieve Notifications   */
    private void checkIntentAndSubribeForNotifications(){
        Bundle extras = getIntent().getExtras();
        if(extras!=null){
            Set<String> keysInExtras = extras.keySet();

            String from = extras.getString("from");

            printd(TAG,"::"+from);

            if(from==null){
                return;
            }
            if(from.toLowerCase().equals(FCM_WEATHER_UPDATE.toLowerCase())){
                // Go to WeatherNewsActivity
                Intent intent = new Intent(this, WeatherNewsListActivity.class);
                startActivity(intent);
            }

            if(from.toLowerCase().equals(FCM_MARKET_GUIDE.toLowerCase())){
                // Go to MarketGuideAcitivity
                Intent intent = new Intent(this, MarketGuideListActivity.class);
                startActivity(intent);
            }

            if(from.toLowerCase().equals(FCM_ANNOUNCEMENT.toLowerCase())){
                // Go to Announcements Activity
                Intent intent = new Intent(this, AnnouncementsListActivity.class);
                startActivity(intent);
            }

            printd(TAG,"Keys in Extra");
            for(String key : keysInExtras){
                // find the keys you need and get the data from the bundle using those keys
            }
        }

        printd(TAG,"weathers weathers weathers weathers weathers weathers");

        // iterating on the topics
        for(int i=0;i<LIST_OF_TOPICS.length;i++){
            String topic=LIST_OF_TOPICS[i].toLowerCase();
            FirebaseMessaging.getInstance().subscribeToTopic(topic)
                    .addOnCompleteListener(new OnCompleteListener<Void>() {
                        @Override
                        public void onComplete(@NonNull Task<Void> task) {
                            String msg = "Subscribed";
                            if (!task.isSuccessful()) {
                                msg = "Subscribe failed";
                            }
                            printd(TAG, msg);
                            //Toast.makeText(MainActivity.this, msg, Toast.LENGTH_SHORT).show();
                        }
                    });

        }
    }


    /* Laods data from the fb realtime database */
    private void loadNotificationsFromRealTimeDB(){
        // Write a message to the database
        FirebaseDatabase database = FirebaseDatabase.getInstance();
        DatabaseReference myRef = database.getReference(REALTIME_DB_WEATHER_NEWS);
        announcementList=new ArrayList<>();

        // Read from the database
        myRef.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(DataSnapshot dataSnapshot) {
                // This method is called once with the initial value and again
                // whenever data at this location is updated.
                //String value = dataSnapshot.getValue(String.class);
                printd(TAG, "data retrieved here bibido: ");
                for(DataSnapshot snapshot1:dataSnapshot.getChildren()){
                    //fileModel currentFile=snapshot1.getValue(fileModel.class);
                    updateDataObject currentObject=snapshot1.getValue(updateDataObject.class);

                    announcementModel announcement=new announcementModel();
                    announcement.setTitle(currentObject.getTitle());
                    announcement.setTextShortContent(currentObject.getTextShortContent());
                    announcement.setHtmlContent(currentObject.getHtmlContent());

                    printd(TAG,"tit : "+announcement.getTitle());
                    announcementList.add(announcement);
                }
                Collections.reverse(announcementList);

                if(announcementList.size()>0){
                    List<announcementModel> topThreeAnnouncements=announcementList.subList(0,3);
                    setUpTheNotifications(topThreeAnnouncements);
                };
            }

            @Override
            public void onCancelled(DatabaseError error) {
                // Failed to read value
                printd(TAG, "Failed to read value."+error.toException());
            }
        });
    }

    private void setUpTheNotifications(List<announcementModel> topThreeAnnouncements) {
        List<SliderItem> sliderItemList = new ArrayList<>();

        for(int i=0;i<topThreeAnnouncements.size();i++){
            Uri imageUri1=null;
            switch (i){
                case 0:
                    imageUri1 = Uri.parse(ContentResolver.SCHEME_ANDROID_RESOURCE +
                            "://" + getResources().getResourcePackageName(R.drawable.ann_1)
                            + '/' + getResources().getResourceTypeName(R.drawable.ann_1) + '/'
                            + getResources().getResourceEntryName(R.drawable.ann_1) );
                    break;
                case 1:
                    imageUri1 = Uri.parse(ContentResolver.SCHEME_ANDROID_RESOURCE +
                            "://" + getResources().getResourcePackageName(R.drawable.ann_2)
                            + '/' + getResources().getResourceTypeName(R.drawable.ann_2) + '/'
                            + getResources().getResourceEntryName(R.drawable.ann_2) );
                    break;
                case 2:
                    imageUri1 = Uri.parse(ContentResolver.SCHEME_ANDROID_RESOURCE +
                            "://" + getResources().getResourcePackageName(R.drawable.ann_3)
                            + '/' + getResources().getResourceTypeName(R.drawable.ann_3) + '/'
                            + getResources().getResourceEntryName(R.drawable.ann_3) );
                    break;
                default:
                    imageUri1 = Uri.parse(ContentResolver.SCHEME_ANDROID_RESOURCE +
                            "://" + getResources().getResourcePackageName(R.drawable.ann_1)
                            + '/' + getResources().getResourceTypeName(R.drawable.ann_1) + '/'
                            + getResources().getResourceEntryName(R.drawable.ann_1) );
            }


            SliderItem sliderItem1 = new SliderItem();
            //sliderItem1.setDescription("listen, learn and enjoy");
            sliderItem1.setTitle(topThreeAnnouncements.get(i).getTitle());
            sliderItem1.setDescription(topThreeAnnouncements.get(i).getTextShortContent());
            sliderItem1.setImageUrl(String.valueOf(imageUri1));

            // adding it to the list
            sliderItemList.add(sliderItem1);
        }

        adapter = new SliderAdapterExample(this,announcementList);
        adapter.renewItems(sliderItemList);

        /* *********************************************** */

        sliderView.setSliderAdapter(adapter);
        sliderView.setIndicatorAnimation(IndicatorAnimationType.WORM); //set indicator animation by using SliderLayout.IndicatorAnimations. :WORM or THIN_WORM or COLOR or DROP or FILL or NONE or SCALE or SCALE_DOWN or SLIDE and SWAP!!
        sliderView.setSliderTransformAnimation(SliderAnimations.SIMPLETRANSFORMATION);
        sliderView.setAutoCycleDirection(SliderView.AUTO_CYCLE_DIRECTION_BACK_AND_FORTH);
        sliderView.setIndicatorSelectedColor(Color.WHITE);
        sliderView.setIndicatorUnselectedColor(Color.GRAY);
        sliderView.setScrollTimeInSec(5);
        sliderView.setAutoCycle(true);
        sliderView.startAutoCycle();

        if(announcementList.size()>=1){
            containerForSlider.setVisibility(View.VISIBLE);
            slideViewCard.setVisibility(View.VISIBLE);
        }
        sliderView.setOnIndicatorClickListener(new DrawController.ClickListener() {
            @Override
            public void onIndicatorClicked(int position) {
                //Log.i("GGG", "onIndicatorClicked: " + sliderView.getCurrentPagePosition());

            }
        });


    }//end of setUpTheNotifications


    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.home_page_menu, menu);
        return super.onCreateOptionsMenu(menu);
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        switch (item.getItemId()) {
            case R.id.action_choose_language_id:
                // User chose the "Settings" item, show the app settings UI...
                // Go to Announcements Activity
                Intent intent = new Intent(this, LanguageSelectionActivity.class);
                startActivity(intent);
                return true;
            default:
                // If we got here, the user's action was not recognized.
                // Invoke the superclass to handle it.
                return super.onOptionsItemSelected(item);

        }
    }


}// end of HomePageActivity