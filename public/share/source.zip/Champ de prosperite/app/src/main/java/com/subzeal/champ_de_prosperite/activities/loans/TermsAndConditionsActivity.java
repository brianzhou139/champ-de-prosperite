package com.subzeal.champ_de_prosperite.activities.loans;

import static com.subzeal.champ_de_prosperite.constants.activity_constants.INTENT_LOAN_TO_LOAN_APPLICATION;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Build;
import android.os.Bundle;
import android.os.Parcelable;
import android.view.View;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.Toast;

import com.subzeal.champ_de_prosperite.R;
import com.subzeal.champ_de_prosperite.activities.crop_schedule.model.CropItem;
import com.subzeal.champ_de_prosperite.activities.loans.models.LoanItem;

public class TermsAndConditionsActivity extends AppCompatActivity {
    private String TAG="TermsAndConditionsActivity";
    private Button continueButt;
    private CheckBox checkBoxTerms;
    private LoanItem currentLoan;
    private WebView webView = null;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_terms_and_conditions);

        Bundle extras = getIntent().getExtras();
        if (extras != null) {
            // get the intent data
            currentLoan = getIntent().getParcelableExtra(INTENT_LOAN_TO_LOAN_APPLICATION);
        }

        checkBoxTerms = findViewById(R.id.terms_check_id);
        continueButt =  findViewById(R.id.loan_continue_butt_id);
        webView = (WebView) findViewById(R.id.webview);

        continueButt.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if(checkBoxTerms.isChecked()){
                    Intent goToApplyLoan = new Intent(getApplicationContext(), LoanAplicationActivity.class);
                    // goToFileViewIntent.putParcelableArrayListExtra(INTENT_LOAN_TO_LOAN_APPLICATION,(ArrayList<? extends Parcelable>)announcementList);
                    goToApplyLoan.putExtra(INTENT_LOAN_TO_LOAN_APPLICATION, (Parcelable) currentLoan);
                    startActivity(goToApplyLoan);
                }else{
                    Toast.makeText(TermsAndConditionsActivity.this, R.string.loan_please_Agree_label, Toast.LENGTH_LONG).show();
                    checkBoxTerms.setBackgroundResource(R.color.red_100);
                }
            }
        });// end of continueButt

        // display data
        displayWebViewData();

    }//end of onCreate

    private void displayWebViewData() {
        webView.getSettings().setJavaScriptEnabled(true);
        webView.getSettings().setLayoutAlgorithm(WebSettings.LayoutAlgorithm.SINGLE_COLUMN);
        webView.getSettings().setDomStorageEnabled(true);
        webView.getSettings().setAllowFileAccessFromFileURLs(true);
        webView.getSettings().setAllowUniversalAccessFromFileURLs(true);

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.KITKAT)
        {
            webView.getSettings().setLayoutAlgorithm(WebSettings.LayoutAlgorithm.TEXT_AUTOSIZING);
        }
        else
        {
            webView.getSettings().setLayoutAlgorithm(WebSettings.LayoutAlgorithm.NORMAL);
        }
        if(true){
            webView.loadUrl("file:///android_asset/terms_fr.html");
        }
    }// end of displayWebViewData

}// end of TermsAndConditionsActivity