package com.subzeal.champ_de_prosperite.adapters;

import static com.subzeal.champ_de_prosperite.constants.activity_constants.INTENT_KEY_PASS_ANNOUNCEMENTS_TO_DISPLAYER;

import android.content.Context;
import android.content.Intent;
import android.graphics.Color;
import android.os.Parcelable;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import com.bumptech.glide.Glide;
import com.smarteist.autoimageslider.SliderViewAdapter;
import com.subzeal.champ_de_prosperite.R;
import com.subzeal.champ_de_prosperite.activities.announcements.AnnouncementsListActivity;
import com.subzeal.champ_de_prosperite.models.SliderItem;
import com.subzeal.champ_de_prosperite.models.announcementModel;

import java.util.ArrayList;
import java.util.List;

public class SliderAdapterExample extends SliderViewAdapter<SliderAdapterExample.SliderAdapterVH> {

    private Context context;
    private List<SliderItem> mSliderItems = new ArrayList<>();
    private List<announcementModel> announcementList;

    public SliderAdapterExample(Context context,List<announcementModel> listo) {
        this.context = context;
        this.announcementList=listo;
    }

    public void renewItems(List<SliderItem> sliderItems) {
        this.mSliderItems = sliderItems;
        notifyDataSetChanged();
    }

    public void deleteItem(int position) {
        this.mSliderItems.remove(position);
        notifyDataSetChanged();
    }

    public void addItem(SliderItem sliderItem) {
        this.mSliderItems.add(sliderItem);
        notifyDataSetChanged();
    }

    @Override
    public SliderAdapterVH onCreateViewHolder(ViewGroup parent) {
        View inflate = LayoutInflater.from(parent.getContext()).inflate(R.layout.image_slider_layout_item, null);
        return new SliderAdapterVH(inflate);
    }

    @Override
    public void onBindViewHolder(SliderAdapterVH viewHolder, final int position) {
        SliderItem sliderItem = mSliderItems.get(position);
        viewHolder.textViewTitle.setText(sliderItem.getTitle());
        viewHolder.textViewTitle.setTextSize(16);
        viewHolder.textViewTitle.setTextColor(Color.WHITE);
        viewHolder.textViewDescription.setText(sliderItem.getDescription());
        viewHolder.textViewDescription.setTextSize(12);
        viewHolder.textViewDescription.setTextColor(Color.parseColor("#94a3b8"));

        Glide.with(viewHolder.itemView)
                .load(sliderItem.getImageUrl())
                .fitCenter()
                .into(viewHolder.imageViewBackground);

        viewHolder.itemView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                //Toast.makeText(context, "Tots " + announcementList.size(), Toast.LENGTH_SHORT).show();
                if(announcementList.size()>=1){
                    Intent goToFileViewIntent=new Intent(context, AnnouncementsListActivity.class);
                    goToFileViewIntent.putParcelableArrayListExtra(INTENT_KEY_PASS_ANNOUNCEMENTS_TO_DISPLAYER,(ArrayList<? extends Parcelable>)announcementList);
                    context.startActivity(goToFileViewIntent);
                }
            }
        });
    }

    @Override
    public int getCount() {
        //slider view count could be dynamic size
        return mSliderItems.size();
    }

    class SliderAdapterVH extends SliderViewAdapter.ViewHolder {
        View itemView;
        ImageView imageViewBackground;
        ImageView imageGifContainer;
        TextView textViewTitle;
        TextView textViewDescription;

        public SliderAdapterVH(View itemView) {
            super(itemView);
            imageViewBackground = itemView.findViewById(R.id.iv_auto_image_slider);
            imageGifContainer = itemView.findViewById(R.id.iv_gif_container);
            textViewTitle = itemView.findViewById(R.id.tv_auto_title);
            textViewDescription = itemView.findViewById(R.id.tv_auto_image_description);
            this.itemView = itemView;
        }
    }// end of SliderAdapterVH
}
