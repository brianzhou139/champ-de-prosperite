package com.subzeal.champ_de_prosperite.local_auth;

import static android.content.Context.MODE_PRIVATE;

import android.app.Activity;
import android.content.Context;
import android.content.SharedPreferences;
import android.content.res.Configuration;
import android.content.res.Resources;

import java.util.Locale;

public class SharedPreferencesAuth {
    private static String KEY_FARMER_UID="uid";
    private static String KEY_FARMER_NAME="name";
    private static String KEY_LANGUAGE="language";

    Context mContext;

    public SharedPreferencesAuth(Context context){
        this.mContext=context;
        String currentLang=getAppLanguage();
        //String currentLang="nd";
        setLocale((Activity) context,currentLang);
    }

    /* returns the uid of the farmer */
    public String getFarmerUid(){
        // Fetching the stored data from the SharedPreference
        SharedPreferences sh = mContext.getSharedPreferences("MySharedPref", MODE_PRIVATE);
        String fUid = sh.getString(KEY_FARMER_UID, null);
        return fUid;
    }

    /* setting the farmer Uid  */
    public void setFarmerUid(String id){
        // Creating a shared pref object with a file name "MySharedPref" in private mode
        SharedPreferences sharedPreferences = mContext.getSharedPreferences("MySharedPref", MODE_PRIVATE);
        SharedPreferences.Editor myEdit = sharedPreferences.edit();
        // write all the data entered by the user in SharedPreference and apply
        myEdit.putString(KEY_FARMER_UID,id);
        myEdit.apply();
    }

    /* returns the uid of the farmer */
    public String getFarmerName(){
        // Fetching the stored data from the SharedPreference
        SharedPreferences sh = mContext.getSharedPreferences("MySharedPref", MODE_PRIVATE);
        String fName = sh.getString(KEY_FARMER_NAME, null);
        return fName;
    }

    /* setting the farmer name */
    public void setFarmerName(String name){
        // Creating a shared pref object with a file name "MySharedPref" in private mode
        SharedPreferences sharedPreferences = mContext.getSharedPreferences("MySharedPref", MODE_PRIVATE);
        SharedPreferences.Editor myEdit = sharedPreferences.edit();
        // write all the data entered by the user in SharedPreference and apply
        myEdit.putString(KEY_FARMER_NAME,name);
        myEdit.apply();
    }

    /* returns the uid of the farmer */
    public String getAppLanguage(){
        // Fetching the stored data from the SharedPreference
        SharedPreferences sh = mContext.getSharedPreferences("MySharedPref", MODE_PRIVATE);
        String appLang = sh.getString(KEY_LANGUAGE, "fr");
        return appLang;
    }

    /* setting the language name*/
    public void setAppLanguage(String lang){
        // Creating a shared pref object with a file name "MySharedPref" in private mode
        SharedPreferences sharedPreferences = mContext.getSharedPreferences("MySharedPref", MODE_PRIVATE);
        SharedPreferences.Editor myEdit = sharedPreferences.edit();
        // write all the data entered by the user in SharedPreference and apply
        myEdit.putString(KEY_LANGUAGE,lang);
        myEdit.apply();
    }

    /* change the language here  */
    public static void setLocale(Activity activity, String languageCode) {
        Locale locale = new Locale(languageCode);
        Locale.setDefault(locale);
        Resources resources = activity.getResources();
        Configuration config = resources.getConfiguration();
        config.setLocale(locale);
        resources.updateConfiguration(config, resources.getDisplayMetrics());
    }//end of setLocale

}
