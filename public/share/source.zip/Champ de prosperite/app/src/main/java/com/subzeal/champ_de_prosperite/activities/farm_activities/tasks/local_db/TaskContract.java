package com.subzeal.champ_de_prosperite.activities.farm_activities.tasks.local_db;

import android.provider.BaseColumns;

public class TaskContract {
    public static final class TaskEntry implements BaseColumns {

        // Table Name
        public static final String TABLE_NAME = "tasks";

        // Columns
        public static final String _ID = BaseColumns._ID;
        public static final String COLUMN_TASK_DATE= "Date";
        public static final String COLUMN_TASK_NAME = "Name";
        public static final String COLUMN_TASK_STATUS= "Status";
        public static final String COLUMN_TASK_NOTES = "Notes";

    }// end of NationEntry
}
