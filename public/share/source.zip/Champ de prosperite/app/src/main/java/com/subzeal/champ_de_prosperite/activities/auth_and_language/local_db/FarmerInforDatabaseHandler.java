package com.subzeal.champ_de_prosperite.activities.auth_and_language.local_db;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.util.Log;

import com.subzeal.champ_de_prosperite.activities.auth_and_language.model.FarmerModel;

import java.util.ArrayList;

public class FarmerInforDatabaseHandler {
    private static String TAG="FarmerInforDatabaseHandler";
    private Context context;
    private SQLiteDatabase database;
    private FarmerInforDBHelper farmerInforDBHelper;

    public FarmerInforDatabaseHandler(Context context){
        this.context=context;
        farmerInforDBHelper=new FarmerInforDBHelper(context);
        database=farmerInforDBHelper.getWritableDatabase();
    };//end of InventoryDatabaseHandler


    private void insertFarmerInfor(FarmerModel farmerModel){
        ContentValues contentValues=new ContentValues();
        contentValues.put(FarmerInforContract._ID,farmerModel.getFarmerId());
        contentValues.put(FarmerInforContract.COLUMN_FARMER_FIRSTNAME_SURNAME,farmerModel.getFirstNameAndSurname());
        contentValues.put(FarmerInforContract.COLUMN_FARMER_DAY_OF_BIRTH,farmerModel.getDayOfBirth());
        contentValues.put(FarmerInforContract.COLUMN_FARMER_MONTH_OF_BIRTH,farmerModel.getMonthOfBirth());
        contentValues.put(FarmerInforContract.COLUMN_FARMER_YEAR_OF_BIRTH,farmerModel.getYearOfBirth());
        contentValues.put(FarmerInforContract.COLUMN_FARMER_ID_NUMBER,farmerModel.getIdNumber());
        contentValues.put(FarmerInforContract.COLUMN_FARMER_PHONE_NUMBER,farmerModel.getPhoneNumber());
        contentValues.put(FarmerInforContract.COLUMN_FARMER_GENDER,farmerModel.getGender());
        contentValues.put(FarmerInforContract.COLUMN_FARMER_VILLAGE,farmerModel.getGender());
        contentValues.put(FarmerInforContract.COLUMN_FARMER_DISTRICT,farmerModel.getDistrict());
        contentValues.put(FarmerInforContract.COLUMN_FARMER_LANGUAGE,farmerModel.getLanguage());

        long rowID = database.insert(FarmerInforContract.TABLE_NAME,null,contentValues);
    }//end of insertData

    private void updateFarmerInfor(FarmerModel farmerModel) {
        String selection = FarmerInforContract._ID + " = ?";
        String[] selectionArgs = { farmerModel.getFarmerId() };
        ContentValues contentValues = new ContentValues();
        contentValues.put(FarmerInforContract._ID,farmerModel.getFarmerId());
        contentValues.put(FarmerInforContract.COLUMN_FARMER_FIRSTNAME_SURNAME,farmerModel.getFirstNameAndSurname());
        contentValues.put(FarmerInforContract.COLUMN_FARMER_DAY_OF_BIRTH,farmerModel.getDayOfBirth());
        contentValues.put(FarmerInforContract.COLUMN_FARMER_MONTH_OF_BIRTH,farmerModel.getMonthOfBirth());
        contentValues.put(FarmerInforContract.COLUMN_FARMER_YEAR_OF_BIRTH,farmerModel.getYearOfBirth());
        contentValues.put(FarmerInforContract.COLUMN_FARMER_ID_NUMBER,farmerModel.getIdNumber());
        contentValues.put(FarmerInforContract.COLUMN_FARMER_PHONE_NUMBER,farmerModel.getPhoneNumber());
        contentValues.put(FarmerInforContract.COLUMN_FARMER_GENDER,farmerModel.getGender());
        contentValues.put(FarmerInforContract.COLUMN_FARMER_VILLAGE,farmerModel.getGender());
        contentValues.put(FarmerInforContract.COLUMN_FARMER_DISTRICT,farmerModel.getDistrict());
        contentValues.put(FarmerInforContract.COLUMN_FARMER_LANGUAGE,farmerModel.getLanguage());

        int rowsUpdated = database.update(FarmerInforContract.TABLE_NAME, contentValues, selection, selectionArgs);
        Log.i(TAG, "Number of rows updated: " + rowsUpdated);
    }// updateFarmerInfor

    public ArrayList<FarmerModel> queryFarmerInforAndReturnIt(){
        ArrayList<FarmerModel> mList=new ArrayList<>();

        String [] projection={
                FarmerInforContract._ID,
                FarmerInforContract.COLUMN_FARMER_FIRSTNAME_SURNAME,
                FarmerInforContract.COLUMN_FARMER_GENDER
        };

        // Filter
        String selection = null;
        String []selectionArgs = null;

        String sortOrder = null;

        Cursor cursor = database.query(FarmerInforContract.TABLE_NAME,// table sname ,
                projection,  // Columns to return
                selection,   // Selection: Where clause or the condition
                selectionArgs, //
                null, //
                null,
                sortOrder
        );

        if(cursor!=null){
            String str="";
            while(cursor.moveToNext()){  // cursor iterates through all the rows
                // Cursor iterates through all rows
                String[] columns = cursor.getColumnNames();
                FarmerModel item=new FarmerModel();

                // { id , country , continent }
                String id=cursor.getString(cursor.getColumnIndex(FarmerInforContract._ID));
                String fName=cursor.getString(cursor.getColumnIndex(FarmerInforContract.COLUMN_FARMER_FIRSTNAME_SURNAME));
                String fGender=cursor.getString(cursor.getColumnIndex(FarmerInforContract.COLUMN_FARMER_GENDER));

                item.setFirstNameAndSurname(fName);
                item.setGender(fGender);
                item.setFarmerId(id);
                mList.add(item);
            }
        }
        return mList;
    }//end of insertData

    // check is id if there is recent data
    public boolean isRecentFarmerAvailable(String rowId) {
        String[] projection = {
                FarmerInforContract._ID,
        };
        // Filter results. Make these null if you want to query all rows

        String selection = FarmerInforContract._ID + " = ? ";	// _id = ?
        String[] selectionArgs = { rowId };				// Replace '?' by rowId in runtime		// _id = 5
        String sortOrder = null;	// Ascending or Descending ...
        Cursor cursor = database.query(FarmerInforContract.TABLE_NAME,		// The table name
                projection,                 // The columns to return
                selection,                  // Selection: WHERE clause OR the condition
                selectionArgs,              // Selection Arguments for the WHERE clause
                null,                       // don't group the rows
                null,                       // don't filter by row groups
                sortOrder);					// The sort order
        if (cursor != null && cursor.moveToNext()) {
            String str = "";
            return true;
        }
        return false;
    }


    /* upsert the farmer here */
    public void upsertFarmersLocalDB(FarmerModel fm){
        boolean isIdAvailable=isRecentFarmerAvailable(fm.getFarmerId());
        if(isIdAvailable){
            updateFarmerInfor(fm);
        }else{
            insertFarmerInfor(fm);
        }
    }



}//end of FarmerInforDatabaseHandler
