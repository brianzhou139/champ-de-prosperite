package com.subzeal.champ_de_prosperite.activities.farm_activities.plantings.local_db;

import android.content.Context;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
public class PlantingsDBHelper extends SQLiteOpenHelper {

    private static final String DATABASE_NAME = "farmplantings.db";
    private static final int DATABASE_VERSION = 1;


    private final String SQL_CREATE_COUNTRY_TABLE
            = "CREATE TABLE " + PlantingsContract.PlantingsEntry.TABLE_NAME
            + " (" + PlantingsContract.PlantingsEntry._ID + " INTEGER PRIMARY KEY AUTOINCREMENT, "
            + PlantingsContract.PlantingsEntry.COLUMN_PLANT_NAME + " TEXT NOT NULL, "
            + PlantingsContract.PlantingsEntry.COLUMN_PLANTING_DATE + " TEXT, "
            + PlantingsContract.PlantingsEntry.COLUMN_QUANTITY_PLANTED + " TEXT, "
            + PlantingsContract.PlantingsEntry.COLUMN_NAME_OF_FIELD + " TEXT, "
            + PlantingsContract.PlantingsEntry.COLUMN_NOTES + " TEXT"
            + ");";

    public PlantingsDBHelper(Context context) {
        super(context, DATABASE_NAME, null, DATABASE_VERSION);
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        db.execSQL(SQL_CREATE_COUNTRY_TABLE);
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        // Ideally we wouldn't want to delete all of our entries!
        db.execSQL("DROP TABLE IF EXISTS " + PlantingsContract.PlantingsEntry.TABLE_NAME);
        onCreate(db);	// Call to create a new db with upgraded schema and version
    }
}
