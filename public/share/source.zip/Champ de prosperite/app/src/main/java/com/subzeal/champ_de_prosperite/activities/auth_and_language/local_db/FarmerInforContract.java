package com.subzeal.champ_de_prosperite.activities.auth_and_language.local_db;

import android.provider.BaseColumns;

public class FarmerInforContract implements BaseColumns {
    // Table Name
    public static final String TABLE_NAME = "farmer_infor";
    // Columns
    public static final String _ID=BaseColumns._ID;
    public static final String COLUMN_FARMER_FIRSTNAME_SURNAME="firstNameAndSurname";
    public static final String COLUMN_FARMER_DAY_OF_BIRTH="dayOfBirth";
    public static final String COLUMN_FARMER_MONTH_OF_BIRTH="monthOfBirth";
    public static final String COLUMN_FARMER_YEAR_OF_BIRTH="yearOfBirth";
    public static final String COLUMN_FARMER_ID_NUMBER="idNumber";
    public static final String COLUMN_FARMER_PHONE_NUMBER="phoneNumber";
    public static final String COLUMN_FARMER_GENDER="gender";
    public static final String COLUMN_FARMER_VILLAGE="village";
    public static final String COLUMN_FARMER_DISTRICT="district";
    public static final String COLUMN_FARMER_LANGUAGE="language";
}
