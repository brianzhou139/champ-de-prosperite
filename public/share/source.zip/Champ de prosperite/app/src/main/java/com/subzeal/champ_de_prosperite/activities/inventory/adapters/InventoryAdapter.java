package com.subzeal.champ_de_prosperite.activities.inventory.adapters;

import static com.subzeal.champ_de_prosperite.activities.inventory.util.function_util.getInventoryItemSvg;

import android.content.Context;
import android.content.Intent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.subzeal.champ_de_prosperite.R;
import com.subzeal.champ_de_prosperite.activities.inventory.InventoryEditActivity;
import com.subzeal.champ_de_prosperite.activities.inventory.InventoryPseudoAddActivity;
import com.subzeal.champ_de_prosperite.models.InventoryItem;
import com.subzeal.champ_de_prosperite.models.InventoryItemType;

import java.util.ArrayList;

public class InventoryAdapter extends RecyclerView.Adapter<InventoryAdapter.ViewHolder> {
    private static String TAG="InventoryAdapter";
    private Context mContext;
    private ArrayList<InventoryItem> mList;
    private boolean allowClick;

    public InventoryAdapter(Context context,ArrayList<InventoryItem> it,boolean allowClick){
        this.mContext=context;
        this.mList=it;
        this.allowClick=allowClick;
    }

    @NonNull
    @Override
    public ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view= LayoutInflater.from(mContext).inflate(R.layout.inventory_item,parent,false);
        return new ViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull ViewHolder holder, int position) {
        InventoryItem inventoryItem=mList.get(position);
        holder.mTextName.setText(inventoryItem.getInventoryItemName());
        holder.mQuantity.setText(inventoryItem.getInventoryItemQuantity()+"");

        String itemName=inventoryItem.getInventoryItemName();
        InventoryItemType invItemType=getInventoryItemSvg(itemName);

        if(invItemType.getIconSvg()!=-1){
            holder.inventorySvg.setImageResource(invItemType.getIconSvg());
        }else{
            holder.inventorySvg.setVisibility(View.INVISIBLE);
        }

        if(allowClick && !inventoryItem.isDummy()){
            holder.itemView.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    //Log.d(TAG,"del clicked : "+inventoryItem.getId());
                    //Toast.makeText(mContext,"del clicked : "+inventoryItem.getId(),Toast.LENGTH_SHORT).show();
                    Intent intent = new Intent(mContext, InventoryEditActivity.class);
                    intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                    intent.putExtra("inventory_item",inventoryItem);
                    // starting an Activity to display the page of the article
                    mContext.startActivity(intent);
                }
            });//end of delButt
        }else{
            holder.itemView.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    //Toast.makeText(mContext,"Click the + button to add an inventory",Toast.LENGTH_LONG).show();
                    Intent intent = new Intent(mContext, InventoryPseudoAddActivity.class);
                    intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                    intent.putExtra("inventory_item",inventoryItem);
                    // starting an Activity to display the page of the article
                    mContext.startActivity(intent);
                }
            });//end of delButt
        }


    }//end of onBindViewHolder

    @Override
    public int getItemCount() {
        return mList.size();
    }

    public class ViewHolder extends RecyclerView.ViewHolder{
        TextView mTextName,mQuantity;
        ImageView inventorySvg;
        Button delButt;
        public ViewHolder(@NonNull View itemView) {
            super(itemView);
            mTextName=itemView.findViewById(R.id.inventory_item_name_name);
            mQuantity=itemView.findViewById(R.id.inventory_quantity_id);
            inventorySvg=itemView.findViewById(R.id.inventory_svg_icon);
        }
    }// end of ViewHolder

}