package com.subzeal.champ_de_prosperite.activities.crop_schedule.model;

import android.os.Parcel;
import android.os.Parcelable;

public class CropItem implements Parcelable {
    private String cropName;
    private String cropName_sn;
    private String cropName_nd;
    private String cropName_fr;
    private String cropHtmlContent;
    private String cropHtmlContent_sn;

    public CropItem() {
    }

    protected CropItem(Parcel in) {
        cropName = in.readString();
        cropName_sn = in.readString();
        cropName_nd = in.readString();
        cropName_fr = in.readString();
        cropHtmlContent = in.readString();
        cropHtmlContent_sn = in.readString();
    }

    public static final Creator<CropItem> CREATOR = new Creator<CropItem>() {
        @Override
        public CropItem createFromParcel(Parcel in) {
            return new CropItem(in);
        }

        @Override
        public CropItem[] newArray(int size) {
            return new CropItem[size];
        }
    };

    public String getCropName() {
        return cropName;
    }

    public void setCropName(String cropName) {
        this.cropName = cropName;
    }

    public String getCropName_sn() {
        return cropName_sn;
    }

    public void setCropName_sn(String cropName_sn) {
        this.cropName_sn = cropName_sn;
    }

    public String getCropName_nd() {
        return cropName_nd;
    }

    public void setCropName_nd(String cropName_nd) {
        this.cropName_nd = cropName_nd;
    }

    public String getCropName_fr() {
        return cropName_fr;
    }

    public void setCropName_fr(String cropName_fr) {
        this.cropName_fr = cropName_fr;
    }

    public String getCropHtmlContent() {
        return cropHtmlContent;
    }

    public void setCropHtmlContent(String cropHtmlContent) {
        this.cropHtmlContent = cropHtmlContent;
    }

    public String getCropHtmlContent_sn() {
        return cropHtmlContent_sn;
    }

    public void setCropHtmlContent_sn(String cropHtmlContent_sn) {
        this.cropHtmlContent_sn = cropHtmlContent_sn;
    }

    @Override
    public int describeContents() {
        return 0;
    }

    @Override
    public void writeToParcel(Parcel dest, int flags) {
        dest.writeString(cropName);
        dest.writeString(cropName_sn);
        dest.writeString(cropName_nd);
        dest.writeString(cropName_fr);
        dest.writeString(cropHtmlContent);
        dest.writeString(cropHtmlContent_sn);
    }
}
