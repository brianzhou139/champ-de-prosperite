package com.subzeal.champ_de_prosperite.activities.farm_activities.plantings;

import static com.subzeal.champ_de_prosperite.activities.farm_activities.plantings.adapters.PlantingsAdapter.INTENT_KEY_PASS_PLANT_TO_EDITOR;
import static com.subzeal.champ_de_prosperite.utils.UtilFunctions.getMonthFromInt;

import androidx.appcompat.app.ActionBar;
import androidx.appcompat.app.AppCompatActivity;

import android.app.DatePickerDialog;
import android.os.Bundle;
import android.util.Log;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.DatePicker;
import android.widget.Toast;

import com.google.android.material.textfield.TextInputEditText;
import com.google.gson.Gson;
import com.subzeal.champ_de_prosperite.R;
import com.subzeal.champ_de_prosperite.activities.farm_activities.plantings.local_db.PlantingsDatabaseHandler;
import com.subzeal.champ_de_prosperite.activities.farm_activities.plantings.models.PlantItem;
import com.subzeal.champ_de_prosperite.local_auth.SharedPreferencesAuth;

import java.util.Calendar;

public class EditPlantingActivity extends AppCompatActivity {

    private static String TAG="EditPlantingActivity";
    private TextInputEditText plantingDateEdt;
    String iyear=null;
    int imonth=0;
    String iday=null;
    private boolean dateIsSet=false;

    private Button updateButton,deleteButton;
    private TextInputEditText plantNameEdt,
            plantQuantityEdt,nameOfFieldEdt,notesEdt;

    private PlantingsDatabaseHandler plantingsDatabaseHandler;

    private PlantItem plantItem=null;
    private SharedPreferencesAuth sharedPreferencesAuth;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        sharedPreferencesAuth=new SharedPreferencesAuth(this);
        setContentView(R.layout.activity_edit_planting);
        plantingsDatabaseHandler=new PlantingsDatabaseHandler(this);

        // ActionBar and its title
        ActionBar actionBar=getSupportActionBar();
        actionBar.setTitle("Planting");

        // enable back button
        actionBar.setDisplayHomeAsUpEnabled(true);
        actionBar.setHomeButtonEnabled(true);


        plantingDateEdt=findViewById(R.id.plantings_planting_date_id);
        plantNameEdt=findViewById(R.id.plantings_plant_name_id);
        plantQuantityEdt=findViewById(R.id.plantings_quantity_planted_id);
        nameOfFieldEdt=findViewById(R.id.plantings_name_of_field_id);
        notesEdt=findViewById(R.id.plantings_short_notes_id);

        Bundle extras = getIntent().getExtras();
        if (extras != null) {
            //currentFile = (Paper)getIntent().getSerializableExtra(PAPER_TO_FILEVIEW_DATA_KEY); //Obtaining data
            plantItem = (PlantItem) getIntent().getParcelableExtra(INTENT_KEY_PASS_PLANT_TO_EDITOR);
            // show related fiels
            displayPlantData(plantItem);
        }


        // listed to date clicks
        plantingDateEdt.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                //Toast.makeText(getApplicationContext(),"planting date clicked",Toast.LENGTH_SHORT).show();
                final Calendar newCalender=Calendar.getInstance();

                DatePickerDialog dialog=new DatePickerDialog(EditPlantingActivity.this, new DatePickerDialog.OnDateSetListener() {
                    @Override
                    public void onDateSet(DatePicker view, int year, int month, int dayOfMonth) {
                        iyear=year+"";
                        imonth=month;
                        iday=dayOfMonth+"";
                        Log.d(TAG,"day : "+dayOfMonth);
                        Log.d(TAG,"month : "+month);
                        Log.d(TAG,"year : "+year);
                        dateIsSet=true;
                        plantingDateEdt.setText(dayOfMonth+"/"+month+"/"+year);
                    }
                },newCalender.get(Calendar.YEAR),newCalender.get(Calendar.MONTH),newCalender.get(Calendar.DAY_OF_MONTH));

                dialog.show();
            }
        });
    }//end of onCreate

    private void displayPlantData(PlantItem plantItem) {
        plantingDateEdt.setText(plantItem.getPlantDate());
        plantNameEdt.setText(plantItem.getPlantName());
        plantQuantityEdt.setText(plantItem.getQuantityPlanted());
        nameOfFieldEdt.setText(plantItem.getNameOfField());
        notesEdt.setText(plantItem.getNotes());
    }//end of displayPlantData

    private void updatePlantingInfor(){
        String plantName=plantNameEdt.getText().toString().trim();
        String plantQuantity=plantQuantityEdt.getText().toString().trim();
        String nameOfField=nameOfFieldEdt.getText().toString().trim();
        String plantDate=iday+" "+getMonthFromInt(imonth)+", "+iyear;
        String notes=notesEdt.getText().toString().trim();

        if(iday==null){
            plantDate=plantItem.getPlantDate();
        }

        // check for empty fields
        if(plantName.length()==0){
            Toast.makeText(EditPlantingActivity.this, "Please provide the name of the plant", Toast.LENGTH_SHORT).show();
            return;
        }
        PlantItem newItem=new PlantItem();
        newItem.setPlantDate(plantDate);
        newItem.setPlantName(plantName);
        newItem.setQuantityPlanted(plantQuantity);
        newItem.setNotes(notes);
        newItem.setNameOfField(nameOfField);
        newItem.setId(plantItem.getId());

        Gson gson = new Gson();
        Log.d(TAG,""+ gson.toJson(newItem));

        //Toast.makeText(AddPlantingsActivity.this, "save Butt Clicked", Toast.LENGTH_SHORT).show();
        plantingsDatabaseHandler.updatePlantInfor(newItem);

        // finish activity
        finish();
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.farm_activities_edit_menu, menu);
        return super.onCreateOptionsMenu(menu);
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        switch (item.getItemId()) {
            case R.id.farm_activity_update_id:
                // User chose the "Settings" item, show the app settings UI...
                //updateHarvestItem();
                updatePlantingInfor();
                return true;
            case R.id.farm_activity_delete_id:
                // User chose the "Settings" item, show the app settings UI...
                plantingsDatabaseHandler.deletePlanting(plantItem);
                finish();
                return true;
            default:
                // If we got here, the user's action was not recognized.
                // Invoke the superclass to handle it.
                return super.onOptionsItemSelected(item);

        }
    }



}//end of MainActivity