package com.subzeal.champ_de_prosperite.activities.inventory.util;

import com.subzeal.champ_de_prosperite.R;
import com.subzeal.champ_de_prosperite.models.InventoryItem;
import com.subzeal.champ_de_prosperite.models.InventoryItemType;

import java.util.ArrayList;

public class function_util {
    // public static
    public static String ITEM_TYPE_LIVESTOCK="livestock"; //0
    public static String ITEM_TYPE_CROPS="crops";// 1
    public static String ITEM_TYPE_MACHINERY="machinery"; // 2

    // Live_Stock
    private static String[] CATTLE = {"cattle", "cows", "cow", "bulls", "mombe", "bétail"};
    private static String[] DONKEY = {"donkey", "donkeys", "madhongi", "ânes"};
    private static String[] SHEEP = {"sheep", "sheeps", "hwayi", "moutons"};
    private static String[] PIG = {"pigs", "pig", "nguruve", "porcs"};
    private static String[] GOAT = {"goat", "goats", "mbudzi", "chèvre"};
    private static String[] CHICKEN = {"chicken", "chickens", "broilers", "huku", "poulet"};
    private static String[] RABBIT = {"rabbit", "rabbits", "tsuro", "lapin"};
    private static String[] TURKEY = {"turkey", "turkeys", "ngarukuni", "dinde"};
    private static String[] DUCK = {"duck", "ducks", "dhadha", "canard"};
    private static String[] DOG = {"dog", "dogs", "imbwa", "imbwanana", "mbwanana", "chien"};
    private static String[] CAT = {"cat", "cats", "kiti", "zvikiti", "katsi", "kitsi", "chat"};

    // Crop Produce
    private static String[] MAIZE = {"maize", "corn", "chibage", "mabagwe", "maïs", "blé"};
    private static String[] SUNFLOWER = {"sunflower", "sunflowers", "tournesol"};
    private static String[] TOMATO = {"tomato", "tomatoes", "madomasi", "domasi", "tomate", "tomates"};
    private static String[] BEANS = {"beans", "bean", "haricot", "haricots"};
    private static String[] COTTON = {"cotton", "kotoni", "coton"};
    private static String[] SORGHUM = {"sorghum", "mapfunde", "sorgho"};
    private static String[] GROUNDNUTS = {"groundnuts", "peanuts", "ground nuts", "pea nuts", "nzungu", "arachides"};
    private static String[] WHEAT = {"wheat", "gorosi", "blé"};
    private static String[] BANANA = {"banana", "bananas", "banane", "bananes"};

    // MAchinery
    private static String[] TRACTOR = {"tractor", "tractors", "tirakita", "tracteur"};
    private static String[] PLOWS = {"plows", "plow", "plough", "ploughs", "gejo", "charrue"};
    private static String[] HARVESTOR = {"harvester", "harvesters", "combine harvesters",
            "combine-harvesters", "combine harvester", "combine-harvester", "moissonneuse", "moissonneuses"};
    private static String[] SPRAYER = {"sprayer", "sprayers", "pulvérisateur", "pulvérisateurs"};
    private static String[] SPRINGLER = {"springler", "springlers", "asperseur", "asperseurs","arroseur"};
    private static String[] CULTIVATOR = {"cultivator", "cultivators", "cultivateur", "cultivateurs"};
    private static String[] PLANTER = {"planter", "planters", "planteuse", "planteuses"};
    private static String[] SHOVEL = {"shovel", "shovels", "foshoro", "pelle", "pelles"};
    private static String[] HOE = {"hoe", "hoes", "badza", "mapadza", "houe", "houes"};
    private static String[] AXE = {"axe", "axes", "sanhu", "hache", "haches"};

    public static InventoryItemType getInventoryItemSvg(String itemName){
        InventoryItemType inventoryItemType=new InventoryItemType();
        inventoryItemType.setIconSvg(-1);
        inventoryItemType.setTypeNum(-1);

        // cattle
        if(availableInList(itemName,CATTLE)){
            inventoryItemType.setIconSvg(R.drawable.v_cattle);
            inventoryItemType.setTypeStr(ITEM_TYPE_LIVESTOCK);
            inventoryItemType.setTypeNum(0);
            return inventoryItemType;
        }

        // donkey
        if(availableInList(itemName,DONKEY)){
            inventoryItemType.setIconSvg(R.drawable.v_donkey);
            inventoryItemType.setTypeStr(ITEM_TYPE_LIVESTOCK);
            inventoryItemType.setTypeNum(0);
            return inventoryItemType;
        }

        // sheep
        if(availableInList(itemName,SHEEP)){
            inventoryItemType.setIconSvg(R.drawable.v_sheep);
            inventoryItemType.setTypeStr(ITEM_TYPE_LIVESTOCK);
            inventoryItemType.setTypeNum(0);
            return inventoryItemType;
        }

        // pig
        if(availableInList(itemName,PIG)){
            inventoryItemType.setIconSvg(R.drawable.v_pig);
            inventoryItemType.setTypeStr(ITEM_TYPE_LIVESTOCK);
            inventoryItemType.setTypeNum(0);
            return inventoryItemType;
        }

        // goat
        if(availableInList(itemName,GOAT)){
            inventoryItemType.setIconSvg(R.drawable.v_goat);
            inventoryItemType.setTypeStr(ITEM_TYPE_LIVESTOCK);
            inventoryItemType.setTypeNum(0);
            return inventoryItemType;
        }

        // chicken
        if(availableInList(itemName,CHICKEN)){
            inventoryItemType.setIconSvg(R.drawable.v_chicken);
            inventoryItemType.setTypeStr(ITEM_TYPE_LIVESTOCK);
            inventoryItemType.setTypeNum(0);
            return inventoryItemType;
        }

        // rabbits
        if(availableInList(itemName,RABBIT)){
            inventoryItemType.setIconSvg(R.drawable.v_rabbit);
            inventoryItemType.setTypeStr(ITEM_TYPE_LIVESTOCK);
            inventoryItemType.setTypeNum(0);
            return inventoryItemType;
        }

        // trukey
        if(availableInList(itemName,TURKEY)){
            inventoryItemType.setIconSvg(R.drawable.v_turkey);
            inventoryItemType.setTypeStr(ITEM_TYPE_LIVESTOCK);
            inventoryItemType.setTypeNum(0);
            return inventoryItemType;
        }

        // duck
        if(availableInList(itemName,DUCK)){
            inventoryItemType.setIconSvg(R.drawable.v_duck);
            inventoryItemType.setTypeStr(ITEM_TYPE_LIVESTOCK);
            inventoryItemType.setTypeNum(0);
            return inventoryItemType;
        }

        // Dog
        if(availableInList(itemName,DOG)){
            inventoryItemType.setIconSvg(R.drawable.v_dog);
            inventoryItemType.setTypeStr(ITEM_TYPE_LIVESTOCK);
            inventoryItemType.setTypeNum(0);
            return inventoryItemType;
        }

        // Cats
        if(availableInList(itemName,CAT)){
            inventoryItemType.setIconSvg(R.drawable.v_cat);
            inventoryItemType.setTypeStr(ITEM_TYPE_LIVESTOCK);
            inventoryItemType.setTypeNum(0);
            return inventoryItemType;
        }

        /****************************************************************/
        /***********************         CROPS CROPS            **   ****/
        // maize
        if(availableInList(itemName,MAIZE)){
            inventoryItemType.setIconSvg(R.drawable.v_maize);
            inventoryItemType.setTypeStr(ITEM_TYPE_CROPS);
            inventoryItemType.setTypeNum(1);
            return inventoryItemType;
        }

        // sunflower
        if(availableInList(itemName,SUNFLOWER)){
            inventoryItemType.setIconSvg(R.drawable.v_sunflower);
            inventoryItemType.setTypeStr(ITEM_TYPE_CROPS);
            inventoryItemType.setTypeNum(1);
            return inventoryItemType;
        }

        // tomatoes
        if(availableInList(itemName,TOMATO)){
            inventoryItemType.setIconSvg(R.drawable.v_tomatoes);
            inventoryItemType.setTypeStr(ITEM_TYPE_CROPS);
            inventoryItemType.setTypeNum(1);
            return inventoryItemType;
        }


        // beans
        if(availableInList(itemName,BEANS)){
            inventoryItemType.setIconSvg(R.drawable.v_beans);
            inventoryItemType.setTypeStr(ITEM_TYPE_CROPS);
            inventoryItemType.setTypeNum(1);
            return inventoryItemType;
        }

        // cotton
        if(availableInList(itemName,COTTON)){
            inventoryItemType.setIconSvg(R.drawable.v_cotton);
            inventoryItemType.setTypeStr(ITEM_TYPE_CROPS);
            inventoryItemType.setTypeNum(1);
            return inventoryItemType;
        }


        // ground nuts
        if(availableInList(itemName,GROUNDNUTS)){
            inventoryItemType.setIconSvg(R.drawable.v_groundnuts);
            inventoryItemType.setTypeStr(ITEM_TYPE_CROPS);
            inventoryItemType.setTypeNum(1);
            return inventoryItemType;
        }

        // Sorghum
        if(availableInList(itemName,SORGHUM)){
            inventoryItemType.setIconSvg(R.drawable.v_wheat);
            inventoryItemType.setTypeStr(ITEM_TYPE_CROPS);
            inventoryItemType.setTypeNum(1);
            return inventoryItemType;
        }

        // Wheat
        if(availableInList(itemName,WHEAT)){
            inventoryItemType.setIconSvg(R.drawable.v_wheat);
            inventoryItemType.setTypeStr(ITEM_TYPE_CROPS);
            inventoryItemType.setTypeNum(1);
            return inventoryItemType;
        }

        // Bananas
        if(availableInList(itemName,BANANA)){
            inventoryItemType.setIconSvg(R.drawable.v_banana);
            inventoryItemType.setTypeStr(ITEM_TYPE_CROPS);
            inventoryItemType.setTypeNum(1);
            return inventoryItemType;
        }



        /****************************************************************/
        /***********************        Machinery           **   ****/
        // tractor
        if(availableInList(itemName,TRACTOR)){
            inventoryItemType.setIconSvg(R.drawable.v_tractor);
            inventoryItemType.setTypeStr(ITEM_TYPE_MACHINERY);
            inventoryItemType.setTypeNum(2);
            return inventoryItemType;
        }

        // plow
        if(availableInList(itemName,PLOWS)){
            inventoryItemType.setIconSvg(R.drawable.v_plow);
            inventoryItemType.setTypeStr(ITEM_TYPE_MACHINERY);
            inventoryItemType.setTypeNum(2);
            return inventoryItemType;
        }

        // harvestor
        if(availableInList(itemName,HARVESTOR)){
            inventoryItemType.setIconSvg(R.drawable.v_harvester);
            inventoryItemType.setTypeStr(ITEM_TYPE_MACHINERY);
            inventoryItemType.setTypeNum(2);
            return inventoryItemType;
        }

        // springler
        if(availableInList(itemName,SPRINGLER)){
            inventoryItemType.setIconSvg(R.drawable.v_sprinkler);
            inventoryItemType.setTypeStr(ITEM_TYPE_MACHINERY);
            inventoryItemType.setTypeNum(2);
            return inventoryItemType;
        }

        // sprayer
        if(availableInList(itemName,SPRAYER)){
            inventoryItemType.setIconSvg(R.drawable.v_sprayer);
            inventoryItemType.setTypeStr(ITEM_TYPE_MACHINERY);
            inventoryItemType.setTypeNum(2);
            return inventoryItemType;
        }

        // sprayer
        if(availableInList(itemName,CULTIVATOR)){
            inventoryItemType.setIconSvg(R.drawable.v_cultivator);
            inventoryItemType.setTypeStr(ITEM_TYPE_MACHINERY);
            inventoryItemType.setTypeNum(2);
            return inventoryItemType;
        }

        // cultivator
        if(availableInList(itemName,CULTIVATOR)){
            inventoryItemType.setIconSvg(R.drawable.v_cultivator);
            inventoryItemType.setTypeStr(ITEM_TYPE_MACHINERY);
            inventoryItemType.setTypeNum(2);
            return inventoryItemType;
        }

        // shovel
        if(availableInList(itemName,SHOVEL)){
            inventoryItemType.setIconSvg(R.drawable.v_shovel);
            inventoryItemType.setTypeStr(ITEM_TYPE_MACHINERY);
            inventoryItemType.setTypeNum(2);
            return inventoryItemType;
        }

        // hoe
        if(availableInList(itemName,HOE)){
            inventoryItemType.setIconSvg(R.drawable.v_hoe);
            inventoryItemType.setTypeStr(ITEM_TYPE_MACHINERY);
            inventoryItemType.setTypeNum(2);
            return inventoryItemType;
        }


        return inventoryItemType;
    }


    /* checks if a string is available in a list*/
    private static boolean availableInList(String itemName, String[] listo){
        for(int i=0;i<listo.length;i++){
            if(itemName.trim().toLowerCase().equals(listo[i].trim().toLowerCase())){
                return true;
            }
        }
        return false;
    }

    public static ArrayList<InventoryItem> getEmptyListOfInventories(){
        ArrayList<InventoryItem> itemArrayList=new ArrayList<>();


        InventoryItem im3 = new InventoryItem();
        im3.setInventoryItemName("tracteur");
        im3.setInventoryItemQuantity("0");
        im3.setDummy(true);

        InventoryItem im1 = new InventoryItem();
        im1.setInventoryItemName("charrue");
        im1.setInventoryItemQuantity("0");
        im1.setDummy(true);

        InventoryItem im0 = new InventoryItem();
        im0.setInventoryItemName("houe");
        im0.setInventoryItemQuantity("0");
        im0.setDummy(true);

        InventoryItem it9 = new InventoryItem();
        it9.setInventoryItemName("arroseur");
        it9.setInventoryItemQuantity("0");
        it9.setDummy(true);

        InventoryItem it8 = new InventoryItem();
        it8.setInventoryItemName("maïs");
        it8.setInventoryItemQuantity("0 kg");
        it8.setDummy(true);

        InventoryItem it7 = new InventoryItem();
        it7.setInventoryItemName("tomates");
        it7.setInventoryItemQuantity("0");
        it7.setDummy(true);

        InventoryItem it6 = new InventoryItem();
        it6.setInventoryItemName("coton");
        it6.setInventoryItemQuantity("0 balles");
        it6.setDummy(true);

        InventoryItem it5 = new InventoryItem();
        it5.setInventoryItemName("blé");
        it5.setInventoryItemQuantity("0 kg");
        it5.setDummy(true);

        InventoryItem it4 = new InventoryItem();
        it4.setInventoryItemName("bétail");
        it4.setInventoryItemQuantity("0");
        it4.setDummy(true);

        InventoryItem it3 = new InventoryItem();
        it3.setInventoryItemName("porcs");
        it3.setInventoryItemQuantity("0");
        it3.setDummy(true);

        InventoryItem it2 = new InventoryItem();
        it2.setInventoryItemName("ânes");
        it2.setInventoryItemQuantity("0");
        it2.setDummy(true);

        InventoryItem it1 = new InventoryItem();
        it1.setInventoryItemName("bétail");
        it1.setInventoryItemQuantity("0");
        it1.setDummy(true);

        itemArrayList.add(it1);
        itemArrayList.add(it2);
        itemArrayList.add(it3);
        itemArrayList.add(it4);
        itemArrayList.add(it5);
        itemArrayList.add(it6);
        itemArrayList.add(it7);
        itemArrayList.add(it8);
        itemArrayList.add(it9);
        itemArrayList.add(im0);
        itemArrayList.add(im1);
        itemArrayList.add(im3);
        return itemArrayList;
    }

}
