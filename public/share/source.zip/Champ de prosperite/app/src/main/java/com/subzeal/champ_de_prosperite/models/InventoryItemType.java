package com.subzeal.champ_de_prosperite.models;

public class InventoryItemType {
    String itemName;
    int iconSvg;
    String typeStr;
    int typeNum;

    public InventoryItemType() {
    }

    public String getItemName() {
        return itemName;
    }

    public void setItemName(String itemName) {
        this.itemName = itemName;
    }

    public int getIconSvg() {
        return iconSvg;
    }

    public void setIconSvg(int iconSvg) {
        this.iconSvg = iconSvg;
    }

    public String getTypeStr() {
        return typeStr;
    }

    public void setTypeStr(String typeStr) {
        this.typeStr = typeStr;
    }

    public int getTypeNum() {
        return typeNum;
    }

    public void setTypeNum(int typeNum) {
        this.typeNum = typeNum;
    }
}
