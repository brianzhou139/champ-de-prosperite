package com.subzeal.champ_de_prosperite.activities.auth_and_language;

import static com.subzeal.champ_de_prosperite.constants.firebase_constants.REALTIME_DB_FARMERS;
import static com.subzeal.champ_de_prosperite.utils.Logger.printd;

import androidx.annotation.NonNull;
import androidx.appcompat.app.ActionBar;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;

import android.app.DatePickerDialog;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.location.Address;
import android.location.Geocoder;
import android.location.Location;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.DatePicker;
import android.widget.RadioGroup;
import android.widget.Toast;

import com.google.android.gms.location.FusedLocationProviderClient;
import com.google.android.gms.location.LocationServices;
import com.google.android.gms.tasks.OnFailureListener;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.android.material.textfield.TextInputEditText;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.gson.Gson;
import com.subzeal.champ_de_prosperite.HomePageActivity;
import com.subzeal.champ_de_prosperite.R;
import com.subzeal.champ_de_prosperite.activities.auth_and_language.local_db.FarmerInforDatabaseHandler;
import com.subzeal.champ_de_prosperite.activities.auth_and_language.model.FarmerModel;
import com.subzeal.champ_de_prosperite.local_auth.SharedPreferencesAuth;

import java.io.IOException;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.HashMap;
import java.util.List;
import java.util.Locale;
import java.util.UUID;

public class RegistrationPage1Activity extends AppCompatActivity {
    private static String TAG="RegistrationPage1Activity";
    private Button registerButton;
    private TextInputEditText firstNameEdt,idNumberEdt,
            phoneNumberEdt,villageEdt,regDateOfBirthEdt,
            wardEdt,districtEdt;
    String iyear=null;
    String imonth=null;
    String iday=null;

    private RadioGroup radioGroup;
    private FarmerModel currentFarmerDetails;

    private FusedLocationProviderClient fusedLocationProviderClient;
    public static int REQUEST_COD=100;

    private FarmerInforDatabaseHandler farmerInforDatabaseHandler;
    private SharedPreferencesAuth sharedPreferencesAuth;
    private DatabaseReference mDatabase;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        sharedPreferencesAuth=new SharedPreferencesAuth(this);
        setContentView(R.layout.activity_registration_page1);

        // ActionBar and its title
        ActionBar actionBar=getSupportActionBar();
        actionBar.setTitle(getResources().getString(R.string.registration_form_label));

        mDatabase = FirebaseDatabase.getInstance().getReference();
        farmerInforDatabaseHandler=new FarmerInforDatabaseHandler(this);
        fusedLocationProviderClient= LocationServices.getFusedLocationProviderClient(this);

        ArrayList<FarmerModel> listo=new ArrayList<>();
        listo=farmerInforDatabaseHandler.queryFarmerInforAndReturnIt();

        registerButton=findViewById(R.id.register_button_id);
        firstNameEdt=findViewById(R.id.reg_first_name_id);
        regDateOfBirthEdt=findViewById(R.id.register_date_id);
        idNumberEdt=findViewById(R.id.reg_id_number_id);
        phoneNumberEdt=findViewById(R.id.reg_phone_number_id);
        villageEdt=findViewById(R.id.reg_village_id);
        wardEdt=findViewById(R.id.reg_ward_id);
        districtEdt=findViewById(R.id.edit_district_id);
        radioGroup=findViewById(R.id.radioGroup);

        currentFarmerDetails=new FarmerModel();
        currentFarmerDetails.setGender("");

        try {
            if (ContextCompat.checkSelfPermission(getApplicationContext(), android.Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED ) {
                ActivityCompat.requestPermissions(this, new String[]{android.Manifest.permission.ACCESS_FINE_LOCATION}, 101);
            }
        } catch (Exception e){
            e.printStackTrace();
        }

        // listed to date clicks
        regDateOfBirthEdt.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                //Toast.makeText(getApplicationContext(),"planting date clicked",Toast.LENGTH_SHORT).show();
                final Calendar newCalender=Calendar.getInstance();

                DatePickerDialog dialog=new DatePickerDialog(RegistrationPage1Activity.this, new DatePickerDialog.OnDateSetListener() {
                    @Override
                    public void onDateSet(DatePicker view, int year, int month, int dayOfMonth) {
                        iyear=year+"";
                        imonth=month+"";
                        iday=dayOfMonth+"";
                        printd(TAG,"day : "+dayOfMonth);
                        printd(TAG,"month : "+month);
                        printd(TAG,"year : "+year);
                        regDateOfBirthEdt.setText(dayOfMonth+"/"+month+"/"+year);
                    }
                },newCalender.get(Calendar.YEAR),newCalender.get(Calendar.MONTH),newCalender.get(Calendar.DAY_OF_MONTH));

                dialog.show();
            }
        });


        // listen tp radio button changes
        radioGroup.setOnCheckedChangeListener(new RadioGroup.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(RadioGroup group, int checkedId) {
                switch (checkedId){
                    case R.id.radio_button_male_id:
                        currentFarmerDetails.setGender("male");
                        break;
                    case R.id.radio_button_female_id:
                        currentFarmerDetails.setGender("female");
                        break;
                    default:
                        Log.d("Main Activity","Hello World");
                }
                //Toast.makeText(getApplicationContext(),"Radio butt",Toast.LENGTH_SHORT).show();
            }
        });

        // listen to reg buttomn clicks
        registerButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String firstNameSurname=firstNameEdt.getText().toString();
                String idNumber=idNumberEdt.getText().toString();
                String phoneNumber=phoneNumberEdt.getText().toString();
                String village=villageEdt.getText().toString();
                String ward=wardEdt.getText().toString();
                String district=districtEdt.getText().toString();

                String dayOfBirth=iday;
                String monthOfMonth=imonth;
                String yearOfBirth=iyear;

                // first name and surname
                if(firstNameSurname.trim().length()==0){
                    Toast.makeText(getApplicationContext(),getResources().getString(R.string.reg_fill_in_name),Toast.LENGTH_LONG).show();
                    return;
                }

                if(imonth==null){
                    Toast.makeText(getApplicationContext(),getResources().getString(R.string.reg_fill_in_date_of_birth),Toast.LENGTH_LONG).show();
                    return;
                }

                if(idNumber.trim().length()==0 ||
                        phoneNumber.trim().length()==0 ||
                        village.trim().length()==0 || ward.trim().length()==0 || district.trim().length()==0){
                    Toast.makeText(getApplicationContext(),getResources().getString(R.string.reg_fill_in_all_details),Toast.LENGTH_LONG).show();
                    return;
                }

                //Toast.makeText(getApplicationContext(),"its still showing",Toast.LENGTH_SHORT).show();
                if(currentFarmerDetails.getGender().trim().length()==0){
                    Toast.makeText(getApplicationContext(),getResources().getString(R.string.reg_fill_in_gender),Toast.LENGTH_SHORT).show();
                    return;
                }

                String uniqueId = sharedPreferencesAuth.getFarmerUid();

                if(uniqueId==null){
                    uniqueId = UUID.randomUUID().toString();
                    sharedPreferencesAuth.setFarmerUid(uniqueId);
                }
                currentFarmerDetails.setFarmerId(uniqueId);
                currentFarmerDetails.setFirstNameAndSurname(firstNameSurname);
                currentFarmerDetails.setDayOfBirth(dayOfBirth);
                currentFarmerDetails.setMonthOfBirth(monthOfMonth);
                currentFarmerDetails.setYearOfBirth(yearOfBirth);
                currentFarmerDetails.setIdNumber(idNumber);
                currentFarmerDetails.setVillage(village);
                currentFarmerDetails.setWard(ward);
                currentFarmerDetails.setDistrict(district);
                currentFarmerDetails.setPhoneNumber(phoneNumber);

                // save data to real time DB
                saveDataToRealtimeDb(currentFarmerDetails);

                // Register User And go to the MainActivity
                Gson gson = new Gson();
                printd(TAG,""+ gson.toJson(currentFarmerDetails));

                // save data to the local database
                farmerInforDatabaseHandler.upsertFarmersLocalDB(currentFarmerDetails);
                sharedPreferencesAuth.setFarmerName(firstNameSurname);

                // Go to MaimPageActivity
                // Go to Registration Page
                Intent intent = new Intent(getApplicationContext(), HomePageActivity.class);
                startActivity(intent);
                finish();

            }

        });//end of continue butt

    } // end of onCreate

    private void saveDataToRealtimeDb(FarmerModel farmerModel){
        try{
            //mDatabase = FirebaseDatabase.getInstance().getReference();
            mDatabase.child(REALTIME_DB_FARMERS).child(farmerModel.getFarmerId()).setValue(farmerModel)
                    .addOnSuccessListener(new OnSuccessListener<Void>() {
                        @Override
                        public void onSuccess(Void unused) {
                            FindLocationAndSave();
                        }
                    }).addOnFailureListener(new OnFailureListener() {
                        @Override
                        public void onFailure(@NonNull Exception e) {

                        }
                    });
        }catch (Exception e){
            printd(TAG,"Error while saving to firebase");
        }

    }//end of saveDataToRealtimeDb

    // Find Location And Save
    public void FindLocationAndSave(){
        if (ContextCompat.checkSelfPermission(getApplicationContext(), android.Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED ) {
            //ActivityCompat.requestPermissions(this, new String[]{android.Manifest.permission.ACCESS_FINE_LOCATION}, 101);
        }else{
            fusedLocationProviderClient.getLastLocation().addOnSuccessListener(new OnSuccessListener<Location>() {
                @Override
                public void onSuccess(Location location) {
                    if(location!=null){
                        Geocoder geocoder=new Geocoder(getApplicationContext(), Locale.getDefault());
                        try {
                            List<Address> addressesList=geocoder.getFromLocation(location.getLatitude(),location.getLongitude(),1);
                            Address adr=addressesList.get(0);
                            // Register User And go to the MainActivity
                            Gson gson = new Gson();
                            printd(TAG,"Address Ici");
                            printd(TAG,""+ gson.toJson(adr));
                            printd(TAG,"Latitude : "+ adr.getLatitude());
                            printd(TAG,"Longitude : "+ adr.getLongitude());
                            // Log.d(TAG,"City : "+ adr.getCountryName());
                            // Log.d(TAG,"PostalCode : "+ adr.getPostalCode());
                            double latitude=adr.getLatitude();
                            double longitude=adr.getLongitude();

                            HashMap<String,Object> locationUpdate = new HashMap<>();
                            locationUpdate.put("latitude", latitude);
                            locationUpdate.put("longitude", longitude);

                            String fId=sharedPreferencesAuth.getFarmerUid();
                            if(fId!=null){
                                mDatabase.child(REALTIME_DB_FARMERS).child(fId).updateChildren(locationUpdate);
                            }

                        } catch (IOException e) {
                            e.printStackTrace();
                        }

                    }
                }
            });

        }
    };



} // end of  RegistrationPage1Activity