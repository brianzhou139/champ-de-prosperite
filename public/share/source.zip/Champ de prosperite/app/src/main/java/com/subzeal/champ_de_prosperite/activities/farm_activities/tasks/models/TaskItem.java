package com.subzeal.champ_de_prosperite.activities.farm_activities.tasks.models;

import android.os.Parcel;
import android.os.Parcelable;

public class TaskItem implements Parcelable {
    private int id;
    private String taskDate;
    private String taskName;
    private String taskStatus;
    private String taskNotes;

    public TaskItem(){};

    protected TaskItem(Parcel in) {
        id = in.readInt();
        taskDate = in.readString();
        taskName = in.readString();
        taskStatus = in.readString();
        taskNotes = in.readString();
    }

    @Override
    public void writeToParcel(Parcel dest, int flags) {
        dest.writeInt(id);
        dest.writeString(taskDate);
        dest.writeString(taskName);
        dest.writeString(taskStatus);
        dest.writeString(taskNotes);
    }

    @Override
    public int describeContents() {
        return 0;
    }

    public static final Creator<TaskItem> CREATOR = new Creator<TaskItem>() {
        @Override
        public TaskItem createFromParcel(Parcel in) {
            return new TaskItem(in);
        }

        @Override
        public TaskItem[] newArray(int size) {
            return new TaskItem[size];
        }
    };

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getTaskDate() {
        return taskDate;
    }

    public void setTaskDate(String taskDate) {
        this.taskDate = taskDate;
    }

    public String getTaskName() {
        return taskName;
    }

    public void setTaskName(String taskName) {
        this.taskName = taskName;
    }

    public String getTaskStatus() {
        return taskStatus;
    }

    public void setTaskStatus(String taskStatus) {
        this.taskStatus = taskStatus;
    }

    public String getTaskNotes() {
        return taskNotes;
    }

    public void setTaskNotes(String taskNotes) {
        this.taskNotes = taskNotes;
    }
}
