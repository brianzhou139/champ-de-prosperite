package com.subzeal.champ_de_prosperite.activities.inventory.local_db;

import android.provider.BaseColumns;

/* Contains Column Names and .. tables and columns */
public class InventoryContract implements BaseColumns {
    // Table Name
    public static final String TABLE_NAME = "inventory_table";

    // Columns
    public static final String _ID=BaseColumns._ID;
    public static final String COLUMN_INVENTORY_ITEM_NAME="Name";
    public static final String COLUMN_INVENTORY_ITEM_QUANTITY="Quantity";

}//end of InventoryContract
