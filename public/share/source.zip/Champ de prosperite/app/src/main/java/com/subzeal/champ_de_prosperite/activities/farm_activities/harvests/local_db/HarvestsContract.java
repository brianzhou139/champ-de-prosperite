package com.subzeal.champ_de_prosperite.activities.farm_activities.harvests.local_db;

import android.provider.BaseColumns;

public class HarvestsContract {
    public static final class HarvestsEntry implements BaseColumns {
        // Table Name
        public static final String TABLE_NAME = "plantings";
        // Columns
        public static final String _ID = BaseColumns._ID;
        public static final String COLUMN_HARVEST_NAME= "HarvestedCrop";
        public static final String COLUMN_HARVEST_DATE = "Date";
        public static final String COLUMN_HARVEST_QUANTITY= "Quantity";
        public static final String COLUMN_HARVEST_NAME_OF_FIELD = "Field";
        public static final String COLUMN_HARVEST_INCOME = "Income";
        public static final String COLUMN_HARVEST_UNIT_COSTS = "UnitCosts";
        public static final String COLUMN_HARVEST_NOTES = "Notes";
    }// end of NationEntry
}
