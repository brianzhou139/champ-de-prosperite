package com.subzeal.champ_de_prosperite.activities.crop_schedule;

import static com.subzeal.champ_de_prosperite.activities.crop_schedule.data.CropsData.getCropsListData;

import androidx.appcompat.app.ActionBar;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.os.Bundle;

import com.subzeal.champ_de_prosperite.R;
import com.subzeal.champ_de_prosperite.activities.crop_schedule.adapters.CropAdapter;
import com.subzeal.champ_de_prosperite.activities.crop_schedule.model.CropItem;
import com.subzeal.champ_de_prosperite.local_auth.SharedPreferencesAuth;

import java.util.ArrayList;

public class CropScheduleListActivity extends AppCompatActivity {
    private RecyclerView mRecyclerView;
    private CropAdapter cropAdapter;
    private ArrayList<CropItem> mList;
    private SharedPreferencesAuth sharedPreferencesAuth;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        sharedPreferencesAuth=new SharedPreferencesAuth(this);
        setContentView(R.layout.activity_crop_schedule_list);
        // ActionBar and its title
        ActionBar actionBar=getSupportActionBar();
        actionBar.setTitle(getResources().getString(R.string.crops_label));

        // enable back button
        actionBar.setDisplayHomeAsUpEnabled(true);
        actionBar.setHomeButtonEnabled(true);

        mList=new ArrayList<>();
        mRecyclerView=findViewById(R.id.recyclerview_id);
        mRecyclerView.setLayoutManager(new LinearLayoutManager(this));

        // dispalying data
        displayLocalCropData();


    }// end of onCreate

    private void displayLocalCropData(){
        mList=getCropsListData();
        // show data in the reyclerList
        cropAdapter=new CropAdapter(getApplicationContext(),mList,sharedPreferencesAuth);
        mRecyclerView.setAdapter(cropAdapter);
    }

}//end of CropScheduleListActivity