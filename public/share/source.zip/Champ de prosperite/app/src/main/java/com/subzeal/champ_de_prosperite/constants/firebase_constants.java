package com.subzeal.champ_de_prosperite.constants;

import static com.subzeal.champ_de_prosperite.constants.app_constants.isDEVELOPMENT;

public class firebase_constants {
    // realtime db constants
    public static String REALTIME_DB_WEATHER_NEWS = isDEVELOPMENT ? "dev-weather_news/":"prod-weather_news/";

    // announcements
    public static String REALTIME_DB_ANNOUNCEMENTS = isDEVELOPMENT ? "dev-announcements/":"prod-announcements/";

    // Market Guide
    public static String REALTIME_DB_MARKET_GUIDE = isDEVELOPMENT ? "dev-market_guide/":"prod-market_guide/";

    // Farmers
    public static String REALTIME_DB_FARMERS = isDEVELOPMENT ? "dev-farmers/":"prod-farmers/";

    // Admins
    public static String REALTIME_DB_ADMINS = isDEVELOPMENT ? "dev-admins/":"prod-admins/";


    // product storage
    public static String FB_STORAGE_PRODUCT__IMAGE = isDEVELOPMENT ? "dev-product_images/":"prod-product_images/";

    // Loans
    public static String REALTIME_DB_LOANS_APPLICATIONS = isDEVELOPMENT ? "dev-loans-applications/":"prod-loans-applications/";


}// end of firebase_constants
