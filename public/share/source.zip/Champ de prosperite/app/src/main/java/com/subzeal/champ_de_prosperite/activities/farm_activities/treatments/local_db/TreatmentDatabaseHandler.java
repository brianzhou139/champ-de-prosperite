package com.subzeal.champ_de_prosperite.activities.farm_activities.treatments.local_db;
import static com.subzeal.champ_de_prosperite.utils.Logger.printd;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;

import com.subzeal.champ_de_prosperite.activities.farm_activities.treatments.models.TreatmentItem;

import java.util.ArrayList;
import java.util.Collections;

public class TreatmentDatabaseHandler {
    private static String TAG="TreatmentDatabaseHandler";
    private Context context;
    private SQLiteDatabase database;
    private TreatmentDBHelper treatmentDBHelper;

    public TreatmentDatabaseHandler(Context context){
        this.context=context;
        treatmentDBHelper=new TreatmentDBHelper(context);
        database=treatmentDBHelper.getWritableDatabase();
    };//end of InventoryDatabaseHandler

    public void insertTreatmentItem(TreatmentItem item){
        ContentValues contentValues=new ContentValues();

        contentValues.put(TreatmentContract.TreatmentEntry.COLUMN_TREATMENT_NAME,item.getTreatmentName());
        contentValues.put(TreatmentContract.TreatmentEntry.COLUMN_TREATMENT_DATE,item.getTreatmentDate());
        contentValues.put(TreatmentContract.TreatmentEntry.COLUMN_TREATMENT_FIELD,item.getTreatmentField());
        contentValues.put(TreatmentContract.TreatmentEntry.COLUMN_TREATMENT_NOTES,item.getTreatmentNotes());

        long rowID = database.insert(TreatmentContract.TreatmentEntry.TABLE_NAME,null,contentValues);
        printd(TAG, "Number of rows updated: " + rowID);

    }//end of insertData

    public void updateTreatmentInfor(TreatmentItem item) {
        String selection = TreatmentContract.TreatmentEntry._ID + " = ?";
        String[] selectionArgs = {String.valueOf(item.getId())};

        ContentValues contentValues = new ContentValues();
        contentValues.put(TreatmentContract.TreatmentEntry.COLUMN_TREATMENT_NAME,item.getTreatmentName());
        contentValues.put(TreatmentContract.TreatmentEntry.COLUMN_TREATMENT_DATE,item.getTreatmentDate());
        contentValues.put(TreatmentContract.TreatmentEntry.COLUMN_TREATMENT_FIELD,item.getTreatmentField());
        contentValues.put(TreatmentContract.TreatmentEntry.COLUMN_TREATMENT_NOTES,item.getTreatmentNotes());

        int rowsUpdated = database.update(TreatmentContract.TreatmentEntry.TABLE_NAME, contentValues, selection, selectionArgs);
        printd(TAG, "Number of rows updated: " + rowsUpdated);
    }// updateFarmerInfor


    public void deleteTreatmentItem(TreatmentItem item) {
        String selection = TreatmentContract.TreatmentEntry._ID + " = ? ";
        String[] selectionArgs = {String.valueOf(item.getId())};//

        int rowsDeleted = database.delete(TreatmentContract.TreatmentEntry.TABLE_NAME, selection, selectionArgs);
        printd(TAG, "Number of rows deleted: " + rowsDeleted);
    }

    public ArrayList<TreatmentItem> queryTreatmentDataAndReturnIt(){
        ArrayList<TreatmentItem> mList=new ArrayList<>();

        String [] projection={
                TreatmentContract.TreatmentEntry._ID,
                TreatmentContract.TreatmentEntry.COLUMN_TREATMENT_NAME,
                TreatmentContract.TreatmentEntry.COLUMN_TREATMENT_DATE,
                TreatmentContract.TreatmentEntry.COLUMN_TREATMENT_FIELD,
                TreatmentContract.TreatmentEntry.COLUMN_TREATMENT_NOTES,
        };

        // Filter
        String selection = null;
        String []selectionArgs = null;

        String sortOrder = null;

        Cursor cursor = database.query(TreatmentContract.TreatmentEntry.TABLE_NAME,// table sname ,
                projection,  // Columns to return
                selection,   // Selection: Where clause or the condition
                selectionArgs, //
                null, //
                null,
                sortOrder
        );

        if(cursor!=null){
            String str="";
            while(cursor.moveToNext()){  // cursor iterates through all the rows
                // Cursor iterates through all rows
                String[] columns = cursor.getColumnNames();
                TreatmentItem item=new TreatmentItem();

                // { id , country , continent }
                int id=cursor.getInt(cursor.getColumnIndex(TreatmentContract.TreatmentEntry._ID));

                String treatmentDate=cursor.getString(cursor.getColumnIndex(TreatmentContract.TreatmentEntry.COLUMN_TREATMENT_DATE));
                String treatmentName=cursor.getString(cursor.getColumnIndex(TreatmentContract.TreatmentEntry.COLUMN_TREATMENT_NAME));
                String treatmentField=cursor.getString(cursor.getColumnIndex(TreatmentContract.TreatmentEntry.COLUMN_TREATMENT_FIELD));
                String treatmentNotes=cursor.getString(cursor.getColumnIndex(TreatmentContract.TreatmentEntry.COLUMN_TREATMENT_NOTES));

                item.setTreatmentDate(treatmentDate);
                item.setTreatmentNotes(treatmentNotes);
                item.setTreatmentField(treatmentField);
                item.setId(id);
                item.setTreatmentName(treatmentName);
                mList.add(item);
            }
        }
        Collections.reverse(mList);
        return mList;
    }//end of insertData

}
