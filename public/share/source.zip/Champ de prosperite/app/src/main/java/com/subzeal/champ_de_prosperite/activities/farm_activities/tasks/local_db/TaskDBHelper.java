package com.subzeal.champ_de_prosperite.activities.farm_activities.tasks.local_db;

import android.content.Context;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

public class TaskDBHelper extends SQLiteOpenHelper {
    private static final String DATABASE_NAME = "farmtasks.db";
    private static final int DATABASE_VERSION = 1;

    private final String SQL_CREATE_TASKS_TABLE
            = "CREATE TABLE " + TaskContract.TaskEntry.TABLE_NAME
            + " (" + TaskContract.TaskEntry._ID + " INTEGER PRIMARY KEY AUTOINCREMENT, "
            + TaskContract.TaskEntry.COLUMN_TASK_NAME + " TEXT NOT NULL, "
            + TaskContract.TaskEntry.COLUMN_TASK_DATE + " TEXT, "
            + TaskContract.TaskEntry.COLUMN_TASK_NOTES + " TEXT, "
            + TaskContract.TaskEntry.COLUMN_TASK_STATUS + " TEXT"
            + ");";

    public TaskDBHelper(Context context) {
        super(context, DATABASE_NAME, null, DATABASE_VERSION);
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        db.execSQL(SQL_CREATE_TASKS_TABLE);
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        // Ideally we wouldn't want to delete all of our entries!
        db.execSQL("DROP TABLE IF EXISTS " + TaskContract.TaskEntry.TABLE_NAME);
        onCreate(db);	// Call to create a new db with upgraded schema and version
    }

}
