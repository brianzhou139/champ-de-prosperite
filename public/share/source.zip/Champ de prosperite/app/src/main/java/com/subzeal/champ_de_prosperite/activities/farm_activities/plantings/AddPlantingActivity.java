package com.subzeal.champ_de_prosperite.activities.farm_activities.plantings;

import static com.subzeal.champ_de_prosperite.utils.UtilFunctions.getMonthFromInt;

import androidx.appcompat.app.ActionBar;
import androidx.appcompat.app.AppCompatActivity;

import android.app.DatePickerDialog;
import android.os.Bundle;
import android.util.Log;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.DatePicker;
import android.widget.Toast;

import com.google.android.material.textfield.TextInputEditText;
import com.google.gson.Gson;
import com.subzeal.champ_de_prosperite.R;
import com.subzeal.champ_de_prosperite.activities.farm_activities.plantings.local_db.PlantingsDatabaseHandler;
import com.subzeal.champ_de_prosperite.activities.farm_activities.plantings.models.PlantItem;
import com.subzeal.champ_de_prosperite.local_auth.SharedPreferencesAuth;

import java.util.Calendar;

public class AddPlantingActivity extends AppCompatActivity {
    private static String TAG="AddPlantingsActivity";
    private TextInputEditText plantingDateEdt;
    String iyear=null;
    int imonth=0;
    String iday=null;
    private boolean dateIsSet=false;

    private TextInputEditText plantNameEdt,
            plantQuantityEdt,nameOfFieldEdt,notesEdt;

    private PlantingsDatabaseHandler plantingsDatabaseHandler;
    private SharedPreferencesAuth sharedPreferencesAuth;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        sharedPreferencesAuth=new SharedPreferencesAuth(this);
        setContentView(R.layout.activity_add_planting);
        plantingsDatabaseHandler=new PlantingsDatabaseHandler(this);

        // ActionBar and its title
        ActionBar actionBar=getSupportActionBar();
        actionBar.setTitle(getResources().getString(R.string.plantings_new_planting));

        // enable back button
        actionBar.setDisplayHomeAsUpEnabled(true);
        actionBar.setHomeButtonEnabled(true);

        plantingDateEdt=findViewById(R.id.plantings_planting_date_id);
        plantNameEdt=findViewById(R.id.plantings_plant_name_id);
        plantQuantityEdt=findViewById(R.id.plantings_quantity_planted_id);
        nameOfFieldEdt=findViewById(R.id.plantings_name_of_field_id);
        notesEdt=findViewById(R.id.plantings_short_notes_id);

        // listed to date clicks
        plantingDateEdt.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                //Toast.makeText(getApplicationContext(),"planting date clicked",Toast.LENGTH_SHORT).show();
                final Calendar newCalender=Calendar.getInstance();

                DatePickerDialog dialog=new DatePickerDialog(AddPlantingActivity.this, new DatePickerDialog.OnDateSetListener() {
                    @Override
                    public void onDateSet(DatePicker view, int year, int month, int dayOfMonth) {
                        iyear=year+"";
                        imonth=month;
                        iday=dayOfMonth+"";
                        Log.d(TAG,"day : "+dayOfMonth);
                        Log.d(TAG,"month : "+month);
                        Log.d(TAG,"year : "+year);
                        dateIsSet=true;
                        plantingDateEdt.setText(dayOfMonth+"/"+month+"/"+year);
                    }
                },newCalender.get(Calendar.YEAR),newCalender.get(Calendar.MONTH),newCalender.get(Calendar.DAY_OF_MONTH));

                dialog.show();
            }
        });
    }//edn of onCreate

    private void saveDataAndClose(){
        if(!dateIsSet){
            Toast.makeText(AddPlantingActivity.this, getResources().getString(R.string.plantings_select_the_date), Toast.LENGTH_SHORT).show();
            return;
        }
        String plantName=plantNameEdt.getText().toString().trim();
        String plantQuantity=plantQuantityEdt.getText().toString().trim();
        String nameOfField=nameOfFieldEdt.getText().toString().trim();
        String plantDate=iday+" "+getMonthFromInt(imonth)+", "+iyear;
        String notes=notesEdt.getText().toString().trim();

        // check for empty fields
        if(plantName.length()==0){
            Toast.makeText(AddPlantingActivity.this, getResources().getString(R.string.plantings_provide_name_of_plant), Toast.LENGTH_SHORT).show();
            return;
        }

        PlantItem plantItem=new PlantItem();
        plantItem.setPlantDate(plantDate);
        plantItem.setPlantName(plantName);
        plantItem.setQuantityPlanted(plantQuantity);
        plantItem.setNotes(notes);
        plantItem.setNameOfField(nameOfField);

        Gson gson = new Gson();
        Log.d(TAG,""+ gson.toJson(plantItem));

        //Toast.makeText(AddPlantingsActivity.this, "save Butt Clicked", Toast.LENGTH_SHORT).show();
        plantingsDatabaseHandler.insertPlantingItem(plantItem);

        // finish activity
        finish();
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.farm_activities_add_menu, menu);
        return super.onCreateOptionsMenu(menu);
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        switch (item.getItemId()) {
            case R.id.action_save:
                // User chose the "Settings" item, show the app settings UI...
                saveDataAndClose();
                return true;
            default:
                // If we got here, the user's action was not recognized.
                // Invoke the superclass to handle it.
                return super.onOptionsItemSelected(item);

        }
    }


}//edn of mainActivity