package com.subzeal.champ_de_prosperite.utils;

import java.text.DecimalFormat;
import java.text.Format;
import java.text.SimpleDateFormat;
import java.util.Date;

public class UtilFunctions {

    /* get Date from long TimeStamp*/
    public static String convertTimestampToDate(long time){
        Date date = new Date(time);
        Format format = new SimpleDateFormat("dd/MM/yy");
        return format.format(date);
    }

    public static String getMonthFromInt(int monthNumber) {
        String[] months = new String[]{"January", "February", "March", "April", "May", "June", "July", "August", "September", "October", "November", "December"};
        return months[monthNumber];
    }

    public static double extractNumberFromString(String input) {
        StringBuilder sb = new StringBuilder();
        boolean hasDecimalPoint = false;

        for (char c : input.toCharArray()) {
            if (Character.isDigit(c)) {
                sb.append(c);
            } else if (c == '.' && !hasDecimalPoint) {
                sb.append(c);
                hasDecimalPoint = true;
            }
        }
        String numberString = sb.toString();
        if (numberString.isEmpty()) {
            return 0.0; // Return 0 if no valid number found
        }
        return Double.parseDouble(numberString);
    }

    public static double roundToTwoDecimalPlaces(double number) {
        DecimalFormat df = new DecimalFormat("#.##");
        String formattedNumber = df.format(number);
        return Double.parseDouble(formattedNumber);
    }


}
