package com.subzeal.champ_de_prosperite.activities.farm_activities;

import androidx.appcompat.app.ActionBar;
import androidx.appcompat.app.AppCompatActivity;
import androidx.cardview.widget.CardView;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;

import com.subzeal.champ_de_prosperite.R;
import com.subzeal.champ_de_prosperite.activities.farm_activities.harvests.HarvestsListActivity;
import com.subzeal.champ_de_prosperite.activities.farm_activities.plantings.PlantingsListActivity;
import com.subzeal.champ_de_prosperite.activities.farm_activities.tasks.TasksListActivity;
import com.subzeal.champ_de_prosperite.activities.farm_activities.treatments.TreatmentsListActivity;
import com.subzeal.champ_de_prosperite.local_auth.SharedPreferencesAuth;

public class DisplayfarmActivitiesActivity extends AppCompatActivity {


    private CardView plantingsCard, treatmentsCard,
            harvestsCard,tasksCard;

    private SharedPreferencesAuth sharedPreferencesAuth;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        sharedPreferencesAuth=new SharedPreferencesAuth(this);
        setContentView(R.layout.activity_displayfarm_activities);

        // ActionBar and its title
        ActionBar actionBar=getSupportActionBar();
        actionBar.setTitle(getResources().getString(R.string.farm_activities_label));

        // enable back button
        actionBar.setDisplayHomeAsUpEnabled(true);
        actionBar.setHomeButtonEnabled(true);

        plantingsCard=findViewById(R.id.plantings_card_id);
        treatmentsCard=findViewById(R.id.treatments_card_id);
        harvestsCard=findViewById(R.id.harvests_card_id);
        tasksCard=findViewById(R.id.tasks_card_id);

        // plantings
        plantingsCard.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // Go to Plantings
                Intent intent = new Intent(getApplicationContext(), PlantingsListActivity.class);
                startActivity(intent);
            }
        });

        // treatments clicked
        treatmentsCard.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // Go to Traetments
                Intent intent = new Intent(getApplicationContext(), TreatmentsListActivity.class);
                startActivity(intent);
            }
        });

        // harvests
        harvestsCard.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // Go to harvests
                Intent intent = new Intent(getApplicationContext(), HarvestsListActivity.class);
                startActivity(intent);
            }
        });

        // tasksCard
        tasksCard.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // Go to Tasks Activity
                Intent intent = new Intent(getApplicationContext(), TasksListActivity.class);
                startActivity(intent);
            }
        });

    }//end of onCreate

}//end of DisplayfarmActivitiesActivity