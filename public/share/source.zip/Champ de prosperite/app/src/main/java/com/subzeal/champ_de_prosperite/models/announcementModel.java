package com.subzeal.champ_de_prosperite.models;

import android.os.Parcel;
import android.os.Parcelable;

public class announcementModel implements Parcelable {
    /* Model Here

    export {
        id:string,
        type:number,
        title:string,
        htmlContent:string,
        textShortContent:string,
        coverImageUrl:any,
        dateCreated:any,
        postedById:string,
        totalSentNotifications:number,
    };

    */

    private String id;
    private int type;
    private String title;
    private String htmlContent;
    private String textShortContent;

    protected announcementModel(Parcel in) {
        id = in.readString();
        type = in.readInt();
        title = in.readString();
        htmlContent = in.readString();
        textShortContent = in.readString();
        coverImageUrl = in.readString();
        dateCreated = in.readLong();
        postedById = in.readString();
        totalSentNotifications = in.readInt();
    }

    @Override
    public void writeToParcel(Parcel dest, int flags) {
        dest.writeString(id);
        dest.writeInt(type);
        dest.writeString(title);
        dest.writeString(htmlContent);
        dest.writeString(textShortContent);
        dest.writeString(coverImageUrl);
        dest.writeLong(dateCreated);
        dest.writeString(postedById);
        dest.writeInt(totalSentNotifications);
    }

    @Override
    public int describeContents() {
        return 0;
    }

    public static final Creator<announcementModel> CREATOR = new Creator<announcementModel>() {
        @Override
        public announcementModel createFromParcel(Parcel in) {
            return new announcementModel(in);
        }

        @Override
        public announcementModel[] newArray(int size) {
            return new announcementModel[size];
        }
    };

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public int getType() {
        return type;
    }

    public void setType(int type) {
        this.type = type;
    }

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public String getHtmlContent() {
        return htmlContent;
    }

    public void setHtmlContent(String htmlContent) {
        this.htmlContent = htmlContent;
    }

    public String getTextShortContent() {
        return textShortContent;
    }

    public void setTextShortContent(String textShortContent) {
        this.textShortContent = textShortContent;
    }

    public String getCoverImageUrl() {
        return coverImageUrl;
    }

    public void setCoverImageUrl(String coverImageUrl) {
        this.coverImageUrl = coverImageUrl;
    }

    public long getDateCreated() {
        return dateCreated;
    }

    public void setDateCreated(long dateCreated) {
        this.dateCreated = dateCreated;
    }

    public String getPostedById() {
        return postedById;
    }

    public void setPostedById(String postedById) {
        this.postedById = postedById;
    }

    public int getTotalSentNotifications() {
        return totalSentNotifications;
    }

    public void setTotalSentNotifications(int totalSentNotifications) {
        this.totalSentNotifications = totalSentNotifications;
    }

    private String coverImageUrl;
    private long dateCreated;
    private String postedById;
    private int totalSentNotifications;

    public announcementModel(){};
}
