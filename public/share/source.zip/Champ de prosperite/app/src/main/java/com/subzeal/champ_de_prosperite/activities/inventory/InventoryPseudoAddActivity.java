package com.subzeal.champ_de_prosperite.activities.inventory;

import static com.subzeal.champ_de_prosperite.activities.inventory.util.function_util.getInventoryItemSvg;

import androidx.appcompat.app.ActionBar;
import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.LinearLayout;

import com.google.android.material.textfield.TextInputEditText;
import com.subzeal.champ_de_prosperite.R;
import com.subzeal.champ_de_prosperite.activities.inventory.local_db.InventoryDatabaseHandler;
import com.subzeal.champ_de_prosperite.local_auth.SharedPreferencesAuth;
import com.subzeal.champ_de_prosperite.models.InventoryItem;
import com.subzeal.champ_de_prosperite.models.InventoryItemType;

import java.util.UUID;

public class InventoryPseudoAddActivity extends AppCompatActivity {

    private TextInputEditText itemNameEdt;
    private TextInputEditText itemQuantityEdt;
    private Button updateInventoryButt;
    private Button deleteInventoryButt;
    private LinearLayout imgContainer;
    private ImageView itemSvgImg;
    private InventoryItem inventoryItem;
    private InventoryDatabaseHandler inventoryDatabaseHandler;

    private SharedPreferencesAuth sharedPreferencesAuth;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        sharedPreferencesAuth=new SharedPreferencesAuth(this);
        setContentView(R.layout.activity_inventory_pseudo_add);

        // ActionBar and its title
        ActionBar actionBar=getSupportActionBar();
        actionBar.setTitle(getResources().getString(R.string.inventory_item_label));

        // enable back button
        actionBar.setDisplayHomeAsUpEnabled(true);
        actionBar.setHomeButtonEnabled(true);

        inventoryDatabaseHandler=new InventoryDatabaseHandler(this);

        imgContainer=findViewById(R.id.item_img_container);
        itemNameEdt=findViewById(R.id.edit_item_name_id);
        itemQuantityEdt=findViewById(R.id.edit_item_quantity_id);

        itemSvgImg=findViewById(R.id.item_svg_id);

        Bundle extras = getIntent().getExtras();
        if (extras != null) {
            //currentFile = (Paper)getIntent().getSerializableExtra(PAPER_TO_FILEVIEW_DATA_KEY); //Obtaining data
            inventoryItem = (InventoryItem) getIntent().getParcelableExtra("inventory_item");
            // show related fiels
            itemNameEdt.setText(inventoryItem.getInventoryItemName());
            itemQuantityEdt.setText(inventoryItem.getInventoryItemQuantity());

            // show svg if it exists
            InventoryItemType inventoryItemType=new InventoryItemType();
            inventoryItemType=getInventoryItemSvg(inventoryItem.getInventoryItemName());
            if(inventoryItemType.getIconSvg()!=-1){
                itemSvgImg.setImageResource(inventoryItemType.getIconSvg());
            }else{
                imgContainer.setVisibility(View.GONE);
            }
        }


    }//end of onCreate

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.farm_activities_add_menu, menu);
        return super.onCreateOptionsMenu(menu);
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        switch (item.getItemId()) {
            case R.id.action_save:
                // User chose the "Settings" item, show the app settings UI...
                String itemName=itemNameEdt.getText().toString();
                String itemQuantity= itemQuantityEdt.getText().toString();
                if(itemName.trim().length()==0 || itemQuantity.trim().length()==0){
                    finish();
                }else{
                    String uniqueId = UUID.randomUUID().toString();
                    InventoryItem newItem=new InventoryItem();
                    newItem.setInventoryItemName(itemName);
                    newItem.setInventoryItemQuantity(itemQuantity);
                    newItem.setId(uniqueId);
                    inventoryDatabaseHandler.insertInventoryData(newItem);
                    // close acitivity
                    finish();
                }

                return true;
            default:
                // If we got here, the user's action was not recognized.
                // Invoke the superclass to handle it.
                return super.onOptionsItemSelected(item);

        }
    }

}//end of InventoryPseudoAddActivity