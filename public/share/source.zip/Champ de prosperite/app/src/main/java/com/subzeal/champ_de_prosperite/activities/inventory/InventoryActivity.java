package com.subzeal.champ_de_prosperite.activities.inventory;
import static com.subzeal.champ_de_prosperite.activities.inventory.util.function_util.getEmptyListOfInventories;
import static com.subzeal.champ_de_prosperite.utils.Logger.printd;

import androidx.appcompat.app.ActionBar;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.app.Dialog;
import android.graphics.Color;
import android.graphics.drawable.ColorDrawable;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.Toast;

import com.google.android.material.floatingactionbutton.ExtendedFloatingActionButton;
import com.google.android.material.textfield.TextInputEditText;
import com.subzeal.champ_de_prosperite.R;
import com.subzeal.champ_de_prosperite.activities.inventory.adapters.InventoryAdapter;
import com.subzeal.champ_de_prosperite.activities.inventory.local_db.InventoryDatabaseHandler;
import com.subzeal.champ_de_prosperite.local_auth.SharedPreferencesAuth;
import com.subzeal.champ_de_prosperite.models.InventoryItem;

import java.util.ArrayList;
import java.util.UUID;

public class InventoryActivity extends AppCompatActivity {
    private static String TAG="InventoryActivity";
    private ExtendedFloatingActionButton fab;
    private InventoryDatabaseHandler inventoryDatabaseHandler;

    private RecyclerView mRecyclerView;
    private InventoryAdapter mInventoryAdapter;
    private ArrayList<InventoryItem> mList;

    private int modalSaveCount=0;
    private SharedPreferencesAuth sharedPreferencesAuth;
    @Override
    protected void onCreate(Bundle savedInstanceState) {

        super.onCreate(savedInstanceState);
        sharedPreferencesAuth=new SharedPreferencesAuth(this);
        setContentView(R.layout.activity_inventory);
        // ActionBar and its title
        ActionBar actionBar=getSupportActionBar();
        actionBar.setTitle(getResources().getString(R.string.inventory_label));

        // enable back button
        actionBar.setDisplayHomeAsUpEnabled(true);
        actionBar.setHomeButtonEnabled(true);

        inventoryDatabaseHandler=new InventoryDatabaseHandler(this);

        fab=findViewById(R.id.fab);
        mRecyclerView=findViewById(R.id.inventoryrecyclerview_list_id);
        mRecyclerView.setLayoutManager(new LinearLayoutManager(this));

        queryAllDataAndDisplay();

        fab.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                showCustomeDialog(false);
                /*
                Snackbar.make(view, "Replace with your own action", Snackbar.LENGTH_LONG)
                        .setAction("Action", null).show();
                        */
            }
        });

    }//end of onCreate

    // retrieves data
    private void queryAllDataAndDisplay(){
        mList=new ArrayList<>();
        printd(TAG,"InventoryActivity() >> ");
        mList=inventoryDatabaseHandler.queryInventoryDataAndReturnIt();
        // show data in the reyclerList
        //Log.d(TAG,"InventoryActivity() >> "+mList.size());
        if(mList.size()==0){
            //Toast.makeText(getApplicationContext(),"heyy",Toast.LENGTH_SHORT).show();
            mList=getEmptyListOfInventories();
            mInventoryAdapter=new InventoryAdapter(getApplicationContext(),mList,false);
            mRecyclerView.setAdapter(mInventoryAdapter);
            //showCustomeDialog(true);
        }else{
            if(mList.size()<3){
                ArrayList<InventoryItem> tempList=getEmptyListOfInventories();
                for(InventoryItem item:tempList){
                    String itemName=item.getInventoryItemName().toLowerCase();
                    boolean available=false;
                    for(InventoryItem db_item:mList){
                        if(itemName.equals(db_item.getInventoryItemName().toLowerCase())){
                            available=true;
                            break;
                        }
                    }
                    if(!available){
                        mList.add(item);
                    }
                }
            }
            mInventoryAdapter=new InventoryAdapter(getApplicationContext(),mList,true);
            mRecyclerView.setAdapter(mInventoryAdapter);
        }
    }


    private void showCustomeDialog(boolean isFocused){
        final Dialog dialog=new Dialog(InventoryActivity.this);

        // set the background to transparemt
        dialog.getWindow().setBackgroundDrawable(new ColorDrawable(Color.TRANSPARENT));

        // we have added a new so lets disable the default
        dialog.requestWindowFeature(getWindow().FEATURE_NO_TITLE);

        // the user will be able to cance the dialog by clicking anywhere
        dialog.setCancelable(true);

        // custom content
        dialog.setContentView(R.layout.custom_dialog);

        final TextInputEditText itemNameEdt=dialog.findViewById(R.id.item_name_id);
        final TextInputEditText itemQuantityEdt=dialog.findViewById(R.id.item_quantity_id);
        final Button inventoryButton = dialog.findViewById(R.id.save_inventory_id);

        if(isFocused){
            //itemNameEdt.setTextInputLayoutFocusedRectEnabled(true);
            itemNameEdt.requestFocus();
        }



        inventoryButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String itemName=itemNameEdt.getText().toString();
                String itemQuantity= itemQuantityEdt.getText().toString();
                if(itemName.trim().length()==0 || itemQuantity.trim().length()==0){
                    Toast.makeText(getApplicationContext(),getResources().getString(R.string.inventory_fill_in_all_details),Toast.LENGTH_SHORT).show();
                    return;
                }
                String uniqueId = UUID.randomUUID().toString();
                InventoryItem inventoryItem=new InventoryItem();
                inventoryItem.setInventoryItemName(itemName);
                inventoryItem.setInventoryItemQuantity(itemQuantity);
                inventoryItem.setId(uniqueId);
                modalSaveCount++;

                //inserting to the databse
                inventoryDatabaseHandler.insertInventoryData(inventoryItem);

                dialog.dismiss();
                queryAllDataAndDisplay();
            }
        });//end of onButton Click

        int width = (int)(getResources().getDisplayMetrics().widthPixels*0.90);
        int height = (int)(getResources().getDisplayMetrics().heightPixels*0.50);
        dialog.getWindow().setLayout(width, height);
        //dialogContainer.setBackgroundResource(R.drawable.back_custom_dialog);
        dialog.show();
    }

    @Override
    protected void onRestart() {
        super.onRestart();
        //inventoryDatabaseHandler.queryInventoryDataAndReturnIt();
    }

    @Override
    protected void onResume() {
        super.onResume();
        queryAllDataAndDisplay();
    }

    @Override
    protected void onDestroy() {
        inventoryDatabaseHandler.destroyInventoryDatabase();
        super.onDestroy();
    }

}//end of InventoryActivity