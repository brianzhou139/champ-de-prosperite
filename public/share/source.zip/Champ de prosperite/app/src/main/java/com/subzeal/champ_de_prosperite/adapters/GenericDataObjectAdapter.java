package com.subzeal.champ_de_prosperite.adapters;

import static com.subzeal.champ_de_prosperite.constants.activity_constants.INTENT_KEY_PASS_DATA_OBJECT;
import static com.subzeal.champ_de_prosperite.models.updateDataObject.TYPE_IMAGE_CONTENT;
import static com.subzeal.champ_de_prosperite.models.updateDataObject.TYPE_TEXT_ONLY_CONTENT;
import static com.subzeal.champ_de_prosperite.utils.UtilFunctions.convertTimestampToDate;

import android.content.Context;
import android.content.Intent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.androidnetworking.widget.ANImageView;
import com.bumptech.glide.Glide;
import com.subzeal.champ_de_prosperite.R;
import com.subzeal.champ_de_prosperite.activities.DisplayDataObjectActivity;
import com.subzeal.champ_de_prosperite.activities.weather_news.WebUrlLoaderActivity;
import com.subzeal.champ_de_prosperite.models.updateDataObject;

import java.util.ArrayList;

public class GenericDataObjectAdapter extends RecyclerView.Adapter{
    // setting the TAG for debugging purposes
    private static String TAG="GenericDataObjectAdapter";

    private ArrayList<updateDataObject> mArrayList;
    private Context mContext;
    private Boolean isDataFromExternalApi;

    public GenericDataObjectAdapter(Context mContext,ArrayList<updateDataObject> mArrayList,boolean isDataFromExternalApi) {
        this.mArrayList = mArrayList;
        this.mContext = mContext;
        this.isDataFromExternalApi=isDataFromExternalApi;
    }

    /*
    @NonNull
    @Override
    public ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        // inflating the layout with the article view  (R.layout.article_item)
        View view;

        switch (viewType){
            case 0:
                return;
            case 1:
                view= LayoutInflater.from(mContext).inflate(R.layout.data_object_item_1,parent,false);
                return new ImageContentViewHolder(view);
        }

        view= LayoutInflater.from(mContext).inflate(R.layout.data_object_item_1,parent,false);
        return new ViewHolder(view);
    }*/

    @NonNull
    @Override
    public RecyclerView.ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        // inflating the layout with the article view  (R.layout.article_item)
        View view;
        switch (viewType){
            case TYPE_TEXT_ONLY_CONTENT:
                view= LayoutInflater.from(mContext).inflate(R.layout.data_object_item_0,parent,false);
                return new TextOnlyContentViewHolder(view);
            case TYPE_IMAGE_CONTENT:
                view= LayoutInflater.from(mContext).inflate(R.layout.data_object_item_1,parent,false);
                return new ImageContentViewHolder(view);
        }
        return null;
    }

    @Override
    public void onBindViewHolder(@NonNull RecyclerView.ViewHolder holder, int position) {
        updateDataObject dataObject=mArrayList.get(position);
        if (dataObject != null) {
            switch (dataObject.getType()) {
                case TYPE_TEXT_ONLY_CONTENT:
                    ((TextOnlyContentViewHolder)holder).title.setText(dataObject.getTitle());
                    ((TextOnlyContentViewHolder)holder).description.setText(dataObject.getTextShortContent());
                    ((TextOnlyContentViewHolder)holder).date.setText(convertTimestampToDate(dataObject.getDateCreated()));
                    break;
                case TYPE_IMAGE_CONTENT:
                    ((ImageContentViewHolder)holder).title.setText(dataObject.getTitle());
                    ((ImageContentViewHolder)holder).description.setText(dataObject.getTextShortContent());
                    ((ImageContentViewHolder)holder).date.setText(convertTimestampToDate(dataObject.getDateCreated()));

                    Glide.with(mContext).load(dataObject.getCoverImageUrl()).into(((ImageContentViewHolder)holder).image);

                    // setting the content Description on the Image
                    ((ImageContentViewHolder)holder).image.setContentDescription(dataObject.getTextShortContent());
                    break;
            }
        }
        // handling click event of the article
        holder.itemView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if(dataObject.isWebApiExternalContent()){
                    // an intent to the WebActivity that display web pages
                    Intent intent = new Intent(mContext, WebUrlLoaderActivity.class);
                    intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                    intent.putExtra("url_key",dataObject.getHtmlContent());
                    // starting an Activity to display the page of the article
                    mContext.startActivity(intent);
                }else{
                    Intent intent = new Intent(mContext, DisplayDataObjectActivity.class);
                    intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                    intent.putExtra(INTENT_KEY_PASS_DATA_OBJECT,dataObject);
                    // starting an Activity to display the page of the article
                    mContext.startActivity(intent);
                }
            }
        });
    }

    @Override
    public int getItemCount() {
        return mArrayList.size();
    }

    public class ViewHolder extends RecyclerView.ViewHolder {
        // declaring the views
        private TextView title,description,date;
        private ANImageView image;

        public ViewHolder(@NonNull View itemView) {
            super(itemView);
            // assigning views to their ids
            title=itemView.findViewById(R.id.title_id);
            description=itemView.findViewById(R.id.description_id);
            image=itemView.findViewById(R.id.image_id);
            date=itemView.findViewById(R.id.dt_date_id);
        }
    }//end of ViewHolder

    @Override
    public int getItemViewType(int position) {

        switch (mArrayList.get(position).getType()) {
            case 0:
                return TYPE_TEXT_ONLY_CONTENT;
            case 1:
                return TYPE_IMAGE_CONTENT;
        }
        return 0;
    }

    public class ImageContentViewHolder extends RecyclerView.ViewHolder {
        // declaring the views
        private TextView title,description,date;
        private ImageView image;

        public ImageContentViewHolder(@NonNull View itemView) {
            super(itemView);
            // assigning views to their ids
            title=itemView.findViewById(R.id.title_id);
            description=itemView.findViewById(R.id.description_id);
            image=itemView.findViewById(R.id.image_id);
            date=itemView.findViewById(R.id.dt_date_id);
        }
    }//end of ViewHolder

    public class TextOnlyContentViewHolder extends RecyclerView.ViewHolder {
        // declaring the views
        private TextView title,description,date;
        public TextOnlyContentViewHolder(@NonNull View itemView) {
            super(itemView);
            // assigning views to their ids
            title=itemView.findViewById(R.id.title_id);
            description=itemView.findViewById(R.id.description_id);
            date=itemView.findViewById(R.id.dt_date_id);
        }
    }//end of ViewHolder

}
