package com.subzeal.champ_de_prosperite.models;

import android.os.Parcel;
import android.os.Parcelable;

public class InventoryItem implements Parcelable {
    private String id;
    private String inventoryItemName;
    private boolean isDummy=false;

    public boolean isDummy() {
        return isDummy;
    }

    public void setDummy(boolean dummy) {
        isDummy = dummy;
    }

    protected InventoryItem(Parcel in) {
        id = in.readString();
        inventoryItemName = in.readString();
        inventoryItemQuantity = in.readString();
    }

    @Override
    public void writeToParcel(Parcel dest, int flags) {
        dest.writeString(id);
        dest.writeString(inventoryItemName);
        dest.writeString(inventoryItemQuantity);
    }

    @Override
    public int describeContents() {
        return 0;
    }

    public static final Creator<InventoryItem> CREATOR = new Creator<InventoryItem>() {
        @Override
        public InventoryItem createFromParcel(Parcel in) {
            return new InventoryItem(in);
        }

        @Override
        public InventoryItem[] newArray(int size) {
            return new InventoryItem[size];
        }
    };

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getInventoryItemName() {
        return inventoryItemName;
    }

    public void setInventoryItemName(String inventoryItemName) {
        this.inventoryItemName = inventoryItemName;
    }

    public String getInventoryItemQuantity() {
        return inventoryItemQuantity;
    }

    public void setInventoryItemQuantity(String inventoryItemQuantity) {
        this.inventoryItemQuantity = inventoryItemQuantity;
    }

    private String inventoryItemQuantity;

    public InventoryItem(){
        isDummy=false;
    };

}
