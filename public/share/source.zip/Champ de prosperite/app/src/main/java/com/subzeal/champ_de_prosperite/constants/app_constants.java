package com.subzeal.champ_de_prosperite.constants;

public class app_constants {
    // Developement Mode
    //public static boolean isDEVELOPMENT=true;
    // Production Mode
    public static boolean isDEVELOPMENT=false;
    // SKELETON
    public static int SHIMMER_DURATION=800;
    public static int SHIMMER_ANGLE=21;
}// end of App-Constants
