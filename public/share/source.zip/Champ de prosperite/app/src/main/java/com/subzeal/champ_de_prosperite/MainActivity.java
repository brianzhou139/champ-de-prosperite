package com.subzeal.champ_de_prosperite;
import static com.subzeal.champ_de_prosperite.constants.fcm_constants.FCM_ANNOUNCEMENT;
import static com.subzeal.champ_de_prosperite.constants.fcm_constants.FCM_MARKET_GUIDE;
import static com.subzeal.champ_de_prosperite.constants.fcm_constants.FCM_WEATHER_UPDATE;
import static com.subzeal.champ_de_prosperite.constants.fcm_constants.LIST_OF_TOPICS;
import static com.subzeal.champ_de_prosperite.utils.Logger.printd;
import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import android.content.Intent;
import android.os.Bundle;
import android.widget.Toast;
import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.messaging.FirebaseMessaging;
import com.subzeal.champ_de_prosperite.activities.announcements.AnnouncementsListActivity;
import com.subzeal.champ_de_prosperite.activities.market_guide.MarketGuideListActivity;
import com.subzeal.champ_de_prosperite.activities.weather_news.WeatherNewsListActivity;
import com.subzeal.champ_de_prosperite.local_auth.SharedPreferencesAuth;

import java.util.Set;

public class MainActivity extends AppCompatActivity {
    private static String TAG="MainActivity";
    private SharedPreferencesAuth sharedPreferencesAuth;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        sharedPreferencesAuth=new SharedPreferencesAuth(this);
        setContentView(R.layout.activity_main);
    }// end of MainActivity

    /*   Checks for Intents and Subscribes to recieve Notifications   */
    private void checkIntentAndSubribeForNotifications(){
        Bundle extras = getIntent().getExtras();
        if(extras!=null){
            Set<String> keysInExtras = extras.keySet();

            String from = extras.getString("from");

            printd(TAG,"::"+from);

            if(from==null){
                return;
            }
            if(from.toLowerCase().equals(FCM_WEATHER_UPDATE.toLowerCase())){
                // Go to WeatherNewsActivity
                Intent intent = new Intent(this, WeatherNewsListActivity.class);
                startActivity(intent);
            }

            if(from.toLowerCase().equals(FCM_MARKET_GUIDE.toLowerCase())){
                // Go to MarketGuideAcitivity
                Intent intent = new Intent(this, MarketGuideListActivity.class);
                startActivity(intent);
            }

            if(from.toLowerCase().equals(FCM_ANNOUNCEMENT.toLowerCase())){
                // Go to Announcements Activity
                Intent intent = new Intent(this, AnnouncementsListActivity.class);
                startActivity(intent);
            }

            printd(TAG,"Keys in Extra");
            for(String key : keysInExtras){
                // find the keys you need and get the data from the bundle using those keys
            }
        }

        printd(TAG,"weathers weathers weathers weathers weathers weathers");

        // iterating on the topics
        for(int i=0;i<LIST_OF_TOPICS.length;i++){
            String topic=LIST_OF_TOPICS[i].toLowerCase();
            FirebaseMessaging.getInstance().subscribeToTopic(topic)
                    .addOnCompleteListener(new OnCompleteListener<Void>() {
                        @Override
                        public void onComplete(@NonNull Task<Void> task) {
                            String msg = "Subscribed";
                            if (!task.isSuccessful()) {
                                msg = "Subscribe failed";
                            }
                            printd(TAG, msg);
                            Toast.makeText(MainActivity.this, msg, Toast.LENGTH_SHORT).show();
                        }
                    });

        }
    }

}// end of MainActivity