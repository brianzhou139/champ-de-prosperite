package com.subzeal.champ_de_prosperite.activities.farm_activities.plantings.adapters;

import android.content.Context;
import android.content.Intent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.subzeal.champ_de_prosperite.R;
import com.subzeal.champ_de_prosperite.activities.farm_activities.plantings.EditPlantingActivity;
import com.subzeal.champ_de_prosperite.activities.farm_activities.plantings.models.PlantItem;

import java.util.ArrayList;

public class PlantingsAdapter extends RecyclerView.Adapter<PlantingsAdapter.ViewHolder>{
    public static String INTENT_KEY_PASS_PLANT_TO_EDITOR="pass_plant_item_to_editor_hgd6dd8dy8y83yd883d";
    private ArrayList<PlantItem> plantItems;
    private Context context;

    public PlantingsAdapter(Context context,ArrayList<PlantItem> listo){
        this.plantItems=listo;
        this.context=context;
    }

    @NonNull
    @Override
    public ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view= LayoutInflater.from(context).inflate(R.layout.planting_item,parent,false);
        return new ViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull ViewHolder holder, int position) {
        PlantItem item=plantItems.get(position);
        holder.plantingNameTxt.setText(item.getPlantName());
        holder.plantDateTxt.setText(item.getPlantDate());
        holder.quantityPlantedTxt.setText(item.getQuantityPlanted());
        holder.nameOfFieldTxt.setText(item.getNameOfField());
        holder.notesTxt.setText(item.getNotes());

        holder.itemView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(context, EditPlantingActivity.class);
                intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                intent.putExtra(INTENT_KEY_PASS_PLANT_TO_EDITOR,item);
                // starting an Activity to display the page of the article
                context.startActivity(intent);
            }
        });

    }//end of onBindViewHolder

    @Override
    public int getItemCount() {
        return plantItems.size();
    }

    public class ViewHolder extends RecyclerView.ViewHolder {
        private TextView plantingNameTxt;
        private TextView plantDateTxt;
        private TextView quantityPlantedTxt;
        private TextView nameOfFieldTxt;
        private TextView notesTxt;
        public ViewHolder(@NonNull View itemView) {
            super(itemView);
            plantingNameTxt=itemView.findViewById(R.id.planting_iten_name_id);
            plantDateTxt=itemView.findViewById(R.id.planting_date_id);
            quantityPlantedTxt=itemView.findViewById(R.id.planting_quantity_id);
            nameOfFieldTxt=itemView.findViewById(R.id.planting_field_name_id);
            notesTxt=itemView.findViewById(R.id.planting_notes_id);
        }
    }
}
