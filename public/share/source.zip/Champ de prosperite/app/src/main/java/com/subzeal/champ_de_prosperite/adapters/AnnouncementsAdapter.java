package com.subzeal.champ_de_prosperite.adapters;

import static com.subzeal.champ_de_prosperite.utils.UtilFunctions.convertTimestampToDate;

import android.content.Context;
import android.os.Build;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.subzeal.champ_de_prosperite.R;
import com.subzeal.champ_de_prosperite.models.announcementModel;

import java.util.List;

public class AnnouncementsAdapter extends RecyclerView.Adapter<AnnouncementsAdapter.ViewHolder>{

    // setting the TAG for debugging purposes
    private static String TAG="AnnouncementsAdapter";

    private List<announcementModel> mList;
    private Context mContext;

    public AnnouncementsAdapter(Context context,List<announcementModel> listo){
        this.mContext=context;
        this.mList=listo;
    }

    @NonNull
    @Override
    public ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view= LayoutInflater.from(mContext).inflate(R.layout.announcement_item,parent,false);
        return new ViewHolder(view);
    }//end of onCreateViewHolder

    @Override
    public void onBindViewHolder(@NonNull ViewHolder holder, int position) {
        announcementModel currentAnnouncement=mList.get(position);

        holder.title.setText(currentAnnouncement.getTitle());
        holder.notitificationDate.setText(convertTimestampToDate(currentAnnouncement.getDateCreated()));
        displayWebViewData(currentAnnouncement,holder.webContent);

    }
    private void displayWebViewData(announcementModel data, WebView webView){
        webView.getSettings().setJavaScriptEnabled(true);
        webView.getSettings().setLayoutAlgorithm(WebSettings.LayoutAlgorithm.SINGLE_COLUMN);
        webView.getSettings().setDomStorageEnabled(true);
        webView.getSettings().setAllowFileAccessFromFileURLs(true);
        webView.getSettings().setAllowUniversalAccessFromFileURLs(true);
        //webView.setInitialScale(1);

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.KITKAT)
        {
            webView.getSettings().setLayoutAlgorithm(WebSettings.LayoutAlgorithm.TEXT_AUTOSIZING);
        }
        else
        {
            webView.getSettings().setLayoutAlgorithm(WebSettings.LayoutAlgorithm.NORMAL);
        }

        //webView.loadDataWithBaseURL(null, getHtmlData(data.getHtmlContent()), "text/html", "utf-8", null);
        webView.loadDataWithBaseURL(null, getHtmlData(data.getTextShortContent().trim()), "text/html", "utf-8", null);
    }

    private String getHtmlData(String bodyHTML) {
        String head = "<head><style>img{max-width: 100%; width:auto; height: auto;}</style></head>";
        return "<html>" + head + "<body>" + bodyHTML + "</body></html>";
    }

    @Override
    public int getItemCount() {
        return mList.size();
    }


    public class ViewHolder extends RecyclerView.ViewHolder{
        private TextView title,notitificationDate;
        private WebView webContent;
        public ViewHolder(@NonNull View itemView) {
            super(itemView);
            title=itemView.findViewById(R.id.annnouncement_id);
            webContent=itemView.findViewById(R.id.annnouncement_webview_id);
            notitificationDate=itemView.findViewById(R.id.notification_date_id);
        }
    }
}
