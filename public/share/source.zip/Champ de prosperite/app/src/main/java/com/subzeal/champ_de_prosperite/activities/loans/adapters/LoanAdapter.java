package com.subzeal.champ_de_prosperite.activities.loans.adapters;

import static com.subzeal.champ_de_prosperite.constants.activity_constants.INTENT_LOAN_TO_LOAN_APPLICATION;

import android.content.Context;
import android.content.Intent;
import android.os.Parcelable;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.TextView;
import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;
import com.subzeal.champ_de_prosperite.R;
import com.subzeal.champ_de_prosperite.activities.loans.LoanAplicationActivity;
import com.subzeal.champ_de_prosperite.activities.loans.TermsAndConditionsActivity;
import com.subzeal.champ_de_prosperite.activities.loans.models.LoanItem;
import com.subzeal.champ_de_prosperite.adapters.AnnouncementsAdapter;
import java.util.ArrayList;

public class LoanAdapter extends RecyclerView.Adapter<LoanAdapter.ViewHolder> {
    private String TAG = "LoanAdapter";
    private Context mContext;
    private ArrayList<LoanItem> loanItemsList;

    public LoanAdapter(Context mContext, ArrayList<LoanItem> loanItemsList) {
        this.mContext = mContext;
        this.loanItemsList = loanItemsList;
    }

    @NonNull
    @Override
    public ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view= LayoutInflater.from(mContext).inflate(R.layout.loan_item,parent,false);
        return new ViewHolder(view);
    }// end of onCreateViewHolder

    @Override
    public void onBindViewHolder(@NonNull ViewHolder holder, int position) {
        LoanItem currentLoan = loanItemsList.get(position);

        // setteing the amount
        holder.amountTxt.setText(""+currentLoan.getAmount());

        // setting the interest rate
        holder.interestRate.setText(""+currentLoan.getInterest_rate());

        // duration
        holder.durationTxt.setText(""+currentLoan.getDuration());

        holder.applyLoanButt.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent goToApplyLoan = new Intent(mContext, TermsAndConditionsActivity.class);
                //goToFileViewIntent.putParcelableArrayListExtra(INTENT_LOAN_TO_LOAN_APPLICATION,(ArrayList<? extends Parcelable>)announcementList);
                goToApplyLoan.putExtra(INTENT_LOAN_TO_LOAN_APPLICATION, (Parcelable) currentLoan);
                mContext.startActivity(goToApplyLoan);
            }
        });// end of applyLoanButt

    }// end of BindViuewHOlder

    @Override
    public int getItemCount() {
        return loanItemsList.size();
    }

    public class ViewHolder extends RecyclerView.ViewHolder {
        private TextView amountTxt,interestRate,durationTxt;
        private Button applyLoanButt;
        public ViewHolder(@NonNull View itemView) {
            super(itemView);
            amountTxt=itemView.findViewById(R.id.amount_loaned_id);
            interestRate = itemView.findViewById(R.id.interest_rate_id);
            durationTxt =  itemView.findViewById(R.id.duration_id);
            applyLoanButt =  itemView.findViewById(R.id.apply_butt_id);

        } //
    }// end of ViewHolder

}// en dof loan adapter
