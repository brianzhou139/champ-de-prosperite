package com.subzeal.champ_de_prosperite.activities.farm_activities.plantings.local_db;

import android.provider.BaseColumns;

public class PlantingsContract {
    public static final class PlantingsEntry implements BaseColumns {
        // Table Name
        public static final String TABLE_NAME = "plantings";
        // Columns
        public static final String _ID = BaseColumns._ID;
        public static final String COLUMN_PLANT_NAME = "PlantName";
        public static final String COLUMN_PLANTING_DATE = "Date";
        public static final String COLUMN_QUANTITY_PLANTED = "Quantity";
        public static final String COLUMN_NAME_OF_FIELD = "Field";
        public static final String COLUMN_NOTES = "Notes";
    }// end of NationEntry

}//end of PlantingsContract



