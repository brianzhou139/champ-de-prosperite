package com.subzeal.champ_de_prosperite.activities.farm_activities.tasks;

import androidx.appcompat.app.ActionBar;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.LinearLayout;

import com.google.android.material.floatingactionbutton.ExtendedFloatingActionButton;
import com.subzeal.champ_de_prosperite.R;
import com.subzeal.champ_de_prosperite.activities.farm_activities.tasks.adapters.TaskAdapter;
import com.subzeal.champ_de_prosperite.activities.farm_activities.tasks.local_db.TaskDatabaseHandler;
import com.subzeal.champ_de_prosperite.activities.farm_activities.tasks.models.TaskItem;
import com.subzeal.champ_de_prosperite.local_auth.SharedPreferencesAuth;

import java.util.ArrayList;

public class TasksListActivity extends AppCompatActivity {

    private static String TAG="TasksListActivity";
    private RecyclerView mRecyclerView;
    private TaskAdapter taskAdapter;
    private ArrayList<TaskItem> mList;
    private ExtendedFloatingActionButton fab;
    private LinearLayout noInforContainer;
    private TaskDatabaseHandler taskDatabaseHandler;
    private SharedPreferencesAuth sharedPreferencesAuth;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        sharedPreferencesAuth=new SharedPreferencesAuth(this);

        setContentView(R.layout.activity_tasks_list);
        taskDatabaseHandler=new TaskDatabaseHandler(this);


        // ActionBar and its title
        ActionBar actionBar=getSupportActionBar();
        actionBar.setTitle("Tasks");

        // enable back button
        actionBar.setDisplayHomeAsUpEnabled(true);
        actionBar.setHomeButtonEnabled(true);

        fab=findViewById(R.id.fab);
        mList=new ArrayList<>();
        mRecyclerView=findViewById(R.id.recyclerview_id);
        mRecyclerView.setLayoutManager(new LinearLayoutManager(this));
        noInforContainer=findViewById(R.id.linear_no_infor_id);

        //setting the data
        displayLocalCropData();

        fab.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(getApplicationContext(), AddTaskActivity.class);
                // starting an Activity to display the page of the article
                startActivity(intent);
            }
        });
    }// end of onCreate


    private void displayLocalCropData(){
        mList=taskDatabaseHandler.queryTaskDataAndReturnIt();

        Log.d(TAG,"szi :: "+mList.size());
        if(mList.size()==0){
            noInforContainer.setVisibility(View.VISIBLE);
        }else{
            noInforContainer.setVisibility(View.GONE);
        }

        // show data in the reyclerList
        taskAdapter=new TaskAdapter(this,mList);
        mRecyclerView.setAdapter(taskAdapter);
    }// displayLocalCropData

    @Override
    protected void onResume() {
        super.onResume();
        displayLocalCropData();
    }// onResume


}//end of TasksListActivity