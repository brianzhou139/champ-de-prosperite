package com.subzeal.champ_de_prosperite.activities.loans;

import static com.subzeal.champ_de_prosperite.constants.activity_constants.INTENT_KEY_PASS_ANNOUNCEMENTS_TO_DISPLAYER;
import static com.subzeal.champ_de_prosperite.constants.activity_constants.INTENT_LOAN_TO_LOAN_APPLICATION;
import static com.subzeal.champ_de_prosperite.constants.firebase_constants.REALTIME_DB_FARMERS;
import static com.subzeal.champ_de_prosperite.constants.firebase_constants.REALTIME_DB_LOANS_APPLICATIONS;
import static com.subzeal.champ_de_prosperite.utils.Logger.printd;
import static com.subzeal.champ_de_prosperite.utils.UtilFunctions.extractNumberFromString;
import static com.subzeal.champ_de_prosperite.utils.UtilFunctions.roundToTwoDecimalPlaces;

import androidx.annotation.NonNull;
import androidx.appcompat.app.ActionBar;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Build;
import android.os.Bundle;
import android.os.Parcelable;
import android.view.View;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.widget.Button;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;

import com.google.android.gms.tasks.OnFailureListener;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.android.material.textfield.TextInputEditText;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.subzeal.champ_de_prosperite.HomePageActivity;
import com.subzeal.champ_de_prosperite.R;
import com.subzeal.champ_de_prosperite.activities.auth_and_language.model.FarmerModel;
import com.subzeal.champ_de_prosperite.activities.loans.models.LoanItem;
import com.subzeal.champ_de_prosperite.local_auth.SharedPreferencesAuth;
import com.subzeal.champ_de_prosperite.utils.KeyboardController;

public class LoanAplicationActivity extends AppCompatActivity {
    // TAG
    private String TAG = "LoanAplicationActivity";
    private SharedPreferencesAuth sharedPreferencesAuth;
    private LoanItem currentLoan;
    private Button submitLoanApplicationButt;
    private TextInputEditText surnameEdt,firstNameEdt,phoneNumberEdt,willayaEdt;
    private KeyboardController keyboardController;

    private WebView webView = null;
    private ScrollView formContainer,thankYouContainer;
    private DatabaseReference mDatabase;

    private TextView amountLoanedTxt,owedAmountTxt,durationtxt;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        sharedPreferencesAuth=new SharedPreferencesAuth(this);
        setContentView(R.layout.activity_loan_aplication);
        keyboardController = new KeyboardController(this);
        mDatabase = FirebaseDatabase.getInstance().getReference();

        submitLoanApplicationButt  = findViewById(R.id.loan_submit_button_id);
        surnameEdt = findViewById(R.id.loan_surname_id);
        firstNameEdt = findViewById(R.id.loan_first_name_id);
        phoneNumberEdt =  findViewById(R.id.reg_phone_number_id);
        willayaEdt = findViewById(R.id.edit_willaya_id);
        webView = (WebView) findViewById(R.id.webview);
        formContainer=findViewById(R.id.form_container);
        thankYouContainer=findViewById(R.id.thank_you_container);
        formContainer.setVisibility(View.VISIBLE);
        thankYouContainer.setVisibility(View.GONE);
        //
        amountLoanedTxt=findViewById(R.id.amount_loaned_id);
        owedAmountTxt=findViewById(R.id.amount_owed_id);
        durationtxt=findViewById(R.id.duration_id);

        // ActionBar and its title
        ActionBar actionBar=getSupportActionBar();
        actionBar.setTitle(getResources().getString(R.string.loan_label));

        // enable back button
        actionBar.setDisplayHomeAsUpEnabled(true);
        actionBar.setHomeButtonEnabled(true);

        Bundle extras = getIntent().getExtras();
        if (extras != null) {
            // get the intent data
            currentLoan = getIntent().getParcelableExtra(INTENT_LOAN_TO_LOAN_APPLICATION);

            // setting the variables
            amountLoanedTxt.setText(currentLoan.getAmount());
            durationtxt.setText(currentLoan.getDuration());

            double amount=extractNumberFromString(currentLoan.getAmount());
            double rate=extractNumberFromString(currentLoan.getInterest_rate());
            double time=extractNumberFromString(currentLoan.getDuration());
            if(time==6){
                time=0.5;
            }
            double addedv = (amount*(rate/100)*time);
            double returnAmount = roundToTwoDecimalPlaces((amount+addedv));
            owedAmountTxt.setText(returnAmount+"");
        }

        submitLoanApplicationButt.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                keyboardController.closeKeyboard();
                if(currentLoan==null){
                    currentLoan= new LoanItem();
                }
                if(surnameEdt.getText().toString().isEmpty() ||
                        firstNameEdt.getText().toString().isEmpty() ||
                        willayaEdt.getText().toString().isEmpty() ||
                        phoneNumberEdt.getText().toString().isEmpty() ){
                    Toast.makeText(LoanAplicationActivity.this, R.string.loan_fill_all_label, Toast.LENGTH_SHORT).show();
                    return;
                }
                currentLoan.setSurname(surnameEdt.getText().toString());
                currentLoan.setFirst_name(firstNameEdt.getText().toString());
                currentLoan.setWillaya(willayaEdt.getText().toString());
                currentLoan.setPhone_number(phoneNumberEdt.getText().toString());

                // saving the data
                saveDataToRealtimeDb(currentLoan);

            }

        });// end of submitLoanApplicationButt

        // display data
        displayWebViewData();

    }// end of onCreate

    /*
    The following code saves loanItem to a firebase realtime db, how to generate a fire*
    * */
    private void saveDataToRealtimeDb(LoanItem loanItem) {
        try {
            DatabaseReference loanRef = mDatabase.child(REALTIME_DB_LOANS_APPLICATIONS).push(); // Generate a new unique ID
            String loanId = loanRef.getKey(); // Get the generated ID

            loanItem.setId(loanId); // Set the generated ID in loanItem

            loanRef.setValue(loanItem)
                    .addOnSuccessListener(new OnSuccessListener<Void>() {
                        @Override
                        public void onSuccess(Void unused) {
                            // Go to thank you page
                            // visibility
                            formContainer.setVisibility(View.GONE);
                            thankYouContainer.setVisibility(View.VISIBLE);
                        }
                    })
                    .addOnFailureListener(new OnFailureListener() {
                        @Override
                        public void onFailure(@NonNull Exception e) {
                            // Failed
                            formContainer.setVisibility(View.VISIBLE);
                            thankYouContainer.setVisibility(View.GONE);
                            Toast.makeText(LoanAplicationActivity.this, e.getMessage(), Toast.LENGTH_LONG).show();
                        }
                    });
        } catch (Exception e) {
            printd(TAG, "Error while saving to Firebase");
            formContainer.setVisibility(View.VISIBLE);
            thankYouContainer.setVisibility(View.GONE);
            Toast.makeText(LoanAplicationActivity.this, e.getMessage(), Toast.LENGTH_LONG).show();
        }
    }


    private void displayWebViewData() {
        webView.getSettings().setJavaScriptEnabled(true);
        webView.getSettings().setLayoutAlgorithm(WebSettings.LayoutAlgorithm.SINGLE_COLUMN);
        webView.getSettings().setDomStorageEnabled(true);
        webView.getSettings().setAllowFileAccessFromFileURLs(true);
        webView.getSettings().setAllowUniversalAccessFromFileURLs(true);

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.KITKAT)
        {
            webView.getSettings().setLayoutAlgorithm(WebSettings.LayoutAlgorithm.TEXT_AUTOSIZING);
        }
        else
        {
            webView.getSettings().setLayoutAlgorithm(WebSettings.LayoutAlgorithm.NORMAL);
        }
        if(true){
            webView.loadUrl("file:///android_asset/thank_you_fr.html");
        }
    }// end of displayWebViewData

    @Override
    public void onBackPressed() {
        super.onBackPressed();
        Intent goToHomePage = new Intent(getApplicationContext(), HomePageActivity.class);
        startActivity(goToHomePage);
    }
}// end of LoanAplicationActivity