package com.subzeal.champ_de_prosperite.activities;

import static com.subzeal.champ_de_prosperite.constants.activity_constants.INTENT_KEY_PASS_DATA_OBJECT;
import static com.subzeal.champ_de_prosperite.models.updateDataObject.TYPE_IMAGE_CONTENT;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Build;
import android.os.Bundle;
import android.view.View;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.widget.ImageView;
import android.widget.TextView;

import com.bumptech.glide.Glide;
import com.subzeal.champ_de_prosperite.R;
import com.subzeal.champ_de_prosperite.models.updateDataObject;

public class DisplayDataObjectActivity extends AppCompatActivity {
    private TextView titleTxt;

    private WebView webView = null;
    private updateDataObject currentDataObject=null;
    private ImageView coverImg;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_display_data_object);
        webView = (WebView) findViewById(R.id.webview);
        coverImg=(ImageView)findViewById(R.id.cover_image_id);
        titleTxt=(TextView)findViewById(R.id.title_id);

        Bundle extras = getIntent().getExtras();
        if (extras != null) {
            //currentFile = (Paper)getIntent().getSerializableExtra(PAPER_TO_FILEVIEW_DATA_KEY); //Obtaining data
            currentDataObject = (updateDataObject) getIntent().getParcelableExtra(INTENT_KEY_PASS_DATA_OBJECT);
            // show related fiels
            titleTxt.setText(currentDataObject.getTitle());
            displayWebViewData(currentDataObject);
            showImage(currentDataObject);
        }
    }//end of onCreate

    private void showImage(updateDataObject data){
        if(data.getType()==TYPE_IMAGE_CONTENT){
            Glide.with(this).load(data.getCoverImageUrl()).into(coverImg);
        }else{
            coverImg.setVisibility(View.GONE);
        }
    }

    private void displayWebViewData(updateDataObject data){
        webView.getSettings().setJavaScriptEnabled(true);
        webView.getSettings().setLayoutAlgorithm(WebSettings.LayoutAlgorithm.SINGLE_COLUMN);
        webView.getSettings().setDomStorageEnabled(true);
        webView.getSettings().setAllowFileAccessFromFileURLs(true);
        webView.getSettings().setAllowUniversalAccessFromFileURLs(true);

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.KITKAT)
        {
            webView.getSettings().setLayoutAlgorithm(WebSettings.LayoutAlgorithm.TEXT_AUTOSIZING);
        }
        else
        {
            webView.getSettings().setLayoutAlgorithm(WebSettings.LayoutAlgorithm.NORMAL);
        }

        webView.loadDataWithBaseURL(null, getHtmlData(data.getHtmlContent()), "text/html", "utf-8", null);
    }

    private String getHtmlData(String bodyHTML) {
        String head = "<head><style>img{max-width: 100%; width:auto; height: auto;}</style></head>";
        return "<html>" + head + "<body>" + bodyHTML + "</body></html>";
    }

}//end of DisplayDataObjectActivity