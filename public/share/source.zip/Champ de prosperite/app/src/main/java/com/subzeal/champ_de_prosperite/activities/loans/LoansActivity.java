package com.subzeal.champ_de_prosperite.activities.loans;

import static com.subzeal.champ_de_prosperite.activities.loans.dummy_data.LoanDummy.getDummyLoansList;
import static com.subzeal.champ_de_prosperite.utils.Logger.printd;

import androidx.appcompat.app.ActionBar;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.os.Bundle;
import com.faltenreich.skeletonlayout.Skeleton;
import com.subzeal.champ_de_prosperite.R;
import com.subzeal.champ_de_prosperite.activities.loans.adapters.LoanAdapter;
import com.subzeal.champ_de_prosperite.activities.loans.dummy_data.LoanDummy;
import com.subzeal.champ_de_prosperite.activities.loans.models.LoanItem;
import com.subzeal.champ_de_prosperite.adapters.AnnouncementsAdapter;
import com.subzeal.champ_de_prosperite.local_auth.SharedPreferencesAuth;
import com.subzeal.champ_de_prosperite.models.announcementModel;

import java.util.ArrayList;
import java.util.List;

public class LoansActivity extends AppCompatActivity {

    // TAG
    private String TAG = "LoansActivity";

    private SharedPreferencesAuth sharedPreferencesAuth;

    private RecyclerView mRecyclerv;
    // declaring an ArrayList of articles
    private ArrayList<LoanItem> mDataList;
    private LoanAdapter loansAdapter;
    // views (skeletons)
    private Skeleton itemsListSkeleton;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_loans);

        // setting the views
        mRecyclerv = findViewById(R.id.rvc);
        // setting the recyclerview layout manager
        mRecyclerv.setLayoutManager(new LinearLayoutManager(this));
        mRecyclerv.setHasFixedSize(false);

        sharedPreferencesAuth=new SharedPreferencesAuth(this);

        // ActionBar and its title
        ActionBar actionBar=getSupportActionBar();
        actionBar.setTitle(getResources().getString(R.string.loans_label));

        // enable back button
        actionBar.setDisplayHomeAsUpEnabled(true);
        actionBar.setHomeButtonEnabled(true);


        // setting the dummy data
        mDataList = new ArrayList<>();
        mDataList = LoanDummy.getDummyLoansList();

        // setting the adapter
        loansAdapter = new LoanAdapter(this,mDataList);
        mRecyclerv.setAdapter(loansAdapter);
        printd(TAG," >> "+mDataList.size());
    }// end of onCreate

}// end of LoansActivity


